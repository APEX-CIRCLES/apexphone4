
import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Users, User as UserIcon, Plus, UserPlus, Info, ArrowLeft, MoreVertical, ShieldCheck, Trophy, Gavel, Camera, Bell, Target, Edit2, Trash2, ListChecks, Lock, RefreshCw } from 'lucide-react';
import { CircleCard } from './components/CircleCard';
import { PublicCircleCard } from './components/PublicCircleCard';
import { Heatmap } from './components/Heatmap';
import { FogOfWar } from './components/FogOfWar';
import { FeedPost } from './components/FeedPost';
import { CheckInModal } from './components/CheckInModal';
import { CreateCircleModal } from './components/CreateCircleModal';
import { JoinCircleModal } from './components/JoinCircleModal';
import { CircleMembersModal } from './components/CircleMembersModal';
import { ChatView } from './components/ChatView';
import { Auth } from './components/Auth';
import { ProfileView } from './components/ProfileView';
import { Toast, ToastProps } from './components/Toast';
import { DayViewModal } from './components/DayViewModal';
import { OnboardingModal } from './components/OnboardingModal';
import { DailyBrief } from './components/DailyBrief';
import { Leaderboard } from './components/Leaderboard';
import { EditCircleModal } from './components/EditCircleModal';
import { HallOfFameView } from './components/HallOfFameView';
import { GovernanceModal } from './components/GovernanceModal';
import { NotificationCenter } from './components/NotificationCenter';
import { GoalProgress } from './components/GoalProgress';
import { GoalModal } from './components/GoalModal';
import { StatsModal } from './components/StatsModal';
import { MasteryTreeModal } from './components/MasteryTreeModal';
import { RankHelpModal } from './components/RankHelpModal';
import { FreezeModal } from './components/FreezeModal';
import { SettingsModal } from './components/SettingsModal';
import { InstallPrompt } from './components/InstallPrompt';
import { Circle, Post, CheckInType, User, HeatmapDay, Goal } from './types';
import { supabase } from './lib/supabase';
import { MASTERY_TRACKS, getMilestone } from './lib/mastery';
import { calculateEarnedMilestones } from './lib/achievement-logic';
import { HABIT_CONFIG } from './lib/habit-config';
import { initAudio, playClick, playSuccess, playUnlock, playError } from './lib/sound';
import { compressImage } from './lib/utils';

function App() {
  const [session, setSession] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Data State
  const [circles, setCircles] = useState<Circle[]>([]);
  const [publicCircles, setPublicCircles] = useState<any[]>([]);
  const [heatmapData, setHeatmapData] = useState<HeatmapDay[]>([]);
  const [activeGoals, setActiveGoals] = useState<Goal[]>([]);
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  
  // Profile / Global Data State
  const [fullPostHistory, setFullPostHistory] = useState<Post[]>([]);
  const [unlockedMilestones, setUnlockedMilestones] = useState<Set<string>>(new Set());
  const [loadingProfileData, setLoadingProfileData] = useState(false);
  const [personalGoals, setPersonalGoals] = useState<Goal[]>([]);
  
  // Navigation State
  const [activeTab, setActiveTab] = useState<'dash' | 'find' | 'profile' | 'circle'>('dash');
  const [circleViewMode, setCircleViewMode] = useState<'feed' | 'mission' | 'chat' | 'hof'>('feed');
  const [selectedCircleId, setSelectedCircleId] = useState<string | null>(null);
  const [toast, setToast] = useState<Omit<ToastProps, 'onClose'> | null>(null);
  
  // Feed & Chat State
  const [feedFilter, setFeedFilter] = useState<CheckInType | 'ALL'>('ALL');
  const [chatDraft, setChatDraft] = useState('');
  
  // Modals
  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [isCreateCircleOpen, setIsCreateCircleOpen] = useState(false);
  const [isJoinCircleOpen, setIsJoinCircleOpen] = useState(false);
  const [isMembersModalOpen, setIsMembersModalOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isEditCircleOpen, setIsEditCircleOpen] = useState(false);
  const [isGovernanceOpen, setIsGovernanceOpen] = useState(false);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [joiningPublicId, setJoiningPublicId] = useState<string | null>(null);
  const [inviteCode, setInviteCode] = useState<string>('');
  
  // Global Modals
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isMasteryOpen, setIsMasteryOpen] = useState(false);
  const [isRankHelpOpen, setIsRankHelpOpen] = useState(false);
  const [isFreezeModalOpen, setIsFreezeModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [missingDateToFreeze, setMissingDateToFreeze] = useState<string | null>(null);

  // Goal Modals
  const [isPersonalGoalModalOpen, setIsPersonalGoalModalOpen] = useState(false);
  const [isCircleGoalModalOpen, setIsCircleGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  
  // Archive / History
  const [selectedDay, setSelectedDay] = useState<HeatmapDay | null>(null);
  const [selectedDayPost, setSelectedDayPost] = useState<Post | null>(null);

  // Time State
  const isSunday = new Date().getDay() === 0;

  const showToast = (message: string, type: 'success' | 'error' | 'neutral') => {
    setToast({ message, type });
    if (type === 'error') playError();
  };

  // 1. Auth & Profile Sync
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) fetchProfile(session.user);
      else setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) fetchProfile(session.user);
      else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    // Check for invite code in URL
    const params = new URLSearchParams(window.location.search);
    const invite = params.get('invite');
    if (invite) {
        setInviteCode(invite);
        // We will open the modal in the profile fetch effect once user is confirmed
    }

    return () => subscription.unsubscribe();
  }, []);

  // 2. Fetch Data when Profile is ready
  useEffect(() => {
    if (userProfile) {
      refreshAllData();
      
      initAudio();

      // Handle Invite Deep Link
      if (inviteCode) {
          setIsJoinCircleOpen(true);
      }

      const channel = supabase
        .channel('notifications')
        .on(
            'postgres_changes',
            {
                event: 'INSERT',
                schema: 'public',
                table: 'notifications',
                filter: `user_id=eq.${userProfile.id}`
            },
            () => {
                fetchUnreadCount();
                showToast('New Intel Received', 'neutral');
                playClick(); 
            }
        )
        .subscribe();
        
      return () => { supabase.removeChannel(channel) };
    }
  }, [userProfile?.id]); 

  const refreshAllData = async () => {
      if (!userProfile) return;
      await Promise.all([
          fetchCircles(),
          fetchHeatmapAndStreak(),
          fetchUnreadCount(),
          fetchActiveGoals()
      ]);
  };

  useEffect(() => {
    if (userProfile) {
      fetchActiveGoals();
    }
  }, [circles, userProfile?.id]);

  useEffect(() => {
    if (activeTab === 'find' && userProfile) {
        fetchPublicCircles();
    }
    if (activeTab === 'profile' && userProfile) {
        fetchFullUserHistory();
        fetchUserMastery();
        fetchPersonalGoals();
    }
  }, [activeTab, userProfile?.id]);

  // Play Click on Tab Change
  useEffect(() => {
      playClick();
  }, [activeTab]);

  const fetchProfile = async (authUser: any) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .single();

      const profile = data as any;

      if (profile) {
        setUserProfile({
            id: profile.id,
            username: profile.username,
            avatarUrl: profile.avatar_url || `https://api.dicebear.com/9.x/dylan/svg?seed=${profile.username}`,
            streak: profile.streak || 0,
            freezeTokens: profile.freeze_tokens || 0
        });
        
        if (profile.onboarding_complete === false) {
            setIsOnboarding(true);
        }

      } else {
        const newProfile = {
            id: authUser.id,
            username: authUser.email.split('@')[0],
            avatar_url: `https://api.dicebear.com/9.x/dylan/svg?seed=${authUser.email}`,
            onboarding_complete: false,
            streak: 0,
            freeze_tokens: 0
        };
        const { error: insertError } = await supabase.from('profiles').insert(newProfile as any);
        if (!insertError) {
            setUserProfile({ 
                id: newProfile.id, 
                username: newProfile.username, 
                avatarUrl: newProfile.avatar_url, 
                streak: 0,
                freezeTokens: 0
            });
            setIsOnboarding(true);
        }
      }
    } catch (e) {
      console.error('Error fetching profile', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchFullUserHistory = async () => {
      if (!userProfile) return;
      setLoadingProfileData(true);
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', userProfile.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
          const mapped: Post[] = data.map((p: any) => ({
             id: p.id,
             userId: p.user_id,
             type: p.activity_type as CheckInType,
             imageUrl: p.image_url,
             caption: p.caption,
             timestamp: new Date(p.created_at).getTime(),
             reactions: p.reactions,
             milestoneKey: p.milestone_key,
             metrics: p.metrics,
             tags: p.tags,
             subActivity: p.sub_activity
          }));
          setFullPostHistory(mapped);
      }
      setLoadingProfileData(false);
  };

  const fetchUserMastery = async () => {
      if (!userProfile) return;
      const { data } = await supabase
        .from('user_milestones')
        .select('milestone_key')
        .eq('user_id', userProfile.id);
        
      if (data) {
          const keys = new Set<string>();
          data.forEach((d: any) => keys.add(d.milestone_key));
          setUnlockedMilestones(keys);
      }
  };

  const fetchPersonalGoals = async () => {
      if (!userProfile) return;
      const { data } = await supabase.from('goals').select('*').eq('user_id', userProfile.id);
      if (data) {
          const mapped: Goal[] = data.map((g: any) => ({
              id: g.id,
              userId: g.user_id,
              activityType: g.activity_type,
              frequency: g.frequency,
              targetCount: g.target_count,
              targetDays: g.target_days,
              subGoal: g.sub_goal,
              metricTarget: g.metric_target,
              title: g.title,
              currentStreak: g.current_streak,
              lastCompletedPeriod: g.last_completed_period,
              progress: 0 
          }));
          setPersonalGoals(mapped);
      }
  }

  const completeOnboarding = async () => {
      if (!userProfile) return;
      await supabase.from('profiles').update({ onboarding_complete: true }).eq('id', userProfile.id);
      setIsOnboarding(false);
      showToast("Access Granted", "success");
      playSuccess();
  };

  const fetchUnreadCount = async () => {
      if (!userProfile) return;
      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userProfile.id)
        .eq('is_read', false);
      
      if (error) {
          if (error.code === '42P01') return; 
          console.error("Error fetching unread count", error);
          return;
      }
      setUnreadNotifications(count || 0);
  }

  const fetchActiveGoals = async () => {
      if (!userProfile) return;
      
      let query = supabase.from('goals').select('*');
      
      if (circles.length > 0) {
          const circleIds = circles.map(c => c.id).join(',');
          query = query.or(`user_id.eq.${userProfile.id},circle_id.in.(${circleIds})`);
      } else {
          query = query.eq('user_id', userProfile.id);
      }
      
      const { data: goals, error } = await query;

      if (error) {
          console.error("Error fetching goals", error);
          return;
      }
      
      if (!goals) return;
      
      const startOfWeek = new Date();
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
      startOfWeek.setHours(0,0,0,0);
      
      const startOfDay = new Date();
      startOfDay.setHours(0,0,0,0);
      
      const { data: posts } = await supabase
        .from('posts')
        .select('activity_type, created_at, circle_id, sub_activity, metrics')
        .eq('user_id', userProfile.id)
        .gte('created_at', startOfWeek.toISOString());
        
      if (!posts) return;

      const processedGoals: Goal[] = goals.map((g: any) => {
          let progress = 0;
          
          let effectiveStreak = g.current_streak || 0;
          if (g.frequency === 'DAILY') {
              const last = g.last_completed_period; 
              if (last) {
                  const lastDate = new Date(last);
                  const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
                  const yesterdayString = yesterday.toISOString().split('T')[0];
                  if (last < yesterdayString) effectiveStreak = 0; 
              } else {
                  effectiveStreak = 0;
              }
          }

          const relevantPosts = posts.filter((p: any) => {
             const matchesType = p.activity_type === g.activity_type;
             const matchesCircle = g.circle_id ? p.circle_id === g.circle_id : true;
             
             let matchesMetrics = true;
             if (g.metric_target) {
                 const targets = g.metric_target;
                 for (const key in targets) {
                     const postValue = parseFloat(p.metrics?.[key] || 0);
                     const targetValue = parseFloat(targets[key]);
                     if (postValue < targetValue) {
                         matchesMetrics = false;
                         break;
                     }
                 }
             }

             return matchesType && matchesCircle && matchesMetrics;
          });
          
          if (g.frequency === 'DAILY') {
             const todayPost = relevantPosts.find((p: any) => new Date(p.created_at) >= startOfDay);
             progress = todayPost ? 1 : 0;
          } else if (g.frequency === 'WEEKLY') {
             progress = relevantPosts.length;
          } else if (g.frequency === 'SPECIFIC_DAYS') {
              const hitDays = new Set(relevantPosts.map((p: any) => new Date(p.created_at).getDay()));
              progress = g.target_days.filter((d: number) => hitDays.has(d)).length;
          }

          return {
              id: g.id,
              userId: g.user_id,
              circleId: g.circle_id,
              activityType: g.activity_type,
              frequency: g.frequency,
              targetCount: g.frequency === 'DAILY' ? 1 : g.target_count,
              targetDays: g.target_days,
              progress,
              subGoal: g.sub_goal,
              metricTarget: g.metric_target,
              title: g.title,
              currentStreak: effectiveStreak,
              lastCompletedPeriod: g.last_completed_period
          };
      });
      
      setActiveGoals(processedGoals);
  }

  const fetchHeatmapAndStreak = async () => {
    if (!userProfile) return;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 27);

    const { data: posts } = await supabase
        .from('posts')
        .select('created_at')
        .eq('user_id', userProfile.id)
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: false });

    let freezeDates = new Set();
    try {
        const { data: freezes, error } = await supabase
            .from('streak_freezes')
            .select('freeze_date')
            .eq('user_id', userProfile.id)
            .gte('freeze_date', startDate.toISOString().split('T')[0]);
        
        if (!error && freezes) {
            freezeDates = new Set(freezes.map((f: any) => new Date(f.freeze_date).toDateString()));
        }
    } catch (e) {
        console.warn("Streak Freezes table missing");
    }

    const postDates = new Set(posts?.map((p: any) => new Date(p.created_at).toDateString()));
    const days: HeatmapDay[] = [];

    let currentStreak = 0;
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (postDates.has(today.toDateString())) {
        currentStreak++;
    }
    
    let checkDate = new Date(yesterday);
    let missingDateForRepair = null;

    while (true) {
        const dateStr = checkDate.toDateString();
        const isoDate = checkDate.toISOString().split('T')[0];

        if (postDates.has(dateStr) || freezeDates.has(dateStr)) {
            currentStreak++;
            checkDate.setDate(checkDate.getDate() - 1);
        } else {
            if (dateStr === today.toDateString()) {
                 checkDate.setDate(checkDate.getDate() - 1);
                 continue;
            }
            if (dateStr === yesterday.toDateString()) {
                missingDateForRepair = isoDate;
            }
            break;
        }
        if ((today.getTime() - checkDate.getTime()) / (1000 * 3600 * 24) > 365) break; 
    }
    
    if (missingDateForRepair && userProfile.freezeTokens > 0 && !freezeDates.has(yesterday.toDateString())) {
        setMissingDateToFreeze(missingDateForRepair);
        setIsFreezeModalOpen(true);
        playError(); 
    }

    if (currentStreak !== userProfile.streak) {
        await supabase.from('profiles').update({ streak: currentStreak }).eq('id', userProfile.id);
        setUserProfile(prev => prev ? { ...prev, streak: currentStreak } : null);
    }

    for (let i = 0; i < 28; i++) {
        const d = new Date(startDate);
        d.setDate(d.getDate() + i);
        const dStr = d.toDateString();
        
        const isFuture = d > new Date();
        const isToday = dStr === new Date().toDateString();
        const hasPost = postDates.has(dStr);
        // @ts-ignore
        const isFrozen = freezeDates.has(dStr);
        
        let status: HeatmapDay['status'] = isFuture ? 'future' : (hasPost ? 'completed' : isFrozen ? 'frozen' : 'missed');
        if (isToday && !hasPost) status = 'pending';

        days.push({
            date: d.toISOString(),
            status,
            intensity: hasPost ? 100 : 0
        });
    }

    setHeatmapData(days);
  };

  const handleUseFreeze = async () => {
      if (!userProfile || !missingDateToFreeze) return;
      playClick();
      try {
          const { error } = await supabase.from('streak_freezes').insert({
              user_id: userProfile.id,
              freeze_date: missingDateToFreeze
          });
          
          if (error) throw error;

          const newBalance = Math.max(0, userProfile.freezeTokens - 1);
          await supabase.from('profiles').update({ freeze_tokens: newBalance }).eq('id', userProfile.id);
          
          setUserProfile(prev => prev ? { ...prev, freezeTokens: newBalance } : null);
          
          showToast('Streak Repaired', 'success');
          playSuccess();
          setIsFreezeModalOpen(false);
          fetchHeatmapAndStreak();

      } catch (e) {
          console.error(e);
          showToast('Failed to use token', 'error');
      }
  };

  const fetchCircles = async () => {
    if (!userProfile) return;

    const { data: memberships, error } = await supabase
      .from('circle_members')
      .select(`
        circle_id,
        circles (
          id,
          name,
          description,
          streak,
          theme,
          created_by,
          is_public,
          allowed_activity_types,
          image_url
        )
      `)
      .eq('user_id', userProfile.id);

    if (error) {
        console.error('Error fetching circles', error);
        return;
    }

    const startOfDay = new Date();
    startOfDay.setHours(0,0,0,0);
    const todayISO = startOfDay.toISOString();

    const circleIds = memberships.map((m: any) => m.circle_id);
    const postedTypesByCircle: Record<string, Set<CheckInType>> = {};
    let postedCircleIds = new Set();

    if (circleIds.length > 0) {
        const { data: myPosts } = await supabase
            .from('posts')
            .select('circle_id, activity_type')
            .eq('user_id', userProfile.id)
            .in('circle_id', circleIds)
            .gte('created_at', todayISO);
        
        if (myPosts) {
            myPosts.forEach((p: any) => {
                postedCircleIds.add(p.circle_id);
                if (!postedTypesByCircle[p.circle_id]) {
                    postedTypesByCircle[p.circle_id] = new Set();
                }
                postedTypesByCircle[p.circle_id].add(p.activity_type as CheckInType);
            });
        }
    }

    const loadedCircles: Circle[] = (memberships || []).map((m: any) => ({
      id: m.circles.id,
      name: m.circles.name,
      description: m.circles.description || '',
      memberCount: 0,
      activeCount: 0,
      hasUserPostedToday: postedCircleIds.has(m.circles.id),
      unlockedTypes: Array.from(postedTypesByCircle[m.circles.id] || []),
      streak: m.circles.streak || 0,
      posts: [],
      theme: m.circles.theme || '#10b981',
      createdBy: m.circles.created_by,
      isPublic: m.circles.is_public || false,
      allowedTypes: m.circles.allowed_activity_types || null,
      imageUrl: m.circles.image_url || null
    }));

    setCircles(loadedCircles);
  };

  const fetchFeed = async (circleId: string) => {
      if (!userProfile) return;

      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

      const { data: postsData, error } = await supabase
        .from('posts')
        .select(`
            *,
            user:profiles(username, avatar_url)
        `)
        .eq('circle_id', circleId)
        .gte('created_at', twentyFourHoursAgo)
        .order('created_at', { ascending: false });

      if (error || !postsData) return;

      const postIds = postsData.map(p => p.id);
      let likedPostIds = new Set();
      let savedPostIds = new Set();
      let flaggedPostIds = new Set();
      let flagCounts: Record<string, number> = {};
      
      if (postIds.length > 0) {
          const { data: myLikes } = await supabase
            .from('post_likes')
            .select('post_id')
            .eq('user_id', userProfile.id)
            .in('post_id', postIds);
        
          if (myLikes) {
            myLikes.forEach((l: any) => likedPostIds.add(l.post_id));
          }

          const { data: hof } = await supabase
             .from('hall_of_fame')
             .select('post_id')
             .in('post_id', postIds)
             .eq('circle_id', circleId);
             
           if (hof) {
               hof.forEach((h: any) => savedPostIds.add(h.post_id));
           }

           const { data: flags } = await supabase
              .from('post_flags')
              .select('post_id, user_id')
              .in('post_id', postIds);
            
           if (flags) {
               flags.forEach((f: any) => {
                   flagCounts[f.post_id] = (flagCounts[f.post_id] || 0) + 1;
                   if (f.user_id === userProfile.id) flaggedPostIds.add(f.post_id);
               });
           }
      }

      const formattedPosts: Post[] = postsData.map((p: any) => ({
          id: p.id,
          userId: p.user_id,
          type: p.activity_type as CheckInType,
          subActivity: p.sub_activity,
          imageUrl: p.image_url,
          caption: p.caption || '',
          timestamp: new Date(p.created_at).getTime(),
          reactions: p.reactions || 0,
          isLikedByCurrentUser: likedPostIds.has(p.id),
          isInHallOfFame: savedPostIds.has(p.id),
          isFlaggedByCurrentUser: flaggedPostIds.has(p.id),
          flagCount: flagCounts[p.id] || 0,
          milestoneKey: p.milestone_key,
          tags: p.tags,
          metrics: p.metrics,
          user: p.user
      }));

      setCircles(prev => prev.map(c => 
          c.id === circleId ? { ...c, posts: formattedPosts } : c
      ));
  };

  const fetchPublicCircles = async () => {
      if (!userProfile) return;
      const myCircleIds = circles.map(c => c.id);
      const { data, error } = await supabase
        .from('circles')
        .select('*')
        .eq('is_public', true)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
          console.error("Error fetching public circles", error);
          return;
      }

      if (data) {
          const available = data.filter((c: any) => !myCircleIds.includes(c.id));
          const mapped = available.map((c: any) => ({
              ...c,
              imageUrl: c.image_url
          }));
          setPublicCircles(mapped);
      }
  };

  const handleCreateCircle = async (name: string, description: string, theme: string, isPublic: boolean, allowedTypes: CheckInType[], imageFile: File | null) => {
    if (!userProfile) return;
    
    playClick();
    let imageUrl = null;
    if (imageFile) {
        try {
            const compressedFile = await compressImage(imageFile);
            
            // Standard path, No Upsert.
            const timestamp = Date.now();
            const fileName = `${userProfile.id}/${timestamp}_circle.jpg`;
            
            const { error: uploadError } = await supabase.storage
                .from('proof-images')
                .upload(fileName, compressedFile, { 
                    upsert: false, // Prevents RLS overwrites
                    contentType: 'image/jpeg' 
                });
            if (uploadError) throw uploadError;
            
            const { data: { publicUrl } } = supabase.storage
                .from('proof-images')
                .getPublicUrl(fileName);
            imageUrl = publicUrl;
        } catch (e: any) {
            console.error('Error uploading circle image:', e.message || e);
            const errorMsg = e.message || 'Unknown Error';
            showToast(`Image upload failed: ${errorMsg}`, 'error');
        }
    }
    
    const { data: circleData, error } = await supabase
        .from('circles')
        .insert({ 
            name, 
            description, 
            theme, 
            created_by: userProfile.id, 
            is_public: isPublic,
            allowed_activity_types: allowedTypes,
            image_url: imageUrl
        })
        .select()
        .single();
    
    if (error || !circleData) {
        console.error('Create circle error:', error);
        showToast('Failed to create circle', 'error');
        return;
    }

    await supabase.from('circle_members').insert({
        circle_id: circleData.id,
        user_id: userProfile.id
    });

    fetchCircles();
    showToast('Circle Initialized', 'success');
    playSuccess();
  };

  const handleUpdateCircle = async (circleId: string, updates: { name: string; description: string; theme: string; is_public: boolean; allowed_activity_types: CheckInType[] }, imageFile: File | null) => {
    if (!userProfile) return;
    playClick();
    
    let imageUrlUpdate = {};
    if (imageFile) {
        try {
            const compressedFile = await compressImage(imageFile);
            
            // Standard path, No Upsert.
            const timestamp = Date.now();
            const fileName = `${userProfile.id}/${timestamp}_circle.jpg`;
            
            const { error: uploadError } = await supabase.storage
                .from('proof-images')
                .upload(fileName, compressedFile, { 
                    upsert: false,
                    contentType: 'image/jpeg' 
                });
            if (uploadError) throw uploadError;
            
            const { data: { publicUrl } } = supabase.storage
                .from('proof-images')
                .getPublicUrl(fileName);
            imageUrlUpdate = { image_url: publicUrl };
        } catch (e: any) {
            console.error('Image update failed:', e.message || e);
            const errorMsg = e.message || 'Unknown Error';
            showToast(`Image update failed: ${errorMsg}`, 'error');
        }
    }
    
    const { error } = await supabase
        .from('circles')
        .update({ 
            name: updates.name,
            description: updates.description,
            theme: updates.theme,
            is_public: updates.is_public,
            allowed_activity_types: updates.allowed_activity_types,
            ...imageUrlUpdate
        })
        .eq('id', circleId);
        
    if (error) {
        console.error('Update circle error:', error);
        showToast('Failed to update circle', 'error');
        return;
    }
    
    setCircles(prev => prev.map(c => c.id === circleId ? { 
        ...c, 
        name: updates.name, 
        description: updates.description, 
        theme: updates.theme,
        isPublic: updates.is_public,
        allowedTypes: updates.allowed_activity_types,
        imageUrl: (imageUrlUpdate as any).image_url || c.imageUrl
    } : c));
    
    showToast('Protocols Updated', 'success');
  };

  const handleJoinCircle = async (code: string) => {
      if (!userProfile) return;
      playClick();
      const { error } = await supabase.from('circle_members').insert({
          circle_id: code,
          user_id: userProfile.id
      });
      if (error) throw error;
      fetchCircles();
      showToast('Welcome to the Squad', 'success');
      playSuccess();
      setInviteCode(''); // Clear after success
  };

  const handleJoinPublic = async (circleId: string) => {
      if (!userProfile) return;
      playClick();
      setJoiningPublicId(circleId);
      try {
          await handleJoinCircle(circleId);
          setPublicCircles(prev => prev.filter(c => c.id !== circleId));
          setActiveTab('dash');
      } catch (e) {
          showToast('Failed to join circle', 'error');
      } finally {
          setJoiningPublicId(null);
      }
  };

  const handleKickMember = async (userIdToKick: string) => {
      if (!selectedCircleId) return;
      const { error } = await supabase
        .from('circle_members')
        .delete()
        .match({ circle_id: selectedCircleId, user_id: userIdToKick });
      if (error) throw error;
  };

  const handleDeleteCircle = async () => {
      if (!selectedCircleId) return;
      const { error } = await supabase.from('circles').delete().eq('id', selectedCircleId);
      if (error) {
          showToast('Delete failed', 'error');
          return;
      }
      showToast('Circle Terminated', 'neutral');
      setCircles(prev => prev.filter(c => c.id !== selectedCircleId));
      setSelectedCircleId(null);
      setIsMembersModalOpen(false);
      setActiveTab('dash');
  };

  const handleCheckIn = async (file: File | null, type: CheckInType, caption: string, _manualMilestoneKey?: string, subActivity?: string, targetCircleId?: string, tags?: string[], metrics?: Record<string, any>, goalId?: string) => {
    if (!userProfile || !file) {
        if (!file) showToast("Proof Image Required", "error");
        return;
    }
    // Size check (e.g. 0 byte files)
    if (file.size === 0) {
        showToast("Invalid Image: File is empty.", "error");
        return;
    }

    playClick();

    const circleIdToUse = targetCircleId || selectedCircleId;
    if (!circleIdToUse) {
        showToast('No Circle Selected', 'error');
        return;
    }

    try {
        let goalAchieved = false;
        let matchingGoal: Goal | undefined;
        
        // Find matching goal if not explicitly passed
        if (goalId) {
            matchingGoal = activeGoals.find(g => g.id === goalId);
        } else {
            matchingGoal = activeGoals.find(g => g.circleId === circleIdToUse && g.activityType === type);
        }
        
        if (matchingGoal) {
            if (matchingGoal.metricTarget && metrics) {
                const targets = matchingGoal.metricTarget;
                for (const key in targets) {
                    const postValue = parseFloat(metrics[key] || 0);
                    const targetValue = targets[key];
                    const label = HABIT_CONFIG[type].metrics.find(m => m.key === key)?.label || key;

                    if (postValue < targetValue) {
                        showToast(`STANDARD NOT MET: ${label} must be ${targetValue}`, 'error');
                        return;
                    }
                }
            }
            
            const currentProgress = matchingGoal.progress || 0;
            const newProgress = currentProgress + 1;
            const isCompletedNow = newProgress >= matchingGoal.targetCount;
            const wasCompletedBefore = currentProgress >= matchingGoal.targetCount;
            
            if (isCompletedNow && !wasCompletedBefore) {
                goalAchieved = true;
                const now = new Date();
                let currentPeriod = '';
                if (matchingGoal.frequency === 'DAILY') {
                    currentPeriod = now.toISOString().split('T')[0];
                } else if (matchingGoal.frequency === 'WEEKLY') {
                    const startOfYear = new Date(now.getFullYear(), 0, 1);
                    const days = Math.floor((now.valueOf() - startOfYear.valueOf()) / 86400000);
                    const weekNum = Math.ceil((days + startOfYear.getDay() + 1) / 7);
                    currentPeriod = `${now.getFullYear()}-W${weekNum}`;
                }
                
                if (matchingGoal.lastCompletedPeriod !== currentPeriod) {
                    const newStreak = (matchingGoal.currentStreak || 0) + 1;
                    await supabase.from('goals').update({
                        current_streak: newStreak,
                        last_completed_period: currentPeriod
                    }).eq('id', matchingGoal.id);
                }
            }
        }

        let earnedMilestones: string[] = [];
        let primaryMilestoneKey: string | undefined = undefined;
        
        // Wrap milestone logic in try-catch to not block upload
        try {
            if (tags || metrics) {
                earnedMilestones = await calculateEarnedMilestones({
                    type,
                    tags: tags || [],
                    metrics: metrics || {},
                    userId: userProfile.id
                });
                
                if (earnedMilestones.length > 0) {
                    const tracks = MASTERY_TRACKS[type] || [];
                    let maxLevel = 0;
                    earnedMilestones.forEach(key => {
                        const m = tracks.find(t => t.key === key);
                        if (m && m.level > maxLevel) {
                            maxLevel = m.level;
                            primaryMilestoneKey = key;
                        }
                    });
                }
            }
        } catch (milestoneError) {
            console.warn("Milestone calculation error", milestoneError);
        }

        // Sanitize Filename to prevent upload errors
        const originalExt = file.name.split('.').pop() || 'jpg';
        const fileExt = originalExt.replace(/[^a-zA-Z0-9]/g, ''); 
        const timestamp = Date.now();
        const randomString = Math.random().toString(36).substring(7);
        // Use user folder path and NO UPSERT
        const fileName = `${userProfile.id}/${timestamp}_proof_${randomString}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
            .from('proof-images')
            .upload(fileName, file, { 
                upsert: false, // Safer for RLS
                contentType: file.type || 'image/jpeg' 
            });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
            .from('proof-images')
            .getPublicUrl(fileName);

        const { error: insertError } = await supabase.from('posts').insert({
            circle_id: circleIdToUse,
            user_id: userProfile.id,
            image_url: publicUrl,
            caption,
            activity_type: type,
            milestone_key: primaryMilestoneKey || null,
            sub_activity: subActivity || null,
            tags: tags || [],
            metrics: metrics || {}
        });

        if (insertError) throw insertError;
        
        // Update User Streak
        const currentStreak = userProfile.streak + 1;
        if (currentStreak > 0 && currentStreak % 7 === 0) {
             const newTokens = (userProfile.freezeTokens || 0) + 1;
             await supabase.from('profiles').update({ freeze_tokens: newTokens }).eq('id', userProfile.id);
             setUserProfile(prev => prev ? { ...prev, freezeTokens: newTokens } : null);
             showToast('7 DAY STREAK: FREEZE TOKEN EARNED', 'success');
        }

        if (goalAchieved) {
            showToast('DIRECTIVE COMPLETE. STREAK EXTENDED.', 'success');
            playSuccess();
        } else if (earnedMilestones.length > 0) {
             const primaryLabel = getMilestone(type, primaryMilestoneKey || '')?.label;
             showToast(`ACHIEVEMENT UNLOCKED: ${primaryLabel}`, 'success');
             playUnlock();
        } else {
            showToast('Proof Verified. Fog Lifted.', 'success');
            playSuccess();
        }

        // Optimistically update circle state
        setCircles(prev => prev.map(c => {
            if (c.id === circleIdToUse) {
                const newUnlocked = new Set(c.unlockedTypes);
                newUnlocked.add(type);
                return { 
                    ...c, 
                    hasUserPostedToday: true, 
                    unlockedTypes: Array.from(newUnlocked) 
                };
            }
            return c;
        }));

        setIsCheckInOpen(false);
        setIsQuickCaptureOpen(false);
        
        await fetchCircles(); 
        await fetchHeatmapAndStreak(); 
        await fetchActiveGoals();
        
        if (activeTab === 'circle' && selectedCircleId === circleIdToUse) {
            await fetchFeed(circleIdToUse);
        }
        if (activeTab === 'profile') {
            await fetchFullUserHistory();
            await fetchUserMastery();
        }

    } catch (e: any) {
        console.error('Check-in failed', e);
        
        // Robust Error Parsing to prevent [object Object] toast
        let errorMsg = 'Unknown Error';
        try {
            if (typeof e === 'string') {
                errorMsg = e;
            } else if (e instanceof Error) {
                errorMsg = e.message;
            } else if (e && typeof e === 'object') {
                // Handle Supabase/Postgrest Error Shapes
                errorMsg = e.message || e.error_description || (e.error && e.error.message) || JSON.stringify(e);
            }
        } catch (parseError) {
            errorMsg = "Critical Upload Failure";
        }

        showToast(`Upload Failed: ${errorMsg}`, 'error');
    }
  };

  const handleDeletePost = async (postId: string) => {
    playClick();
    const { error } = await supabase.from('posts').delete().eq('id', postId);
    if (error) {
        showToast('Failed to delete proof', 'error');
        return;
    }
    if (selectedCircleId) {
        setCircles(prev => prev.map(c => {
            if (c.id === selectedCircleId) {
                return { ...c, posts: c.posts.filter(p => p.id !== postId) };
            }
            return c;
        }));
    }
    fetchHeatmapAndStreak();
    fetchCircles();
    showToast('Proof Deleted', 'neutral');
  };

  const handleFlagPost = async (post: Post) => {
      if (!userProfile) return;
      playClick();
      const { error } = await supabase.from('post_flags').insert({
          user_id: userProfile.id,
          post_id: post.id
      });
      if (error) {
          showToast('Already flagged', 'error');
          return;
      }
      
      try {
          await supabase.from('notifications').insert({
              user_id: post.userId,
              actor_id: userProfile.id,
              type: 'FLAG',
              content: 'Your proof has been contested.',
              related_entity_id: post.id
          });
      } catch (e) {
          console.warn("Notification failed", e);
      }

      if (selectedCircleId) {
          setCircles(prev => prev.map(c => c.id === selectedCircleId ? {
              ...c,
              posts: c.posts.map(p => p.id === post.id ? { 
                  ...p, 
                  isFlaggedByCurrentUser: true,
                  flagCount: (p.flagCount || 0) + 1
              } : p)
          } : c));
      }
      showToast('Flagged as Suspect', 'neutral');
  };

  const handlePardonPost = async (post: Post) => {
      playClick();
      const { error } = await supabase.from('post_flags').delete().eq('post_id', post.id);
      if (error) {
          showToast('Failed to pardon', 'error');
          return;
      }
      if (selectedCircleId) {
          setCircles(prev => prev.map(c => c.id === selectedCircleId ? {
              ...c,
              posts: c.posts.map(p => p.id === post.id ? { 
                  ...p, 
                  isFlaggedByCurrentUser: false,
                  flagCount: 0
              } : p)
          } : c));
      }
      showToast('Proof Verified by Admin', 'success');
  }

  const handleToggleHallOfFame = async (post: Post) => {
      if (!userProfile || !selectedCircleId) return;
      playClick();
      const isCurrentlySaved = post.isInHallOfFame;
      setCircles(prev => prev.map(c => {
          if (c.id === selectedCircleId) {
              return {
                  ...c,
                  posts: c.posts.map(p => p.id === post.id ? { ...p, isInHallOfFame: !isCurrentlySaved } : p)
              };
          }
          return c;
      }));

      try {
          if (!isCurrentlySaved) {
              const { error } = await supabase.from('hall_of_fame').insert({
                  circle_id: selectedCircleId,
                  post_id: post.id,
                  saved_by: userProfile.id
              });
              if (error) throw error;
              showToast('Saved to Hall of Fame', 'success');
          } else {
               const { error } = await supabase.from('hall_of_fame').delete().match({
                   circle_id: selectedCircleId,
                   post_id: post.id
               });
               if (error) throw error;
               showToast('Removed from Hall of Fame', 'neutral');
          }
      } catch (e) {
          console.error('HOF Toggle Error', e);
          showToast('Failed to update Hall of Fame', 'error');
          fetchFeed(selectedCircleId);
      }
  };

  const handleUpdateProfile = async (username: string, avatarUrl: string) => {
    if (!userProfile) return;
    const { error } = await supabase
      .from('profiles')
      .update({ username, avatar_url: avatarUrl })
      .eq('id', userProfile.id);
    if (error) throw error;
    setUserProfile(prev => prev ? { ...prev, username, avatarUrl } : null);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUserProfile(null);
    showToast('Signed Out', 'neutral');
  };

  const handleDeleteAccount = async () => {
      if (!userProfile) return;
      const { error } = await supabase.from('profiles').delete().eq('id', userProfile.id);
      if (error) {
          showToast('Delete failed. Contact support.', 'error');
      } else {
          await supabase.auth.signOut();
          setSession(null);
          setUserProfile(null);
          alert('Account Deleted');
      }
  };

  const handleCircleClick = (circleId: string) => {
      playClick();
      setSelectedCircleId(circleId);
      setActiveTab('circle'); 
      // Default to 'feed' but you can default to 'mission' if preferred
      setCircleViewMode('feed'); 
      setFeedFilter('ALL'); 
      const circle = circles.find(c => c.id === circleId);
      // Fetch feed regardless of posted status so we can potentially filter locked content
      fetchFeed(circleId);
  };

  const handleLeaveCircle = async () => {
      fetchCircles(); 
      setActiveTab('dash');
      setSelectedCircleId(null);
  }

  const handleReply = (username: string) => {
      playClick();
      setChatDraft(`@${username} `);
      setCircleViewMode('chat');
  };

  const handleDayClick = async (day: HeatmapDay) => {
      if (!userProfile || day.status !== 'completed') return;
      playClick();
      const date = new Date(day.date);
      const startOfDay = new Date(date); startOfDay.setHours(0,0,0,0);
      const endOfDay = new Date(date); endOfDay.setHours(23,59,59,999);
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', userProfile.id)
        .gte('created_at', startOfDay.toISOString())
        .lte('created_at', endOfDay.toISOString())
        .limit(1)
        .single();
      if (!error && data) {
          const post: Post = {
             id: data.id,
             userId: data.user_id,
             type: data.activity_type as CheckInType,
             subActivity: data.sub_activity,
             imageUrl: data.image_url,
             caption: data.caption,
             timestamp: new Date(data.created_at).getTime(),
             reactions: data.reactions,
             milestoneKey: data.milestone_key,
             tags: data.tags,
             metrics: data.metrics
          };
          setSelectedDayPost(post);
          setSelectedDay(day);
      }
  };

  const handleInitiateGovernance = async () => {
      if (!selectedCircleId) return;
      const { error } = await supabase.from('governance_sessions').insert({ circle_id: selectedCircleId });
      if (!error) {
          setIsGovernanceOpen(true);
          showToast("Council Session Started", 'success');
      } else {
          showToast("Failed to start session", 'error');
      }
  }

  // --- GOAL / DIRECTIVE MANAGEMENT ---

  const handleCreateGoal = async (goalData: Omit<Goal, 'id' | 'progress'>) => {
      if (editingGoal) {
          await handleUpdateGoal(editingGoal.id, goalData);
          return;
      }

      if (!userProfile) return;
      playClick();
      const { error } = await supabase.from('goals').insert({
          user_id: goalData.circleId ? null : userProfile.id,
          circle_id: goalData.circleId || null,
          activity_type: goalData.activityType,
          frequency: goalData.frequency,
          target_count: goalData.targetCount,
          target_days: goalData.targetDays,
          sub_goal: goalData.subGoal,
          metric_target: goalData.metricTarget,
          title: goalData.title
      });
      
      if (error) {
          console.error("Goal Creation Error:", error);
          showToast('Failed to set directive', 'error');
      } else {
          showToast('Directive Set', 'success');
          fetchActiveGoals();
          if (goalData.circleId === null) fetchPersonalGoals();
      }
  };

  const handleUpdateGoal = async (goalId: string, goalData: Omit<Goal, 'id' | 'progress'>) => {
      playClick();
      const { error } = await supabase.from('goals').update({
          activity_type: goalData.activityType,
          frequency: goalData.frequency,
          target_count: goalData.targetCount,
          target_days: goalData.targetDays,
          sub_goal: goalData.subGoal,
          metric_target: goalData.metricTarget,
          title: goalData.title
      }).eq('id', goalId);

      if (error) {
          console.error("Goal Update Error:", error);
          showToast('Failed to update directive', 'error');
      } else {
          showToast('Directive Updated', 'success');
          setEditingGoal(null); 
          fetchActiveGoals();
          fetchPersonalGoals();
      }
  };

  const handleDeleteGoal = async (id: string) => {
      if(!window.confirm("Abort this directive?")) return;
      playClick();
      const { error } = await supabase.from('goals').delete().eq('id', id);
      if (error) {
          console.error("Delete Goal Error:", error);
          showToast('Failed to delete directive. Check permissions.', 'error');
      } else {
          showToast('Directive Aborted', 'neutral');
          fetchActiveGoals(); 
          fetchPersonalGoals();
      }
  }

  const openEditGoal = (goal: Goal) => {
      playClick();
      setEditingGoal(goal);
      if (goal.circleId) {
          setIsCircleGoalModalOpen(true);
      } else {
          setIsPersonalGoalModalOpen(true);
      }
  };

  const selectedCircle = circles.find(c => c.id === selectedCircleId);
  const isSelectedCircleCreator = selectedCircle?.createdBy === userProfile?.id;
  const currentCircleGoals = selectedCircleId ? activeGoals.filter(g => g.circleId === selectedCircleId) : [];

  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center text-apex-primary font-mono text-xs tracking-widest animate-pulse">ESTABLISHING UPLINK...</div>;
  if (!session) return <Auth />;

  return (
    <div className="min-h-screen bg-black text-apex-text pb-safe-bottom pt-safe-top select-none">
      <InstallPrompt />
      
      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}

      {isOnboarding && (
        <OnboardingModal onComplete={completeOnboarding} />
      )}

      {/* VIEW: DASHBOARD */}
      {activeTab === 'dash' && (
        <div className="p-4 pt-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-black italic tracking-tighter text-white">APEX</h1>
              <p className="text-xs text-apex-muted font-mono uppercase tracking-widest">{userProfile?.username}</p>
            </div>
            <div className="flex gap-3">
                <button 
                    onClick={() => { playClick(); refreshAllData(); }}
                    className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-all active:scale-95"
                    title="Sync Data"
                >
                    <RefreshCw size={20} />
                </button>
                <button 
                    onClick={() => { playClick(); setIsNotificationCenterOpen(true); }}
                    className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-all active:scale-95 relative"
                >
                    <Bell size={20} />
                    {unreadNotifications > 0 && <div className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border border-black" />}
                </button>
                <button 
                    onClick={() => { playClick(); setIsLeaderboardOpen(true); }}
                    className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-yellow-500 hover:text-yellow-400 hover:border-yellow-500/50 transition-all active:scale-95 shadow-[0_0_15px_rgba(234,179,8,0.1)]"
                >
                    <Trophy size={20} />
                </button>
                <button 
                    onClick={() => { playClick(); setIsJoinCircleOpen(true); }}
                    className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition-all active:scale-95"
                >
                    <UserPlus size={20} />
                </button>
                <button 
                    onClick={() => { playClick(); setIsCreateCircleOpen(true); }}
                    className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-apex-primary hover:bg-apex-primary hover:text-black transition-all active:scale-95"
                >
                    <Plus size={20} />
                </button>
                <button 
                    onClick={() => setActiveTab('profile')}
                    className="w-10 h-10 rounded-full bg-zinc-800 overflow-hidden border border-zinc-700 active:scale-95 transition-transform"
                >
                    <img src={userProfile?.avatarUrl} alt="Me" className="w-full h-full object-cover" />
                </button>
            </div>
          </div>

          <DailyBrief />
          
          <div className="mb-8">
            <Heatmap days={heatmapData} onDayClick={handleDayClick} />
            <div className="mt-2 text-right">
                <span className="text-[10px] text-zinc-600 font-mono uppercase">Current Streak: <span className="text-white font-bold">{userProfile?.streak} DAYS</span></span>
            </div>
          </div>
          
          {activeGoals.filter(g => !g.circleId).length > 0 && (
              <div className="mb-8">
                  <div className="flex justify-between items-end mb-4">
                      <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-500">Active Directives</h2>
                  </div>
                  <div className="bg-zinc-900/30 border border-zinc-800 p-4 rounded-xl">
                      {activeGoals.filter(g => !g.circleId).map(goal => (
                          <GoalProgress key={goal.id} goal={goal} />
                      ))}
                  </div>
              </div>
          )}

          <div>
            <div className="flex justify-between items-end mb-4">
              <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-500">Your Circles</h2>
            </div>
            
            {circles.length === 0 ? (
                <div className="text-center py-16 border border-zinc-900 bg-zinc-900/20 rounded-xl relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-tr from-apex-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <ShieldCheck className="w-12 h-12 text-zinc-700 mx-auto mb-4 group-hover:text-apex-primary transition-colors duration-500" />
                    <h3 className="text-white font-bold mb-1">No Allegiances</h3>
                    <p className="text-zinc-500 text-xs mb-6">You are operating solo.</p>
                    <button onClick={() => { playClick(); setIsCreateCircleOpen(true); }} className="text-apex-primary text-xs font-bold uppercase tracking-widest hover:underline">
                        Initialize New Circle
                    </button>
                </div>
            ) : (
                circles.map(circle => (
                <CircleCard key={circle.id} circle={circle} onClick={() => handleCircleClick(circle.id)} />
                ))
            )}
          </div>
        </div>
      )}

      {/* VIEW: CIRCLE */}
      {activeTab === 'circle' && selectedCircle && (
        <div className="min-h-screen bg-black relative">
          <div className="sticky top-0 z-30 bg-black/95 backdrop-blur-md border-b border-zinc-800">
            <div className="p-4 pb-2 flex items-center justify-between">
                <div className="flex items-center gap-1">
                     <button onClick={() => { playClick(); setActiveTab('dash'); }} className="p-2 -ml-2 text-zinc-400 hover:text-white">
                        <ArrowLeft size={20} />
                    </button>
                    {isSunday && (
                        <button onClick={() => isSelectedCircleCreator ? handleInitiateGovernance() : setIsGovernanceOpen(true)} className="p-2 bg-white text-black rounded-full animate-pulse-border">
                            <Gavel size={16} />
                        </button>
                    )}
                </div>
               
                <div className="flex flex-col items-center">
                    {selectedCircle.imageUrl ? (
                        <div className="w-8 h-8 rounded-lg overflow-hidden border border-zinc-700 mb-1">
                             <img src={selectedCircle.imageUrl} className="w-full h-full object-cover" />
                        </div>
                    ) : null}
                    <h2 className="font-bold text-white text-sm" style={{color: selectedCircle.theme}}>{selectedCircle.name}</h2>
                    <div className="flex items-center justify-center gap-1.5 text-zinc-500">
                        <span className="text-[10px] font-mono font-bold uppercase">{selectedCircle.streak} Day Streak</span>
                    </div>
                </div>
                <button onClick={() => setIsMembersModalOpen(true)} className="p-2 -mr-2 text-zinc-400 hover:text-white">
                <MoreVertical size={20} />
                </button>
            </div>
            
            {/* NEW TAB BAR */}
            <div className="flex px-2 pb-0 w-full mt-2 gap-1 overflow-x-auto hide-scrollbar">
                <button 
                    onClick={() => { playClick(); setCircleViewMode('feed'); }}
                    className={`flex-1 min-w-[80px] pb-3 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${circleViewMode === 'feed' ? 'text-white border-apex-primary' : 'text-zinc-600 border-transparent hover:text-zinc-400'}`}
                >
                    Proof
                </button>
                <button 
                    onClick={() => { playClick(); setCircleViewMode('mission'); }}
                    className={`flex-1 min-w-[80px] pb-3 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${circleViewMode === 'mission' ? 'text-white border-apex-primary' : 'text-zinc-600 border-transparent hover:text-zinc-400'}`}
                >
                    Mission
                </button>
                <button 
                    onClick={() => { playClick(); setCircleViewMode('chat'); }}
                    className={`flex-1 min-w-[80px] pb-3 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${circleViewMode === 'chat' ? 'text-white border-apex-primary' : 'text-zinc-600 border-transparent hover:text-zinc-400'}`}
                >
                    Comms
                </button>
                <button 
                    onClick={() => { playClick(); setCircleViewMode('hof'); }}
                    className={`flex-1 min-w-[80px] pb-3 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${circleViewMode === 'hof' ? 'text-yellow-500 border-yellow-500' : 'text-zinc-600 border-transparent hover:text-zinc-400'}`}
                >
                    HOF
                </button>
            </div>
          </div>

          {/* Sub-Filters for Feed */}
          {circleViewMode === 'feed' && selectedCircle.unlockedTypes.length > 0 && (
             <div className="sticky top-[108px] z-20 bg-black/95 backdrop-blur py-3 border-b border-zinc-800 mb-2">
                 <div className="flex gap-2 overflow-x-auto hide-scrollbar px-4">
                    <button
                        onClick={() => { playClick(); setFeedFilter('ALL'); }}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase whitespace-nowrap border transition-all ${feedFilter === 'ALL' ? 'bg-white text-black border-white' : 'bg-zinc-900 text-zinc-500 border-zinc-800'}`}
                    >
                        All Activity
                    </button>
                    {Object.values(CheckInType).map(t => {
                        // Only show filter buttons if the type is allowed AND unlocked
                        if (selectedCircle.allowedTypes && !selectedCircle.allowedTypes.includes(t)) return null;
                        if (!selectedCircle.unlockedTypes.includes(t)) return null;

                        return (
                            <button
                                key={t}
                                onClick={() => { playClick(); setFeedFilter(t); }}
                                className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase whitespace-nowrap border transition-all ${feedFilter === t ? 'bg-apex-primary text-black border-apex-primary' : 'bg-zinc-900 text-zinc-500 border-zinc-800'}`}
                            >
                                {t.replace('_', ' ')}
                            </button>
                        );
                    })}
                 </div>
             </div>
          )}

          <div className="relative min-h-[calc(100vh-140px)]">
            
            {/* FEED VIEW */}
            {circleViewMode === 'feed' && (
                (() => {
                    const unlocked = selectedCircle.unlockedTypes || [];
                    const hasPostedAnything = unlocked.length > 0;

                    if (!hasPostedAnything) {
                        return <FogOfWar onCheckIn={() => setIsCheckInOpen(true)} />;
                    }

                    const visiblePosts = selectedCircle.posts?.filter(p => {
                        // Filter 1: Must be an unlocked type
                        if (!unlocked.includes(p.type)) return false;
                        // Filter 2: Must match user selection (All vs Specific)
                        if (feedFilter !== 'ALL' && p.type !== feedFilter) return false;
                        return true;
                    }) || [];
                    
                    const totalCirclePosts = selectedCircle.posts?.length || 0;
                    const hiddenPostsCount = totalCirclePosts - visiblePosts.length;

                    return (
                        <div className="p-4 pb-20 animate-in fade-in slide-in-from-bottom-2 duration-300">
                            
                            {/* Add "Post More" Button */}
                            <div className="mb-6">
                                <button 
                                    onClick={() => setIsCheckInOpen(true)}
                                    className="w-full py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-400 uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-all flex items-center justify-center gap-2"
                                >
                                    <Camera size={16} />
                                    Log Additional Proof
                                </button>
                            </div>

                            {visiblePosts.length > 0 ? (
                                visiblePosts.map(post => (
                                    <FeedPost 
                                        key={post.id} 
                                        post={post} 
                                        currentUserId={userProfile!.id}
                                        isCreator={isSelectedCircleCreator}
                                        onDelete={handleDeletePost}
                                        onReply={handleReply}
                                        onToggleHallOfFame={handleToggleHallOfFame}
                                        onFlag={handleFlagPost}
                                        onPardon={handlePardonPost}
                                    />
                                ))
                            ) : (
                                <div className="text-center py-20 text-zinc-600 font-mono text-xs uppercase">
                                    No proofs visible for this category.
                                </div>
                            )}
                            
                            {hiddenPostsCount > 0 && feedFilter === 'ALL' && (
                                <div className="mt-8 mb-8 p-4 bg-zinc-900/30 border border-dashed border-zinc-800 rounded-xl flex items-center justify-center gap-3">
                                    <Lock size={16} className="text-zinc-500" />
                                    <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                                        {hiddenPostsCount} Posts Locked
                                    </span>
                                </div>
                            )}
                        </div>
                    );
                })()
            )}
            
            {/* NEW: MISSION VIEW - ALWAYS VISIBLE */}
            {circleViewMode === 'mission' && (
                <div className="p-4 pb-20 animate-in fade-in slide-in-from-right-2 duration-300">
                    <div className="flex items-center gap-2 mb-6 px-1">
                        <ListChecks size={18} className="text-emerald-500" />
                        <h3 className="text-sm font-bold text-white uppercase tracking-widest">Active Directives</h3>
                    </div>

                    {currentCircleGoals.length > 0 ? (
                        <div className="space-y-3">
                            {currentCircleGoals.map(goal => (
                                <div key={goal.id} className="relative group bg-zinc-900/40 border border-zinc-800 p-4 rounded-xl transition-all hover:border-zinc-700">
                                    <GoalProgress goal={goal} />
                                    {/* Admin Controls - Always Visible on Mission Tab */}
                                    {isSelectedCircleCreator && (
                                        <div className="flex justify-end gap-2 mt-3 pt-3 border-t border-zinc-800/50">
                                            <button 
                                                onClick={(e) => { 
                                                    e.preventDefault();
                                                    openEditGoal(goal); 
                                                }} 
                                                className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-lg text-[10px] font-bold uppercase transition-colors"
                                            >
                                                <Edit2 size={12} /> Edit
                                            </button>
                                            <button 
                                                onClick={(e) => { 
                                                    e.preventDefault();
                                                    handleDeleteGoal(goal.id); 
                                                }} 
                                                className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-red-950/30 text-zinc-400 hover:text-red-500 rounded-lg text-[10px] font-bold uppercase transition-colors"
                                            >
                                                <Trash2 size={12} /> Delete
                                            </button>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 border border-dashed border-zinc-800 rounded-xl bg-zinc-900/20">
                            <Target size={24} className="mx-auto text-zinc-700 mb-3" />
                            <p className="text-zinc-500 text-xs">No active directives set.</p>
                        </div>
                    )}

                    {isSelectedCircleCreator && (
                        <div className="mt-6">
                            <button 
                                onClick={() => { playClick(); setEditingGoal(null); setIsCircleGoalModalOpen(true); }}
                                className="w-full py-4 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-zinc-400 uppercase font-bold hover:bg-zinc-800 hover:text-white hover:border-zinc-700 transition-all flex items-center justify-center gap-2 shadow-lg"
                            >
                                <Plus size={16} />
                                {currentCircleGoals.length > 0 ? 'Add Directive' : 'Initialize Directives'}
                            </button>
                        </div>
                    )}
                </div>
            )}

            {/* CHAT VIEW */}
            {circleViewMode === 'chat' && (
                <div className="animate-in fade-in slide-in-from-right-2 duration-300">
                    <ChatView circleId={selectedCircle.id} currentUserId={userProfile!.id} initialMessage={chatDraft} />
                </div>
            )}

            {/* HOF VIEW */}
            {circleViewMode === 'hof' && (
                !selectedCircle.hasUserPostedToday ? (
                    <FogOfWar onCheckIn={() => setIsCheckInOpen(true)} />
                ) : (
                    <div className="animate-in fade-in slide-in-from-right-2 duration-300">
                        <HallOfFameView circleId={selectedCircle.id} onPostClick={(post) => {
                            setSelectedDayPost(post);
                            setSelectedDay({ date: new Date(post.timestamp).toISOString(), status: 'completed', intensity: 100 });
                        }} />
                    </div>
                )
            )}
            
            {/* Background Blur if Locked (Only on Feed when completely locked) */}
            {selectedCircle.unlockedTypes.length === 0 && circleViewMode === 'feed' && (
                <div className="absolute inset-0 z-0 p-4 pb-20 blur-xl opacity-30 pointer-events-none">
                     {selectedCircle.posts?.map(post => (
                        <FeedPost key={post.id} post={post} currentUserId={userProfile!.id} />
                    ))}
                </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW: FIND */}
      {activeTab === 'find' && (
        <div className="p-4 pt-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-2xl font-black italic tracking-tighter text-white mb-6">FIND SQUAD</h1>
            <div className="text-center py-8 border border-zinc-800 rounded-xl bg-zinc-900/30 mb-8"><Users className="w-8 h-8 text-zinc-600 mx-auto mb-3" /><h3 className="text-white font-bold mb-1 text-sm">Have an Invite Code?</h3><button onClick={() => { playClick(); setIsJoinCircleOpen(true); }} className="mt-3 text-apex-primary text-xs font-bold uppercase tracking-widest hover:underline">Enter Code Manually</button></div>
            <div><h3 className="text-sm font-bold uppercase tracking-wider text-zinc-500 mb-4">Open Squads</h3>{publicCircles.length === 0 ? ( <div className="text-zinc-600 text-sm italic text-center py-12">No public squads found. <br /><button onClick={() => { playClick(); setIsCreateCircleOpen(true); }} className="text-zinc-400 hover:text-white underline mt-2">Initialize one.</button></div> ) : ( publicCircles.map(c => ( <PublicCircleCard key={c.id} id={c.id} name={c.name} description={c.description} theme={c.theme} imageUrl={c.imageUrl} onJoin={handleJoinPublic} joining={joiningPublicId === c.id} /> )) )}</div>
        </div>
      )}

      {/* VIEW: PROFILE */}
      {activeTab === 'profile' && userProfile && (
        <div className="min-h-screen">
            <ProfileView 
                user={userProfile} 
                allPosts={fullPostHistory}
                unlockedKeys={unlockedMilestones}
                goals={personalGoals}
                loadingData={loadingProfileData}
                onUpdateProfile={handleUpdateProfile} 
                onSignOut={handleSignOut} 
                onShowToast={showToast}
                onShowManifesto={() => setIsOnboarding(true)}
                onOpenGoalModal={() => setIsPersonalGoalModalOpen(true)}
                onOpenStats={() => setIsStatsOpen(true)}
                onOpenMastery={() => setIsMasteryOpen(true)}
                onDeleteGoal={handleDeleteGoal}
                onShowRankHelp={() => setIsRankHelpOpen(true)}
                onOpenSettings={() => setIsSettingsOpen(true)}
                onEditGoal={openEditGoal}
            />
            <div className="fixed bottom-24 left-1/2 -translate-x-1/2">
                <button 
                    onClick={() => { playClick(); setActiveTab('dash'); }}
                    className="bg-zinc-900 border border-zinc-800 text-zinc-400 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-all shadow-xl"
                >
                    Back to Base
                </button>
            </div>
        </div>
      )}

      {/* MODALS (HOISTED) */}
      {isCheckInOpen && ( <CheckInModal onClose={() => setIsCheckInOpen(false)} onSubmit={handleCheckIn} allowedTypes={selectedCircle?.allowedTypes} currentUserId={userProfile?.id} circles={circles} goals={activeGoals} /> )}
      {isQuickCaptureOpen && ( <CheckInModal onClose={() => setIsQuickCaptureOpen(false)} onSubmit={handleCheckIn} currentUserId={userProfile?.id} circles={circles} goals={activeGoals} /> )}
      {isCreateCircleOpen && ( <CreateCircleModal onClose={() => setIsCreateCircleOpen(false)} onSubmit={handleCreateCircle} /> )}
      {isJoinCircleOpen && ( <JoinCircleModal onClose={() => setIsJoinCircleOpen(false)} onSubmit={handleJoinCircle} initialCode={inviteCode} /> )}
      {isLeaderboardOpen && userProfile && ( <Leaderboard onClose={() => setIsLeaderboardOpen(false)} currentUserId={userProfile.id} /> )}
      {isMembersModalOpen && selectedCircleId && userProfile && ( <CircleMembersModal circleId={selectedCircleId} circleName={circles.find(c => c.id === selectedCircleId)?.name || ''} currentUserId={userProfile.id} isCreator={circles.find(c => c.id === selectedCircleId)?.createdBy === userProfile.id} onClose={() => setIsMembersModalOpen(false)} onLeave={handleLeaveCircle} onDeleteCircle={handleDeleteCircle} onKickMember={handleKickMember} onShowToast={showToast} onEditCircle={() => { setIsMembersModalOpen(false); setIsEditCircleOpen(true); }} /> )}
      {isEditCircleOpen && selectedCircle && ( <EditCircleModal circle={selectedCircle} onClose={() => setIsEditCircleOpen(false)} onSubmit={handleUpdateCircle} /> )}
      {isPersonalGoalModalOpen && ( <GoalModal onClose={() => { setIsPersonalGoalModalOpen(false); setEditingGoal(null); }} onSubmit={handleCreateGoal} initialGoal={editingGoal || undefined} /> )}
      {isCircleGoalModalOpen && selectedCircle && ( <GoalModal onClose={() => { setIsCircleGoalModalOpen(false); setEditingGoal(null); }} onSubmit={handleCreateGoal} circleId={selectedCircle.id} activityTypes={selectedCircle.allowedTypes || undefined} initialGoal={editingGoal || undefined} /> )}
      {selectedDay && ( <DayViewModal date={selectedDay.date} post={selectedDayPost} onClose={() => { setSelectedDay(null); setSelectedDayPost(null); }} /> )}
      {isGovernanceOpen && selectedCircleId && userProfile && ( <GovernanceModal circleId={selectedCircleId} currentUserId={userProfile.id} onClose={() => setIsGovernanceOpen(false)} /> )}
      {isRankHelpOpen && ( <RankHelpModal onClose={() => setIsRankHelpOpen(false)} /> )}
      {isFreezeModalOpen && userProfile && ( <FreezeModal tokenCount={userProfile.freezeTokens} onUseToken={handleUseFreeze} onDismiss={() => setIsFreezeModalOpen(false)} /> )}
      {isNotificationCenterOpen && userProfile && ( <NotificationCenter onClose={() => setIsNotificationCenterOpen(false)} currentUserId={userProfile.id} /> )}
      {isStatsOpen && ( <StatsModal posts={fullPostHistory} onClose={() => setIsStatsOpen(false)} /> )}
      {isMasteryOpen && ( <MasteryTreeModal unlockedKeys={unlockedMilestones} onClose={() => setIsMasteryOpen(false)} /> )}
      {isSettingsOpen && ( <SettingsModal onClose={() => setIsSettingsOpen(false)} onSignOut={handleSignOut} onDeleteAccount={handleDeleteAccount} /> )}

      {/* TAB BAR */}
      {activeTab !== 'circle' && (
        <div className="fixed bottom-0 left-0 right-0 bg-zinc-950 border-t border-zinc-900 p-4 pb-safe-bottom flex justify-around items-center z-40">
          <button onClick={() => { playClick(); setActiveTab('dash'); }} className={`flex flex-col items-center gap-1 transition-colors active:scale-90 duration-200 ${activeTab === 'dash' ? 'text-apex-primary' : 'text-zinc-600'}`}><LayoutDashboard size={20} /><span className="text-[10px] font-bold uppercase">Base</span></button>
          <button onClick={() => { playClick(); setActiveTab('find'); }} className={`flex flex-col items-center gap-1 transition-colors active:scale-90 duration-200 ${activeTab === 'find' ? 'text-apex-primary' : 'text-zinc-600'}`}><Users size={20} /><span className="text-[10px] font-bold uppercase">Find</span></button>
          <button onClick={() => { playClick(); setIsQuickCaptureOpen(true); }} className="flex flex-col items-center justify-center -mt-6"><div className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.3)] border-4 border-black active:scale-95 transition-transform"><Camera size={26} fill="currentColor" className="opacity-100" /></div><span className="text-[10px] font-bold uppercase text-white mt-1">Capture</span></button>
          <button onClick={() => { playClick(); setActiveTab('profile'); }} className={`flex flex-col items-center gap-1 transition-colors active:scale-90 duration-200 ${activeTab === 'profile' ? 'text-apex-primary' : 'text-zinc-600'}`}><UserIcon size={20} /><span className="text-[10px] font-bold uppercase">Profile</span></button>
        </div>
      )}
    </div>
  );
}

export default App;
