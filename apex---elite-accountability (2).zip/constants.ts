

import { Circle, CheckInType, User, HeatmapDay } from './types';

export const CURRENT_USER: User = {
  id: 'u1',
  username: 'Jared_Apex',
  avatarUrl: 'https://picsum.photos/seed/jared/200/200',
  streak: 12,
  freezeTokens: 2
};

export const MOCK_HEATMAP: HeatmapDay[] = Array.from({ length: 28 }).map((_, i) => {
    const isFuture = i > 20;
    const isToday = i === 20;
    const random = Math.random();
    let status: HeatmapDay['status'] = isFuture ? 'future' : (random > 0.3 ? 'completed' : 'missed');
    
    if (isToday) status = 'pending';

    return {
        date: new Date(Date.now() - (20 - i) * 86400000).toISOString(),
        status,
        intensity: status === 'completed' ? Math.floor(Math.random() * 50) + 50 : 0
    };
});

export const MOCK_CIRCLES: Circle[] = [
  {
    id: 'c1',
    name: 'The 5AM Club',
    description: 'Wake up. Attack. Win.',
    memberCount: 6,
    activeCount: 2,
    hasUserPostedToday: false,
    unlockedTypes: [],
    streak: 45,
    theme: '#10b981', // Emerald
    createdBy: 'u5',
    isPublic: true,
    allowedTypes: [CheckInType.EARLY_RISE, CheckInType.COLD_PLUNGE, CheckInType.MEDITATION],
    imageUrl: null,
    posts: [
      {
        id: 'p1',
        userId: 'u2',
        type: CheckInType.EARLY_RISE,
        imageUrl: 'https://picsum.photos/seed/gym1/600/800',
        caption: '0430 Check in.',
        timestamp: Date.now() - 3600000,
        reactions: 4
      },
      {
        id: 'p2',
        userId: 'u3',
        type: CheckInType.COLD_PLUNGE,
        imageUrl: 'https://picsum.photos/seed/meditate/600/800',
        caption: '3 mins at 38 degrees.',
        timestamp: Date.now() - 7200000,
        reactions: 2
      }
    ]
  },
  {
    id: 'c2',
    name: 'SaaS Founders',
    description: 'Ship code every single day.',
    memberCount: 4,
    activeCount: 4,
    hasUserPostedToday: true,
    unlockedTypes: [CheckInType.DEEP_WORK],
    streak: 12,
    theme: '#3b82f6', // Blue
    createdBy: 'u1',
    isPublic: false,
    allowedTypes: [CheckInType.DEEP_WORK],
    imageUrl: null,
    posts: [
      {
        id: 'p3',
        userId: 'u4',
        type: CheckInType.DEEP_WORK,
        imageUrl: 'https://picsum.photos/seed/code/600/800',
        caption: 'Deploying the new API.',
        timestamp: Date.now() - 1000000,
        reactions: 3
      },
       {
        id: 'p4',
        userId: 'u1',
        type: CheckInType.DEEP_WORK,
        imageUrl: 'https://picsum.photos/seed/screen/600/800',
        caption: 'Fixed the auth bug. We live.',
        timestamp: Date.now() - 500000,
        reactions: 5
      }
    ]
  }
];

export const TACTICAL_BRIEFS = [
  "Discipline is the bridge between goals and accomplishment.",
  "You are what you do, not what you say you'll do.",
  "The pain of discipline weighs ounces. The pain of regret weighs tons.",
  "Execute. There is no other path.",
  "No one is coming to save you.",
  "Comfort is the enemy of progress.",
  "Your potential is irrelevant. Your results are everything.",
  "Do it tired. Do it scared. Do it now.",
  "Standards define you.",
  "Momentum is created, not found.",
  "A river cuts through rock not because of its power, but its persistence.",
  "Don't wish it were easier. Wish you were better.",
  "Focus on the step in front of you, not the whole staircase.",
  "Your future is hidden in your daily routine."
];