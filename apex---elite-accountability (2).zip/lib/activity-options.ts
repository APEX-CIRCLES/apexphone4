
import { CheckInType } from "../types";

export const ACTIVITY_SUBTYPES: Record<CheckInType, string[]> = {
    [CheckInType.GYM]: [
        'Strength', 'Hypertrophy', 'Mobility', 'Cardio', 'Functional', 'CrossFit', 'Powerlifting', 'Calisthenics'
    ],
    [CheckInType.RUNNING]: [
        'Distance', 'Sprint', 'Zone 2', 'Tempo', 'Long Run', 'Intervals', 'Hill Run', 'Recovery'
    ],
    [CheckInType.READING]: [
        'Physical Book', 'Kindle/Digital', 'Audiobook', 'Study/Textbook', 'Research Paper'
    ],
    [CheckInType.MEDITATION]: [
        'Breathwork', 'Guided', 'Mindfulness', 'Visualization', 'Prayer', 'Transcendental'
    ],
    [CheckInType.EARLY_RISE]: [
        '4:30 AM', '5:00 AM', '5:30 AM', '6:00 AM', '6:30 AM', 'Custom'
    ],
    [CheckInType.STEPS]: [
        '5,000', '7,500', '10,000', '12,500', '15,000', '20,000+'
    ],
    [CheckInType.DIET]: [
        'Clean Eating', 'No Sugar', 'No Fast Food', 'High Protein', 'Calorie Target', 'Tracking', 'Keto', 'Paleo'
    ],
    [CheckInType.DEEP_WORK]: [
        '25m Pomodoro', '45m Focus', '60m Focus', '90m Deep Work', '2h+ Immersion', 'Flow State'
    ],
    [CheckInType.COLD_PLUNGE]: [
        '1 Minute', '2 Minutes', '3 Minutes', '5 Minutes', 'Custom'
    ],
    [CheckInType.FASTING]: [
        '16:8', '18:6', '20:4', '24h', '36h', '48h', 'OMAD'
    ],
    [CheckInType.JOURNALING]: [
        'Free Write', 'Gratitude', 'Reflection', 'Planning', 'Emotional', 'Prayer'
    ],
    [CheckInType.RUCKING]: [
        '1 Mile', '2 Miles', '3 Miles', '5 Miles', '10+ Miles', 'Custom'
    ]
};
