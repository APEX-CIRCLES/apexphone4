
import { CheckInType } from "../types";

export interface Milestone {
    key: string;
    label: string;
    level: number;
    description: string;
    category: 'CORE' | 'SIDE';
}

export const MASTERY_TRACKS: Record<CheckInType, Milestone[]> = {
    [CheckInType.GYM]: [
        // CORE: The Path of Iron (Volume & Consistency)
        { key: 'IRON_INITIATE', label: 'Iron Initiate', level: 1, description: 'Log your first 7 gym sessions.', category: 'CORE' },
        { key: 'GYM_RAT', label: 'Gym Rat', level: 2, description: 'Complete 20 gym sessions.', category: 'CORE' },
        { key: 'UNBROKEN_IRON', label: 'Unbroken Iron', level: 3, description: 'Maintain a 30-day streak of gym check-ins.', category: 'CORE' },
        { key: 'VOLUME_MONSTER', label: 'Volume Monster', level: 4, description: 'Log a total of 50,000 lbs lifted across all sessions.', category: 'CORE' },
        { key: 'PLATE_CLUB', label: 'Plate Club', level: 5, description: 'Log a major lift (Squat, Deadlift, Bench) of 315 lbs or more.', category: 'CORE' },
        { key: 'LEGENDARY_LIFTER', label: 'Legendary Lifter', level: 6, description: 'Log 100 total gym sessions.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'RECOVERY_KING', label: 'Recovery King', level: 1, description: 'Log 10 sessions tagged as Mobility or Recovery.', category: 'SIDE' },
        { key: 'BODYWEIGHT_BEAST', label: 'Bodyweight Beast', level: 2, description: 'Complete 100 pushups in a single session.', category: 'SIDE' },
        { key: 'HEAVY_HITTER', label: 'Heavy Hitter', level: 3, description: 'Log a session with RPE 10.', category: 'SIDE' },
    ],
    [CheckInType.RUNNING]: [
        // CORE: The Path of Distance
        { key: 'FIRST_FLIGHT', label: 'First Flight', level: 1, description: 'Complete your first run.', category: 'CORE' },
        { key: '5K_FINISHER', label: '5K Finisher', level: 2, description: 'Run at least 5km (3.1 miles) in a single session.', category: 'CORE' },
        { key: '10K_TITAN', label: '10K Titan', level: 3, description: 'Run at least 10km (6.2 miles) in a single session.', category: 'CORE' },
        { key: 'HALF_MARATHON', label: 'Half Marathon', level: 4, description: 'Run 13.1 miles (21.1km) in a single session.', category: 'CORE' },
        { key: 'MARATHON_MAN', label: 'Marathon Man', level: 5, description: 'Run 26.2 miles (42.2km) in a single session.', category: 'CORE' },
        { key: 'ULTRA_RUNNER', label: 'Ultra Runner', level: 6, description: 'Run 31+ miles (50km) in a single session.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'ROAD_WARRIOR', label: 'Road Warrior', level: 1, description: 'Log 100 miles of total running volume.', category: 'SIDE' },
        { key: 'ZONE_2_ZOMBIE', label: 'Zone 2 Zombie', level: 1, description: 'Complete 15 runs tagged as Zone 2.', category: 'SIDE' },
        { key: 'HILL_REAPER', label: 'Hill Reaper', level: 2, description: 'Complete 10 runs tagged as Hills.', category: 'SIDE' },
    ],
    [CheckInType.READING]: [
        // CORE: The Path of Wisdom
        { key: 'TURN_THE_PAGE', label: 'Turn The Page', level: 1, description: 'Log your first reading session.', category: 'CORE' },
        { key: 'CHAPTER_CHASER', label: 'Chapter Chaser', level: 2, description: 'Read a total of 100 pages.', category: 'CORE' },
        { key: 'BOOKWORM', label: 'Bookworm', level: 3, description: 'Read a total of 500 pages.', category: 'CORE' },
        { key: 'STACKED_SHELF', label: 'Stacked Shelf', level: 4, description: 'Read a total of 1,500 pages (Approx 5 books).', category: 'CORE' },
        { key: 'SCHOLAR', label: 'Scholar', level: 5, description: 'Read a total of 3,000 pages.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'SCRIPTURE_SOLID', label: 'Scripture Solid', level: 1, description: 'Log 30 sessions tagged as Scripture.', category: 'SIDE' },
        { key: 'STUDY_GRIND', label: 'Study Grind', level: 2, description: 'Log 20 sessions tagged as Study/Textbook.', category: 'SIDE' },
        { key: 'AUDIO_AUDIT', label: 'Audio Audit', level: 1, description: 'Log 10 Audiobook sessions.', category: 'SIDE' },
    ],
    [CheckInType.DEEP_WORK]: [
        // CORE: The Path of Focus
        { key: 'FIRST_BLOCK', label: 'First Block', level: 1, description: 'Complete a deep work session of at least 25 minutes.', category: 'CORE' },
        { key: 'FLOW_STATE', label: 'Flow State', level: 2, description: 'Log 3 sessions of 45+ minutes.', category: 'CORE' },
        { key: 'LASER_FOCUS', label: 'Laser Focus', level: 3, description: 'Log 7 consecutive days with at least 45 minutes of focus.', category: 'CORE' },
        { key: 'MONK_MODE', label: 'Monk Mode', level: 4, description: 'Log 30 days with sessions over 60 minutes.', category: 'CORE' },
        { key: 'DEEP_END', label: 'The Deep End', level: 5, description: 'Complete a single session lasting 4 hours (240 min).', category: 'CORE' },
        { key: 'MASTER_MIND', label: 'Master Mind', level: 6, description: 'Accumulate 10,000 minutes of deep work.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'CLOSER', label: 'Closer', level: 1, description: 'Log 10 sessions tagged as Business/Agency.', category: 'SIDE' },
        { key: 'CODE_GRINDER', label: 'Code Grinder', level: 2, description: 'Log 20 sessions tagged as Coding.', category: 'SIDE' },
    ],
    [CheckInType.MEDITATION]: [
        // CORE: The Path of Stillness
        { key: 'FIRST_BREATH', label: 'First Breath', level: 1, description: 'Log your first meditation session.', category: 'CORE' },
        { key: 'QUIET_MIND', label: 'Quiet Mind', level: 2, description: 'Complete 10 total meditation sessions.', category: 'CORE' },
        { key: 'STILL_MIND', label: 'Still Mind', level: 3, description: 'Meditate for 7 days in a row.', category: 'CORE' },
        { key: 'DEEP_DIVER', label: 'Deep Diver', level: 4, description: 'Complete a single session lasting 30 minutes or more.', category: 'CORE' },
        { key: 'ENLIGHTENED', label: 'Enlightened', level: 5, description: 'Complete 100 total meditation sessions.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'MORNING_MIND', label: 'Morning Mind', level: 1, description: 'Meditate before 8 AM for 5 days.', category: 'SIDE' },
        { key: 'PRAYERFUL', label: 'Prayerful', level: 2, description: 'Log 20 sessions tagged as Prayer.', category: 'SIDE' },
        { key: 'VISUAL_ARCHITECT', label: 'Visual Architect', level: 2, description: 'Log 20 sessions tagged as Visualization.', category: 'SIDE' },
    ],
    [CheckInType.COLD_PLUNGE]: [
        // CORE: The Path of Ice
        { key: 'FIRST_SHOCK', label: 'First Shock', level: 1, description: 'Survive your first cold exposure.', category: 'CORE' },
        { key: 'ICE_INITIATE', label: 'Ice Initiate', level: 2, description: 'Complete 7 sessions of at least 1 minute.', category: 'CORE' },
        { key: 'COLD_BLOODED', label: 'Cold Blooded', level: 3, description: 'Complete 14 sessions of at least 2 minutes.', category: 'CORE' },
        { key: 'GLACIER_BLOOD', label: 'Glacier Blood', level: 4, description: 'Complete 30 sessions of at least 2 minutes.', category: 'CORE' },
        { key: 'WARRIORS_BATH', label: 'Warrior\'s Bath', level: 5, description: 'Endure a single plunge of 5 minutes or more.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'MORNING_PLUNGE', label: 'Morning Plunge', level: 1, description: 'Complete 15 sessions tagged as Morning Reset.', category: 'SIDE' },
        { key: 'BELOW_50', label: 'Below 50°', level: 2, description: 'Log 10 sessions with water temperature below 50°F.', category: 'SIDE' },
    ],
    [CheckInType.EARLY_RISE]: [
        // CORE: The Path of Dawn
        { key: 'BEAT_THE_SUN', label: 'Beat The Sun', level: 1, description: 'Wake up before 6:00 AM for 7 days.', category: 'CORE' },
        { key: 'MORNING_GLORY', label: 'Morning Glory', level: 2, description: 'Wake up before 6:00 AM for 14 days.', category: 'CORE' },
        { key: 'CONSISTENT_CLOCK', label: 'Consistent Clock', level: 3, description: 'Wake up within a 30-minute window for 14 days.', category: 'CORE' },
        { key: 'DAWN_RAIDER', label: 'Dawn Raider', level: 4, description: 'Wake up before 6:00 AM for 30 days.', category: 'CORE' },
        { key: '5AM_CLUB', label: 'The 5AM Club', level: 5, description: 'Log 21 wake-ups at or before 5:00 AM.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'COLD_START', label: 'Cold Start', level: 1, description: 'Wake up and log a Gym or Plunge session before 7:00 AM 10 times.', category: 'SIDE' },
        { key: 'NO_SNOOZE', label: 'No Snooze', level: 2, description: 'Log an Early Rise 5 days in a row.', category: 'SIDE' },
    ],
    [CheckInType.FASTING]: [
        // CORE: The Path of Empty
        { key: 'FIRST_FAST', label: 'First Fast', level: 1, description: 'Complete your first fasting window.', category: 'CORE' },
        { key: 'WINDOW_WARRIOR', label: 'Window Warrior', level: 2, description: 'Hit your target fasting duration for 14 days.', category: 'CORE' },
        { key: 'METABOLIC_SHIFT', label: 'Metabolic Shift', level: 3, description: 'Complete 30 successful fasts.', category: 'CORE' },
        { key: 'IRON_GUT', label: 'Iron Gut', level: 4, description: 'Complete a single fast of 18 hours or more.', category: 'CORE' },
        { key: '24H_WALL', label: '24-Hour Wall', level: 5, description: 'Complete a single fast of 24 hours or more.', category: 'CORE' },
        { key: 'AUTOPHAGY_ACE', label: 'Autophagy Ace', level: 6, description: 'Complete a single fast of 36 hours or more.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'OMAD_SOLDIER', label: 'OMAD Soldier', level: 2, description: 'Complete 10 fasts tagged as OMAD.', category: 'SIDE' },
        { key: 'CUT_PHASE', label: 'Cut Phase', level: 2, description: 'Complete 21 fasts tagged as 16:8 or 18:6.', category: 'SIDE' },
    ],
    [CheckInType.STEPS]: [
        // CORE: The Path of Movement
        { key: 'FIRST_10K', label: 'First 10K', level: 1, description: 'Walk 10,000 steps in a single day.', category: 'CORE' },
        { key: 'ROAD_RAT', label: 'Road Rat', level: 2, description: 'Exceed your step target for 7 consecutive days.', category: 'CORE' },
        { key: 'PAVEMENT_POUNDER', label: 'Pavement Pounder', level: 3, description: 'Walk 15,000 steps in a single day.', category: 'CORE' },
        { key: 'STEP_GIANT', label: 'Step Giant', level: 4, description: 'Exceed your step target for 30 days.', category: 'CORE' },
        { key: 'MARATHON_FEET', label: 'Marathon Feet', level: 5, description: 'Accumulate 100,000 total steps.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'ERRAND_ASSASSIN', label: 'Errand Assassin', level: 1, description: 'Log 10 sessions tagged as Errands.', category: 'SIDE' },
        { key: 'TRAIL_WALKER', label: 'Trail Walker', level: 2, description: 'Log 10 sessions tagged as Hiking.', category: 'SIDE' },
    ],
    [CheckInType.JOURNALING]: [
        // CORE: The Path of Reflection
        { key: 'OPEN_PAGE', label: 'Open Page', level: 1, description: 'Log your first journal entry.', category: 'CORE' },
        { key: 'THOUGHT_STREAM', label: 'Thought Stream', level: 2, description: 'Log 7 journal entries.', category: 'CORE' },
        { key: 'CLARITY_SEEKER', label: 'Clarity Seeker', level: 3, description: 'Log 14 journal entries.', category: 'CORE' },
        { key: 'INK_FLOW', label: 'Ink Flow', level: 4, description: 'Journal every day for 30 days.', category: 'CORE' },
        { key: 'CHRONICLER', label: 'Chronicler', level: 5, description: 'Log 100 total journal entries.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'GRATITUDE_CHAIN', label: 'Gratitude Chain', level: 1, description: 'Log 14 entries tagged as Gratitude.', category: 'SIDE' },
        { key: 'MIND_DUMP', label: 'Mind Dump', level: 1, description: 'Log 7 entries tagged as Emotional Dump.', category: 'SIDE' },
        { key: 'PLANNER', label: 'Planner', level: 2, description: 'Log 21 entries tagged as Planning/Goals.', category: 'SIDE' },
    ],
    [CheckInType.RUCKING]: [
        // CORE: The Path of Load
        { key: 'FIRST_MARCH', label: 'First March', level: 1, description: 'Complete your first ruck.', category: 'CORE' },
        { key: 'HEAVY_CARRIER', label: 'Heavy Carrier', level: 2, description: 'Complete 10 total rucks.', category: 'CORE' },
        { key: 'WEIGHTED_WALKER', label: 'Weighted Walker', level: 3, description: 'Complete 10 rucks with at least 20lbs.', category: 'CORE' },
        { key: 'ENDURANCE_MARCH', label: 'Endurance March', level: 4, description: 'Ruck 5 miles or more in a single session.', category: 'CORE' },
        { key: 'BOOTS_AND_WEIGHT', label: 'Boots & Weight', level: 5, description: 'Complete 30 total rucking sessions.', category: 'CORE' },
        { key: 'SPECIAL_FORCES', label: 'Special Forces', level: 6, description: 'Ruck 12+ miles with 45+ lbs.', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'HILL_GRINDER', label: 'Hill Grinder', level: 2, description: 'Complete 10 rucks tagged as Hills.', category: 'SIDE' },
        { key: 'PACK_MULE', label: 'Pack Mule', level: 3, description: 'Complete 5 rucks with at least 40lbs.', category: 'SIDE' },
    ],
    [CheckInType.DIET]: [
        // CORE: The Path of Nutrition
        { key: 'DAY_ONE_DISCIPLINE', label: 'Day One Discipline', level: 1, description: 'Log your first clean eating day.', category: 'CORE' },
        { key: 'CLEAN_WEEK', label: 'Clean Week', level: 2, description: 'Log 7 consecutive days marked "On Plan".', category: 'CORE' },
        { key: 'DISCIPLINE_DOG', label: 'Discipline Dog', level: 3, description: 'Log 14 consecutive days marked "On Plan".', category: 'CORE' },
        { key: 'MACRO_MASTER', label: 'Macro Master', level: 4, description: 'Hit your protein and calorie targets for 21 days.', category: 'CORE' },
        { key: 'CLEAN_MONTH', label: 'Clean Month', level: 5, description: 'Log 30 consecutive days marked "On Plan".', category: 'CORE' },
        
        // SIDE QUESTS
        { key: 'SUGARLESS_STREAK', label: 'Sugarless Streak', level: 1, description: 'Log 14 days tagged as No Sugar.', category: 'SIDE' },
        { key: 'FAST_FOOD_FADE', label: 'Fast Food Fade', level: 2, description: 'Log 30 days tagged as No Fast Food.', category: 'SIDE' },
        { key: 'CUT_COMPLETE', label: 'Cut Complete', level: 3, description: 'Complete 30 days tagged as Cut/Deficit with 80% adherence.', category: 'SIDE' },
    ]
};

export const getMilestone = (type: CheckInType, key: string | null) => {
    if (!key) return null;
    return MASTERY_TRACKS[type]?.find(m => m.key === key);
}
