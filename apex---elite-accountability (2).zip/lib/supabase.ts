import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/database';

// ------------------------------------------------------------------
// CONFIGURATION
// Replace these with your project details from https://app.supabase.com
// ------------------------------------------------------------------
const SUPABASE_URL = 'https://rvzteurpejdceournglh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_RvbHnMMRBwVa19AbFjkYFQ_603xJid0';

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY);