
export type Rank = 'Unranked' | 'Initiate' | 'Operative' | 'Vanguard' | 'APEX';

export const getRank = (streak: number): Rank => {
  if (streak >= 30) return 'APEX';
  if (streak >= 14) return 'Vanguard';
  if (streak >= 7) return 'Operative';
  if (streak >= 3) return 'Initiate';
  return 'Unranked';
};

export const getRankColor = (rank: Rank): string => {
  switch (rank) {
    case 'APEX': return 'text-yellow-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]';
    case 'Vanguard': return 'text-red-500';
    case 'Operative': return 'text-emerald-500';
    case 'Initiate': return 'text-blue-500';
    default: return 'text-zinc-500';
  }
};

export const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 1200; 
                const MAX_HEIGHT = 1200;
                let width = img.width;
                let height = img.height;

                // Resize logic
                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                
                canvas.toBlob((blob) => {
                    if (blob) {
                        // Create new file as JPEG with a clean name
                        const timestamp = Date.now();
                        // Remove special chars from name to prevent S3/Storage errors
                        const cleanName = file.name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10);
                        const fileName = `img_${timestamp}_${cleanName}.jpg`;
                        
                        const newFile = new File([blob], fileName, {
                            type: 'image/jpeg',
                            lastModified: Date.now(),
                        });
                        resolve(newFile);
                    } else {
                        // Fallback
                        console.warn("Blob creation failed, using original");
                        resolve(file);
                    }
                }, 'image/jpeg', 0.8); // 80% quality
            };
            img.onerror = (err) => {
                console.warn("Image load failed, using original", err);
                resolve(file);
            };
        };
        reader.onerror = (err) => {
            console.warn("File read failed, using original", err);
            resolve(file);
        };
    });
};
