
import { CheckInType } from "../types";

export interface HabitSubGoal {
    label: string;
    targetMetric?: {
        key: string;
        label: string;
        suggested?: number;
    };
}

export interface MetricDefinition {
    key: string;
    label: string;
    unit?: string;
    type: 'number' | 'string' | 'time' | 'select';
    options?: string[]; // For select type
}

export interface HabitConfig {
    subGoals: HabitSubGoal[];
    tags: string[];
    metrics: MetricDefinition[];
}

export const HABIT_CONFIG: Record<CheckInType, HabitConfig> = {
    [CheckInType.GYM]: {
        subGoals: [
            { label: 'General Gym Goal' },
            { label: 'Strength Day', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 60 } },
            { label: 'Hypertrophy Day', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 45 } },
            { label: '100 Pushups', targetMetric: { key: 'reps', label: 'Reps', suggested: 100 } },
            { label: 'Mobility Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 20 } },
            { label: 'Conditioning / MetCon', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 20 } },
            { label: 'Custom Gym Goal' }
        ],
        tags: [
            'Strength', 'Hypertrophy', 'Mobility', 'Cardio', 'Conditioning', 'Recovery', 'Calisthenics', 'Functional / CrossFit'
        ],
        metrics: [
            { key: 'duration', label: 'Time', unit: 'min', type: 'number' },
            { key: 'sets', label: 'Sets', type: 'number' },
            { key: 'reps', label: 'Total Reps', type: 'number' },
            { key: 'weight', label: 'Max Weight', unit: 'lbs', type: 'number' },
            { key: 'rpe', label: 'RPE (1-10)', type: 'number' }
        ]
    },
    [CheckInType.RUNNING]: {
        subGoals: [
            { label: 'General Run' },
            { label: '1 Mile Run', targetMetric: { key: 'distance', label: 'Distance (mi)', suggested: 1 } },
            { label: '5K Run', targetMetric: { key: 'distance', label: 'Distance (km)', suggested: 5 } },
            { label: '10K Run', targetMetric: { key: 'distance', label: 'Distance (km)', suggested: 10 } },
            { label: 'Zone 2 Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 30 } },
            { label: 'Interval Session' },
            { label: 'Long Run', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 60 } },
            { label: 'Custom Run' }
        ],
        tags: [
            'Distance', 'Sprints', 'Zone 2', 'Tempo', 'Hills', 'Long Run', 'Track'
        ],
        metrics: [
            { key: 'distance', label: 'Distance', unit: 'mi', type: 'number' },
            { key: 'duration', label: 'Time', unit: 'min', type: 'number' },
            { key: 'pace', label: 'Avg Pace', unit: '/mi', type: 'string' },
            { key: 'elevation', label: 'Elevation', unit: 'ft', type: 'number' }
        ]
    },
    [CheckInType.READING]: {
        subGoals: [
            { label: 'General Reading' },
            { label: '10 Pages', targetMetric: { key: 'pages', label: 'Pages', suggested: 10 } },
            { label: '20 Pages', targetMetric: { key: 'pages', label: 'Pages', suggested: 20 } },
            { label: '1 Chapter', targetMetric: { key: 'chapters', label: 'Chapters', suggested: 1 } },
            { label: 'Scripture Block', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 15 } },
            { label: 'Study Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 30 } }
        ],
        tags: [
            'Nonfiction', 'Fiction', 'Scripture', 'Study / Textbook', 'Business', 'Self-Improvement', 'Audiobook'
        ],
        metrics: [
            { key: 'pages', label: 'Pages', type: 'number' },
            { key: 'duration', label: 'Time', unit: 'min', type: 'number' },
            { key: 'book', label: 'Book Title', type: 'string' }
        ]
    },
    [CheckInType.DEEP_WORK]: {
        subGoals: [
            { label: 'General Focus' },
            { label: 'Pomodoro Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 25 } },
            { label: 'Focus Block', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 45 } },
            { label: 'Monk Block', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 90 } },
            { label: 'Double Block', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 90 } }
        ],
        tags: [
            'Study', 'Writing', 'Coding', 'Business / Agency', 'Exam Prep', 'Creative'
        ],
        metrics: [
            { key: 'duration', label: 'Focus Time', unit: 'min', type: 'number' },
            { key: 'blocks', label: 'Blocks', type: 'number' },
            { key: 'project', label: 'Project Name', type: 'string' }
        ]
    },
    [CheckInType.MEDITATION]: {
        subGoals: [
            { label: 'General Session' },
            { label: 'Breathwork Block', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 10 } },
            { label: 'Mindfulness Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 15 } },
            { label: 'Prayer Session', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 10 } },
            { label: 'Visualization', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 10 } }
        ],
        tags: [
            'Breathwork', 'Mindfulness', 'Guided', 'Prayer', 'Visualization', 'Body Scan'
        ],
        metrics: [
            { key: 'duration', label: 'Duration', unit: 'min', type: 'number' },
            { key: 'type', label: 'Type', type: 'select', options: ['Guided', 'Unguided'] },
            { key: 'mood', label: 'Mood (1-5)', type: 'number' }
        ]
    },
    [CheckInType.COLD_PLUNGE]: {
        subGoals: [
            { label: 'General Plunge' },
            { label: '2-Min Plunge', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 2 } },
            { label: '3-Min Plunge', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 3 } },
            { label: '5-Min Warrior', targetMetric: { key: 'duration', label: 'Time (min)', suggested: 5 } },
            { label: 'Cold Shower' }
        ],
        tags: [
            'Ice Bath', 'Cold Shower', 'Lake / River', 'Post-Workout', 'Morning Reset'
        ],
        metrics: [
            { key: 'duration', label: 'Time', unit: 'min', type: 'number' },
            { key: 'temp', label: 'Temp', unit: '°F', type: 'number' }
        ]
    },
    [CheckInType.EARLY_RISE]: {
        subGoals: [
            { label: 'Wake Up' },
            { label: '6 AM Club', targetMetric: { key: 'wake_time', label: 'Time', suggested: 600 } },
            { label: '5 AM Club', targetMetric: { key: 'wake_time', label: 'Time', suggested: 500 } }
        ],
        tags: [
            '5 AM Club', 'Work Prep', 'Gym First', 'Study First', 'Spiritual First'
        ],
        metrics: [
            { key: 'wake_time', label: 'Wake Time', type: 'time' },
            { key: 'sleep', label: 'Hours Slept', type: 'number' }
        ]
    },
    [CheckInType.FASTING]: {
        subGoals: [
            { label: 'General Fast' },
            { label: '16:8', targetMetric: { key: 'hours', label: 'Hours', suggested: 16 } },
            { label: '18:6', targetMetric: { key: 'hours', label: 'Hours', suggested: 18 } },
            { label: '20:4', targetMetric: { key: 'hours', label: 'Hours', suggested: 20 } },
            { label: 'OMAD' },
            { label: '24-Hour Fast', targetMetric: { key: 'hours', label: 'Hours', suggested: 24 } }
        ],
        tags: [
            '16:8', '18:6', '20:4', 'OMAD', '24h+ Fast', 'Keto Support'
        ],
        metrics: [
            { key: 'hours', label: 'Hours Fasted', type: 'number' }
        ]
    },
    [CheckInType.STEPS]: {
        subGoals: [
            { label: 'Step Count' },
            { label: '10k Steps', targetMetric: { key: 'steps', label: 'Steps', suggested: 10000 } },
            { label: '15k Steps', targetMetric: { key: 'steps', label: 'Steps', suggested: 15000 } }
        ],
        tags: [
            'Walking', 'Hiking', 'Treadmill', 'Rucking', 'Errands'
        ],
        metrics: [
            { key: 'steps', label: 'Count', type: 'number' },
            { key: 'distance', label: 'Distance', unit: 'mi', type: 'number' }
        ]
    },
    [CheckInType.JOURNALING]: {
        subGoals: [
            { label: 'Journal Entry' },
            { label: 'Gratitude Entry' },
            { label: 'Daily Reflection' },
            { label: 'Planning Session' }
        ],
        tags: [
            'Gratitude', 'Reflection', 'Planning / Goals', 'Emotional Dump', 'Scripture / Spiritual', 'Wins of the Day'
        ],
        metrics: [
            { key: 'duration', label: 'Minutes', unit: 'min', type: 'number' },
            { key: 'words', label: 'Word Count', type: 'number' }
        ]
    },
    [CheckInType.RUCKING]: {
        subGoals: [
            { label: 'General Ruck' },
            { label: 'Short Ruck (1-2mi)' },
            { label: 'Endurance Ruck (5mi+)' },
            { label: 'Heavy Ruck (30lb+)' }
        ],
        tags: [
            'Light Load', 'Heavy Load', 'Endurance', 'Hills', 'Training'
        ],
        metrics: [
            { key: 'distance', label: 'Distance', unit: 'mi', type: 'number' },
            { key: 'weight', label: 'Pack Weight', unit: 'lbs', type: 'number' },
            { key: 'duration', label: 'Duration', unit: 'min', type: 'number' }
        ]
    },
    [CheckInType.DIET]: {
        subGoals: [
            { label: 'Healthy Day' },
            { label: 'Calorie Target' },
            { label: 'High Protein' },
            { label: 'No Sugar' },
            { label: 'No Fast Food' },
            { label: 'Cut / Deficit' }
        ],
        tags: [
            'No Sugar', 'No Fast Food', 'High Protein', 'Calorie Target', 'Keto', 'Clean Eating', 'Bulk', 'Cut'
        ],
        metrics: [
            { key: 'calories', label: 'Calories', type: 'number' },
            { key: 'protein', label: 'Protein', unit: 'g', type: 'number' },
            { key: 'adherence', label: 'On Plan?', type: 'select', options: ['Yes', 'No'] }
        ]
    }
};
