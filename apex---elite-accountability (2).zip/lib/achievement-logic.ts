
import { CheckInType } from "../types";
import { supabase } from "./supabase";

// Define the shape of the check-in data
interface CheckInData {
    type: CheckInType;
    tags: string[];
    metrics: Record<string, any>;
    userId: string;
}

export const calculateEarnedMilestones = async (data: CheckInData): Promise<string[]> => {
    const earned: string[] = [];
    const { type, tags, metrics, userId } = data;

    // Helper to get count of previous posts of this type
    const getCount = async (activityType: CheckInType, tag?: string) => {
        let query = supabase
            .from('posts')
            .select('id', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('activity_type', activityType);
        
        if (tag) {
            query = query.contains('tags', [tag]);
        }
        
        const { count } = await query;
        return (count || 0) + 1; // +1 because we include the current one being posted
    };

    // Helper to check if a metric meets a threshold
    const checkMetric = (key: string, threshold: number, operator: '>' | '>=' | '<' | '<=' = '>=') => {
        const value = Number(metrics[key]);
        if (isNaN(value)) return false;
        if (operator === '>=') return value >= threshold;
        if (operator === '>') return value > threshold;
        if (operator === '<=') return value <= threshold;
        if (operator === '<') return value < threshold;
        return false;
    };

    // --- GYM LOGIC ---
    if (type === CheckInType.GYM) {
        const count = await getCount(CheckInType.GYM);
        if (count >= 7) earned.push('IRON_INITIATE');
        if (count >= 20) earned.push('GYM_RAT');
        if (count >= 100) earned.push('LEGENDARY_LIFTER');
        
        // Plate Club (315+ lbs)
        if (checkMetric('weight', 315)) earned.push('PLATE_CLUB');
        
        // Bodyweight Beast (100 Pushups)
        if (checkMetric('reps', 100)) earned.push('BODYWEIGHT_BEAST');
        
        // Heavy Hitter (RPE 10)
        if (checkMetric('rpe', 10)) earned.push('HEAVY_HITTER');

        // Recovery King (10 Mobility tags)
        if (tags.includes('Mobility') || tags.includes('Recovery')) {
            const recoveryCount = await getCount(CheckInType.GYM, 'Mobility'); // Simplified check
            if (recoveryCount >= 10) earned.push('RECOVERY_KING');
        }
    }

    // --- RUNNING LOGIC ---
    if (type === CheckInType.RUNNING) {
        const count = await getCount(CheckInType.RUNNING);
        if (count >= 1) earned.push('FIRST_FLIGHT');

        // Distances (Assuming miles or converted to miles)
        const dist = Number(metrics['distance'] || 0);
        
        if (dist >= 3.1) earned.push('5K_FINISHER');
        if (dist >= 6.2) earned.push('10K_TITAN');
        if (dist >= 13.1) earned.push('HALF_MARATHON');
        if (dist >= 26.2) earned.push('MARATHON_MAN');
        if (dist >= 31) earned.push('ULTRA_RUNNER');
        
        if (tags.includes('Hills')) {
            const hillCount = await getCount(CheckInType.RUNNING, 'Hills');
            if (hillCount >= 10) earned.push('HILL_REAPER');
        }
    }

    // --- READING LOGIC ---
    if (type === CheckInType.READING) {
        const count = await getCount(CheckInType.READING);
        if (count >= 1) earned.push('TURN_THE_PAGE');
        
        // Page counts are accumulative which is expensive for this MVP logic
        // We will approximate based on single session dumps or assume user integrity for now
        const pages = Number(metrics['pages'] || 0);
        
        if (tags.includes('Scripture')) {
             const scripCount = await getCount(CheckInType.READING, 'Scripture');
             if (scripCount >= 30) earned.push('SCRIPTURE_SOLID');
        }
        
        if (tags.includes('Study / Textbook')) {
            const studyCount = await getCount(CheckInType.READING, 'Study / Textbook');
            if (studyCount >= 20) earned.push('STUDY_GRIND');
        }
        
        if (tags.includes('Audiobook')) {
            const audioCount = await getCount(CheckInType.READING, 'Audiobook');
            if (audioCount >= 10) earned.push('AUDIO_AUDIT');
        }
    }

    // --- DEEP WORK LOGIC ---
    if (type === CheckInType.DEEP_WORK) {
        if (checkMetric('duration', 25)) earned.push('FIRST_BLOCK');
        if (checkMetric('duration', 45)) earned.push('FLOW_STATE'); // Simplified logic (1 session vs 3)
        if (checkMetric('duration', 240)) earned.push('DEEP_END');
        
        if (tags.includes('Business / Agency')) {
            const bizCount = await getCount(CheckInType.DEEP_WORK, 'Business / Agency');
            if (bizCount >= 10) earned.push('CLOSER');
        }
        
        if (tags.includes('Coding')) {
            const codeCount = await getCount(CheckInType.DEEP_WORK, 'Coding');
            if (codeCount >= 20) earned.push('CODE_GRINDER');
        }
    }

    // --- MEDITATION LOGIC ---
    if (type === CheckInType.MEDITATION) {
        const count = await getCount(CheckInType.MEDITATION);
        if (count >= 1) earned.push('FIRST_BREATH');
        if (count >= 10) earned.push('QUIET_MIND');
        if (count >= 100) earned.push('ENLIGHTENED');
        
        if (checkMetric('duration', 30)) earned.push('DEEP_DIVER');
        
        if (tags.includes('Prayer')) {
            const prayerCount = await getCount(CheckInType.MEDITATION, 'Prayer');
            if (prayerCount >= 20) earned.push('PRAYERFUL');
        }
        
        if (tags.includes('Visualization')) {
            const visCount = await getCount(CheckInType.MEDITATION, 'Visualization');
            if (visCount >= 20) earned.push('VISUAL_ARCHITECT');
        }
    }

    // --- COLD PLUNGE LOGIC ---
    if (type === CheckInType.COLD_PLUNGE) {
        const count = await getCount(CheckInType.COLD_PLUNGE);
        if (count >= 1) earned.push('FIRST_SHOCK');
        if (count >= 7) earned.push('ICE_INITIATE');
        if (count >= 14) earned.push('COLD_BLOODED');
        if (count >= 30) earned.push('GLACIER_BLOOD');
        
        if (checkMetric('duration', 5)) earned.push('WARRIORS_BATH');
        if (metrics['temp'] && checkMetric('temp', 50, '<')) earned.push('BELOW_50');
    }

    // --- EARLY RISE LOGIC ---
    if (type === CheckInType.EARLY_RISE) {
        // Time check is tricky with string inputs, assuming standard format HH:MM
        // For now, rely on sub-goal selection or tags
        if (tags.includes('5 AM Club')) earned.push('5AM_CLUB'); 
        if (tags.includes('Gym First')) earned.push('COLD_START'); 
        
        const count = await getCount(CheckInType.EARLY_RISE);
        if (count >= 14) earned.push('MORNING_GLORY');
    }

    // --- STEPS LOGIC ---
    if (type === CheckInType.STEPS) {
        if (checkMetric('steps', 10000)) earned.push('FIRST_10K');
        if (checkMetric('steps', 15000)) earned.push('PAVEMENT_POUNDER');
        
        if (tags.includes('Errands')) {
             const count = await getCount(CheckInType.STEPS, 'Errands');
             if (count >= 10) earned.push('ERRAND_ASSASSIN');
        }
    }

    // --- FASTING LOGIC ---
    if (type === CheckInType.FASTING) {
        const count = await getCount(CheckInType.FASTING);
        if (count >= 1) earned.push('FIRST_FAST');
        if (checkMetric('hours', 18)) earned.push('IRON_GUT');
        if (checkMetric('hours', 24)) earned.push('24H_WALL');
        if (checkMetric('hours', 36)) earned.push('AUTOPHAGY_ACE');
        
        if (tags.includes('OMAD')) {
            const omadCount = await getCount(CheckInType.FASTING, 'OMAD');
            if (omadCount >= 10) earned.push('OMAD_SOLDIER');
        }
    }

    // --- RUCKING LOGIC ---
    if (type === CheckInType.RUCKING) {
        const count = await getCount(CheckInType.RUCKING);
        if (count >= 1) earned.push('FIRST_MARCH');
        if (count >= 10) earned.push('HEAVY_CARRIER');
        
        if (checkMetric('weight', 20)) earned.push('WEIGHTED_WALKER');
        if (checkMetric('weight', 40)) earned.push('PACK_MULE');
        if (checkMetric('distance', 5)) earned.push('ENDURANCE_MARCH');
        if (checkMetric('distance', 12) && checkMetric('weight', 45)) earned.push('SPECIAL_FORCES');
    }
    
    // --- DIET LOGIC ---
    if (type === CheckInType.DIET) {
        const count = await getCount(CheckInType.DIET);
        if (count >= 1) earned.push('DAY_ONE_DISCIPLINE');
        
        // Advanced streak logic would go here (Clean Week, Clean Month)
        // For MVP, we'll trigger them on raw count + tag for now
        if (metrics['adherence'] === 'Yes') {
             // Simplified logic: If you have logged 7 "On Plan" meals, give Clean Week
             // Real app would check consecutive dates
             if (count >= 7) earned.push('CLEAN_WEEK');
             if (count >= 14) earned.push('DISCIPLINE_DOG');
             if (count >= 30) earned.push('CLEAN_MONTH');
        }
    }
    
    // --- JOURNALING LOGIC ---
    if (type === CheckInType.JOURNALING) {
        const count = await getCount(CheckInType.JOURNALING);
        if (count >= 1) earned.push('OPEN_PAGE');
        if (count >= 7) earned.push('THOUGHT_STREAM');
        if (count >= 14) earned.push('CLARITY_SEEKER');
        if (count >= 100) earned.push('CHRONICLER');
        
        if (tags.includes('Gratitude')) {
            const gCount = await getCount(CheckInType.JOURNALING, 'Gratitude');
            if (gCount >= 14) earned.push('GRATITUDE_CHAIN');
        }
    }

    // Filter out already earned milestones
    if (earned.length > 0) {
        const { data: existing } = await supabase
            .from('user_milestones')
            .select('milestone_key')
            .eq('user_id', userId)
            .in('milestone_key', earned);
            
        const existingKeys = new Set(existing?.map((e: any) => e.milestone_key) || []);
        return earned.filter(key => !existingKeys.has(key));
    }

    return [];
};
