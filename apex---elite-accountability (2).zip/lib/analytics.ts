
import { Post, CheckInType } from "../types";
import { HABIT_CONFIG } from "./habit-config";

export interface StatSummary {
    type: CheckInType;
    count: number;
    lastSession: number;
    metrics: Record<string, {
        total: number;
        max: number;
        avg: number;
        label: string;
        unit?: string;
    }>;
}

export const calculateStats = (posts: Post[]): Record<CheckInType, StatSummary> => {
    const stats: Record<string, StatSummary> = {};

    posts.forEach(post => {
        if (!stats[post.type]) {
            stats[post.type] = {
                type: post.type,
                count: 0,
                lastSession: 0,
                metrics: {}
            };
        }

        const summary = stats[post.type];
        summary.count++;
        if (post.timestamp > summary.lastSession) summary.lastSession = post.timestamp;

        // Process Metrics
        if (post.metrics) {
            const config = HABIT_CONFIG[post.type]?.metrics || [];
            
            Object.entries(post.metrics).forEach(([key, value]) => {
                const valNum = parseFloat(value as string);
                if (isNaN(valNum)) return;

                const metricDef = config.find(m => m.key === key);
                if (!metricDef || metricDef.type !== 'number') return; // Only agg numbers

                if (!summary.metrics[key]) {
                    summary.metrics[key] = {
                        total: 0,
                        max: 0,
                        avg: 0,
                        label: metricDef.label,
                        unit: metricDef.unit
                    };
                }

                const s = summary.metrics[key];
                s.total += valNum;
                if (valNum > s.max) s.max = valNum;
            });
        }
    });

    // Calculate Averages
    Object.values(stats).forEach(summary => {
        Object.values(summary.metrics).forEach(m => {
            m.avg = Math.round((m.total / summary.count) * 10) / 10;
        });
    });

    return stats as Record<CheckInType, StatSummary>;
};
