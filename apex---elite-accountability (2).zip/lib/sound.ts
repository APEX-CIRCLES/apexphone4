
// Web Audio API Synthesizer for UI Sounds
// No external assets required. Pure code.

let audioCtx: AudioContext | null = null;
let soundEnabled = true;
let hapticsEnabled = true;

export const initAudio = () => {
    if (!audioCtx && typeof window !== 'undefined') {
        audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
};

export const toggleSound = (enabled: boolean) => {
    soundEnabled = enabled;
    if (enabled) initAudio();
};

export const toggleHaptics = (enabled: boolean) => {
    hapticsEnabled = enabled;
};

const playTone = (freq: number, type: OscillatorType, duration: number, startTime: number = 0, vol: number = 0.02) => {
    if (!audioCtx || !soundEnabled) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime + startTime);
    
    // Smoother Envelope
    gain.gain.setValueAtTime(0, audioCtx.currentTime + startTime);
    gain.gain.linearRampToValueAtTime(vol, audioCtx.currentTime + startTime + 0.01); // Attack
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + startTime + duration); // Decay

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start(audioCtx.currentTime + startTime);
    osc.stop(audioCtx.currentTime + startTime + duration);
};

export const playClick = () => {
    if (!soundEnabled) return;
    if (hapticsEnabled && navigator.vibrate) navigator.vibrate(5);
    // Soft "Thock" sound (Sine wave, low frequency)
    playTone(300, 'sine', 0.05, 0, 0.05);
};

export const playSuccess = () => {
    if (!soundEnabled) return;
    if (hapticsEnabled && navigator.vibrate) navigator.vibrate([50, 50, 50]);
    // Soft Ascending Triad (Ethereal)
    const now = 0;
    playTone(440, 'sine', 0.3, now, 0.03);
    playTone(554, 'sine', 0.3, now + 0.05, 0.03);
    playTone(659, 'sine', 0.4, now + 0.1, 0.03);
};

export const playUnlock = () => {
    if (!soundEnabled) return;
    if (hapticsEnabled && navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 200]);
    // Major Chord Pad (Very soft)
    const now = 0;
    playTone(261.63, 'sine', 0.8, now, 0.04); // C4
    playTone(329.63, 'sine', 0.8, now + 0.05, 0.04); // E4
    playTone(392.00, 'sine', 0.8, now + 0.1, 0.04); // G4
    playTone(523.25, 'sine', 1.0, now + 0.15, 0.03); // C5
};

export const playError = () => {
    if (!soundEnabled) return;
    if (hapticsEnabled && navigator.vibrate) navigator.vibrate(200);
    // Soft Low Hum (Triangle wave, low freq)
    playTone(150, 'triangle', 0.2, 0, 0.04);
    playTone(100, 'triangle', 0.2, 0.05, 0.04);
};

export const triggerHaptic = (pattern: number | number[]) => {
    if (hapticsEnabled && navigator.vibrate) navigator.vibrate(pattern);
};
