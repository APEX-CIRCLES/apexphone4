

export enum CheckInType {
  GYM = 'GYM',
  RUNNING = 'RUNNING',
  READING = 'READING',
  DEEP_WORK = 'DEEP_WORK',
  MEDITATION = 'MEDITATION',
  COLD_PLUNGE = 'COLD_PLUNGE',
  EARLY_RISE = 'EARLY_RISE',
  FASTING = 'FASTING',
  STEPS = 'STEPS',
  JOURNALING = 'JOURNALING',
  DIET = 'DIET',
  RUCKING = 'RUCKING'
}

export interface User {
  id: string;
  username: string;
  avatarUrl: string;
  streak: number;
  freezeTokens: number;
}

export interface Post {
  id: string;
  userId: string;
  type: CheckInType;
  subActivity?: string | null;
  imageUrl: string;
  caption: string;
  timestamp: number;
  reactions: number;
  isLikedByCurrentUser?: boolean;
  isInHallOfFame?: boolean;
  isFlaggedByCurrentUser?: boolean;
  flagCount?: number;
  milestoneKey?: string | null;
  tags?: string[] | null;
  metrics?: Record<string, string | number> | null;
  user?: {
      username: string;
      avatar_url: string | null;
  }
}

export interface Circle {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  activeCount: number; // How many posted today
  hasUserPostedToday: boolean;
  unlockedTypes: CheckInType[]; // List of activity types user has completed today
  streak: number;
  posts: Post[];
  theme: string; // Hex color for circle branding
  createdBy: string;
  isPublic: boolean;
  allowedTypes: CheckInType[] | null; // If null, allow all
  imageUrl: string | null;
}

export interface HeatmapDay {
  date: string;
  status: 'completed' | 'missed' | 'pending' | 'future' | 'frozen';
  intensity: number; // 0-100
}

export interface Goal {
    id: string;
    userId?: string;
    circleId?: string;
    activityType: CheckInType;
    frequency: 'DAILY' | 'WEEKLY' | 'SPECIFIC_DAYS';
    targetCount: number;
    targetDays?: number[]; // 0=Sun, 1=Mon...
    progress?: number; // Calculated on frontend
    subGoal?: string | null;
    metricTarget?: Record<string, number> | null;
    title?: string | null;
    currentStreak?: number;
    lastCompletedPeriod?: string | null;
}