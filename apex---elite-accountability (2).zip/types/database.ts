
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string
          avatar_url: string | null
          updated_at: string | null
          onboarding_complete: boolean
          streak: number
          freeze_tokens: number
        }
        Insert: {
          id: string
          username: string
          avatar_url?: string | null
          updated_at?: string | null
          onboarding_complete?: boolean
          streak?: number
          freeze_tokens?: number
        }
        Update: {
          id?: string
          username?: string
          avatar_url?: string | null
          updated_at?: string | null
          onboarding_complete?: boolean
          streak?: number
          freeze_tokens?: number
        }
        Relationships: []
      }
      circles: {
        Row: {
          id: string
          name: string
          description: string | null
          theme: string
          streak: number
          created_at: string
          created_by: string
          is_public: boolean
          allowed_activity_types: string[] | null
          image_url: string | null
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          theme?: string
          streak?: number
          created_at?: string
          created_by?: string
          is_public?: boolean
          allowed_activity_types?: string[] | null
          image_url?: string | null
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          theme?: string
          streak?: number
          created_at?: string
          created_by?: string
          is_public?: boolean
          allowed_activity_types?: string[] | null
          image_url?: string | null
        }
        Relationships: [
           {
            foreignKeyName: "circles_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      circle_members: {
        Row: {
          circle_id: string
          user_id: string
          joined_at: string
        }
        Insert: {
          circle_id: string
          user_id: string
          joined_at?: string
        }
        Update: {
          circle_id?: string
          user_id?: string
          joined_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "circle_members_circle_id_fkey"
            columns: ["circle_id"]
            isOneToOne: false
            referencedRelation: "circles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "circle_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      posts: {
        Row: {
          id: string
          circle_id: string
          user_id: string
          image_url: string
          caption: string | null
          activity_type: string
          sub_activity: string | null
          created_at: string
          reactions: number
          milestone_key: string | null
          tags: string[] | null
          metrics: Json | null
        }
        Insert: {
          id?: string
          circle_id: string
          user_id: string
          image_url: string
          caption?: string | null
          activity_type: string
          sub_activity?: string | null
          created_at?: string
          reactions?: number
          milestone_key?: string | null
          tags?: string[] | null
          metrics?: Json | null
        }
        Update: {
          id?: string
          circle_id?: string
          user_id?: string
          image_url?: string
          caption?: string | null
          activity_type?: string
          sub_activity?: string | null
          created_at?: string
          reactions?: number
          milestone_key?: string | null
          tags?: string[] | null
          metrics?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "posts_circle_id_fkey"
            columns: ["circle_id"]
            isOneToOne: false
            referencedRelation: "circles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      post_likes: {
        Row: {
          user_id: string
          post_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          post_id: string
          created_at?: string
        }
        Update: {
          user_id?: string
          post_id?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      post_flags: {
        Row: {
          user_id: string
          post_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          post_id: string
          created_at?: string
        }
        Update: {
          user_id?: string
          post_id?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_flags_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_flags_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      messages: {
        Row: {
          id: string
          circle_id: string
          user_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          user_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          user_id?: string
          content?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_circle_id_fkey"
            columns: ["circle_id"]
            isOneToOne: false
            referencedRelation: "circles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      hall_of_fame: {
        Row: {
          id: string
          circle_id: string
          post_id: string
          saved_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          circle_id: string
          post_id: string
          saved_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          circle_id?: string
          post_id?: string
          saved_by?: string | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "hall_of_fame_circle_id_fkey"
            columns: ["circle_id"]
            isOneToOne: false
            referencedRelation: "circles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "hall_of_fame_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          }
        ]
      }
      user_milestones: {
        Row: {
          id: string
          user_id: string
          activity_type: string
          milestone_key: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          activity_type: string
          milestone_key: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          activity_type?: string
          milestone_key?: string
          created_at?: string
        }
        Relationships: [
            {
            foreignKeyName: "user_milestones_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      governance_sessions: {
        Row: {
            id: string
            circle_id: string
            created_at: string
            is_active: boolean
            week_of: string
        }
        Insert: {
            id?: string
            circle_id: string
            created_at?: string
            is_active?: boolean
            week_of?: string
        }
        Update: {
            id?: string
            circle_id?: string
            created_at?: string
            is_active?: boolean
            week_of?: string
        }
        Relationships: []
      }
      governance_votes: {
        Row: {
            id: string
            session_id: string
            user_id: string
            vote_type: string
            created_at: string
        }
        Insert: {
            id?: string
            session_id: string
            user_id: string
            vote_type: string
            created_at?: string
        }
        Update: {
            id?: string
            session_id?: string
            user_id?: string
            vote_type?: string
            created_at?: string
        }
        Relationships: [
             {
            foreignKeyName: "governance_votes_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "governance_sessions"
            referencedColumns: ["id"]
          }
        ]
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          actor_id: string
          content: string
          is_read: boolean
          created_at: string
          type: string | null
          related_entity_id: string | null
        }
        Insert: {
          id?: string
          user_id: string
          actor_id: string
          content: string
          is_read?: boolean
          created_at?: string
          type?: string | null
          related_entity_id?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          actor_id?: string
          content?: string
          is_read?: boolean
          created_at?: string
          type?: string | null
          related_entity_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      goals: {
        Row: {
            id: string
            user_id: string | null
            circle_id: string | null
            activity_type: string
            frequency: 'DAILY' | 'WEEKLY' | 'SPECIFIC_DAYS'
            target_count: number
            target_days: number[] | null
            created_at: string
            sub_goal: string | null
            metric_target: Json | null
            title: string | null
            current_streak: number
            last_completed_period: string | null
        }
        Insert: {
            id?: string
            user_id?: string | null
            circle_id?: string | null
            activity_type: string
            frequency: 'DAILY' | 'WEEKLY' | 'SPECIFIC_DAYS'
            target_count?: number
            target_days?: number[] | null
            created_at?: string
            sub_goal?: string | null
            metric_target?: Json | null
            title?: string | null
            current_streak?: number
            last_completed_period?: string | null
        }
        Update: {
            id?: string
            user_id?: string | null
            circle_id?: string | null
            activity_type?: string
            frequency?: 'DAILY' | 'WEEKLY' | 'SPECIFIC_DAYS'
            target_count?: number
            target_days?: number[] | null
            created_at?: string
            sub_goal?: string | null
            metric_target?: Json | null
            title?: string | null
            current_streak?: number
            last_completed_period?: string | null
        }
        Relationships: []
      }
      streak_freezes: {
        Row: {
          id: string
          user_id: string
          freeze_date: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          freeze_date: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          freeze_date?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "streak_freezes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      increment_likes: {
        Args: {
          post_id: string
        }
        Returns: void
      }
      decrement_likes: {
        Args: {
          post_id: string
        }
        Returns: void
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
