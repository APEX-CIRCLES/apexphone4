
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Gavel, TrendingUp, Minus, TrendingDown, Users } from 'lucide-react';

interface GovernanceModalProps {
  circleId: string;
  onClose: () => void;
  currentUserId: string;
}

type VoteType = 'MAINTAIN' | 'ESCALATE' | 'DELOAD';

interface VoteCount {
  MAINTAIN: number;
  ESCALATE: number;
  DELOAD: number;
  total: number;
}

export const GovernanceModal: React.FC<GovernanceModalProps> = ({ circleId, onClose, currentUserId }) => {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [hasVoted, setHasVoted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [votes, setVotes] = useState<VoteCount>({ MAINTAIN: 0, ESCALATE: 0, DELOAD: 0, total: 0 });
  const [myVote, setMyVote] = useState<VoteType | null>(null);

  useEffect(() => {
    initializeSession();
  }, []);

  const initializeSession = async () => {
    try {
      // 1. Get active session
      const { data: sessionData } = await supabase
        .from('governance_sessions')
        .select('id')
        .eq('circle_id', circleId)
        .eq('is_active', true)
        .single();

      if (!sessionData) {
        // Only Admin should see the modal trigger if no session, but double check
        setLoading(false);
        return;
      }

      setSessionId(sessionData.id);

      // 2. Get Votes
      const { data: voteData } = await supabase
        .from('governance_votes')
        .select('user_id, vote_type')
        .eq('session_id', sessionData.id);

      if (voteData) {
        const counts = { MAINTAIN: 0, ESCALATE: 0, DELOAD: 0, total: 0 };
        voteData.forEach((v: any) => {
          counts[v.vote_type as VoteType]++;
          counts.total++;
          if (v.user_id === currentUserId) {
            setHasVoted(true);
            setMyVote(v.vote_type as VoteType);
          }
        });
        setVotes(counts);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const castVote = async (type: VoteType) => {
    if (!sessionId) return;
    
    // Optimistic Update
    setHasVoted(true);
    setMyVote(type);
    setVotes(prev => ({
        ...prev,
        [type]: prev[type] + 1,
        total: prev.total + 1
    }));

    const { error } = await supabase.from('governance_votes').insert({
        session_id: sessionId,
        user_id: currentUserId,
        vote_type: type
    });

    if (error) {
        console.error("Vote failed", error);
        // Revert? For now just log
    }
  };

  if (loading) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 text-center relative bg-zinc-900/30">
          <button onClick={onClose} className="absolute top-4 right-4 text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
          <div className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center mx-auto mb-4 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
            <Gavel size={24} />
          </div>
          <h2 className="font-black italic uppercase tracking-tighter text-white text-2xl">The Council</h2>
          <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest mt-1">Weekly Governance Protocol</p>
        </div>

        {/* Content */}
        <div className="p-6">
            {!hasVoted ? (
                <div className="space-y-4">
                    <p className="text-zinc-400 text-sm text-center mb-6 leading-relaxed">
                        The week is reset. How shall we proceed for the upcoming cycle? Cast your vote.
                    </p>
                    
                    <button 
                        onClick={() => castVote('ESCALATE')}
                        className="w-full bg-red-950/20 border border-red-900/50 hover:bg-red-900/40 p-4 rounded-xl flex items-center justify-between group transition-all active:scale-[0.98]"
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-red-500/10 rounded-lg text-red-500">
                                <TrendingUp size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-red-500 font-bold uppercase text-sm group-hover:text-red-400">Escalate</div>
                                <div className="text-[10px] text-zinc-500">Increase intensity</div>
                            </div>
                        </div>
                    </button>

                    <button 
                        onClick={() => castVote('MAINTAIN')}
                        className="w-full bg-emerald-950/20 border border-emerald-900/50 hover:bg-emerald-900/40 p-4 rounded-xl flex items-center justify-between group transition-all active:scale-[0.98]"
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500">
                                <Minus size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-emerald-500 font-bold uppercase text-sm group-hover:text-emerald-400">Maintain</div>
                                <div className="text-[10px] text-zinc-500">Hold the standard</div>
                            </div>
                        </div>
                    </button>

                    <button 
                        onClick={() => castVote('DELOAD')}
                        className="w-full bg-blue-950/20 border border-blue-900/50 hover:bg-blue-900/40 p-4 rounded-xl flex items-center justify-between group transition-all active:scale-[0.98]"
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
                                <TrendingDown size={20} />
                            </div>
                            <div className="text-left">
                                <div className="text-blue-500 font-bold uppercase text-sm group-hover:text-blue-400">Deload</div>
                                <div className="text-[10px] text-zinc-500">Recovery phase</div>
                            </div>
                        </div>
                    </button>
                </div>
            ) : (
                <div className="space-y-6">
                     <div className="text-center">
                         <div className="inline-block px-3 py-1 rounded bg-zinc-800 text-zinc-400 text-xs font-bold uppercase mb-4">
                            You Voted: <span className="text-white">{myVote}</span>
                         </div>
                     </div>

                     <div className="space-y-4">
                        {/* Escalate Bar */}
                        <div>
                            <div className="flex justify-between text-xs font-bold mb-1">
                                <span className="text-red-500 uppercase">Escalate</span>
                                <span className="text-zinc-500">{votes.ESCALATE} Votes</span>
                            </div>
                            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                                <div className="h-full bg-red-600 transition-all duration-1000" style={{ width: `${(votes.ESCALATE / votes.total) * 100}%`}} />
                            </div>
                        </div>

                         {/* Maintain Bar */}
                         <div>
                            <div className="flex justify-between text-xs font-bold mb-1">
                                <span className="text-emerald-500 uppercase">Maintain</span>
                                <span className="text-zinc-500">{votes.MAINTAIN} Votes</span>
                            </div>
                            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-600 transition-all duration-1000" style={{ width: `${(votes.MAINTAIN / votes.total) * 100}%`}} />
                            </div>
                        </div>

                         {/* Deload Bar */}
                         <div>
                            <div className="flex justify-between text-xs font-bold mb-1">
                                <span className="text-blue-500 uppercase">Deload</span>
                                <span className="text-zinc-500">{votes.DELOAD} Votes</span>
                            </div>
                            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                                <div className="h-full bg-blue-600 transition-all duration-1000" style={{ width: `${(votes.DELOAD / votes.total) * 100}%`}} />
                            </div>
                        </div>
                     </div>
                     
                     <div className="flex items-center justify-center gap-2 text-zinc-600 mt-4">
                        <Users size={14} />
                        <span className="text-xs font-mono">{votes.total} Members Voted</span>
                     </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
