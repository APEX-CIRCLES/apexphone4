
import React from 'react';
import { Snowflake, AlertTriangle, X } from 'lucide-react';

interface FreezeModalProps {
  onUseToken: () => void;
  onDismiss: () => void;
  tokenCount: number;
}

export const FreezeModal: React.FC<FreezeModalProps> = ({ onUseToken, onDismiss, tokenCount }) => {
  return (
    <div className="fixed inset-0 z-[150] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6">
      <div className="w-full max-w-sm bg-zinc-950 border border-red-900/50 rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(220,38,38,0.2)] animate-in fade-in zoom-in duration-300 relative">
        
        {/* Header */}
        <div className="p-8 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-red-500/10 animate-pulse z-0" />
            <div className="relative z-10">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-red-500">
                    <AlertTriangle size={32} className="text-red-500" />
                </div>
                <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white mb-2">
                    Streak Compromised
                </h2>
                <p className="text-sm text-red-400 font-bold uppercase tracking-wider">
                    Critical Failure Detected
                </p>
            </div>
        </div>

        <div className="p-6 bg-zinc-900/50">
            <p className="text-zinc-300 text-sm text-center mb-6 leading-relaxed">
                You missed a check-in yesterday. Your status is at risk of total reset.
            </p>

            <div className="flex items-center justify-between bg-black/40 border border-zinc-800 p-4 rounded-xl mb-6">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/10 rounded-lg">
                        <Snowflake className="text-blue-500" size={20} />
                    </div>
                    <div>
                        <p className="text-[10px] text-zinc-500 font-bold uppercase">Available Tokens</p>
                        <p className="text-lg font-black text-white">{tokenCount}</p>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-[10px] text-zinc-500 font-bold uppercase">Cost</p>
                    <p className="text-lg font-black text-red-500">-1</p>
                </div>
            </div>

            <button 
                onClick={onUseToken}
                className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all active:scale-[0.98] flex items-center justify-center gap-2 mb-3"
            >
                <Snowflake size={18} />
                <span>Deploy Freeze</span>
            </button>
            
            <button 
                onClick={onDismiss}
                className="w-full py-3 bg-transparent text-zinc-600 hover:text-red-500 text-xs font-bold uppercase tracking-widest transition-colors"
            >
                Accept Failure (Reset Streak)
            </button>
        </div>
      </div>
    </div>
  );
};
