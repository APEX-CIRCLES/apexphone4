
import React, { useState, useEffect } from 'react';
import { X, ArrowRight, ShieldCheck } from 'lucide-react';

interface JoinCircleModalProps {
  onClose: () => void;
  onSubmit: (code: string) => Promise<void>;
  initialCode?: string;
}

export const JoinCircleModal: React.FC<JoinCircleModalProps> = ({ onClose, onSubmit, initialCode }) => {
  const [code, setCode] = useState(initialCode || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
      if (initialCode) setCode(initialCode);
  }, [initialCode]);

  const handleSubmit = async () => {
    if (!code) return;
    setIsSubmitting(true);
    setError(null);
    try {
      await onSubmit(code.trim());
      onClose();
    } catch (e: any) {
      setError('Invalid code or already a member.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center">
          <div className="flex items-center gap-2 text-white">
            <ShieldCheck className="w-5 h-5 text-apex-primary" />
            <h2 className="font-bold uppercase tracking-wider text-sm">Join Circle</h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 text-xs text-zinc-500 font-mono leading-relaxed">
            Enter the Circle ID shared by your squad leader. Access is restricted to invite holders only.
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Access Code</label>
            <div className="relative">
                <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. 123e4567-e89b..."
                className="w-full bg-black border border-zinc-700 rounded-xl p-4 pr-12 text-white placeholder:text-zinc-800 focus:outline-none focus:border-apex-primary transition-colors font-mono text-sm"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                    <ArrowRight size={16} className="text-zinc-600" />
                </div>
            </div>
          </div>

          {error && (
            <div className="text-red-500 text-xs font-bold text-center animate-pulse">
                {error}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={isSubmitting || !code}
            className={`w-full py-4 rounded-full font-bold uppercase tracking-widest text-sm transition-all ${
              code && !isSubmitting
                ? 'bg-white text-black hover:bg-zinc-200'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
          >
            {isSubmitting ? 'Authenticating...' : 'Enter Circle'}
          </button>
        </div>
      </div>
    </div>
  );
};
