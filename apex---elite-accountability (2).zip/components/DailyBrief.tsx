
import React, { useState, useEffect } from 'react';
import { X, Radio } from 'lucide-react';
import { TACTICAL_BRIEFS } from '../constants';

export const DailyBrief = () => {
  const [visible, setVisible] = useState(true);
  
  // Use a day-based index to ensure the quote is the same for the whole day
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const brief = TACTICAL_BRIEFS[dayOfYear % TACTICAL_BRIEFS.length];

  if (!visible) return null;

  return (
    <div className="mb-6 bg-zinc-900/40 border border-zinc-800 p-5 rounded-xl relative overflow-hidden group animate-in fade-in slide-in-from-top-4 duration-700">
      <div className="absolute top-0 right-0 p-2 z-10">
        <button onClick={() => setVisible(false)} className="text-zinc-600 hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>
      
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 rounded-full bg-apex-accent animate-pulse shadow-[0_0_8px_rgba(234,179,8,0.6)]" />
        <h3 className="text-[10px] font-bold text-apex-accent uppercase tracking-widest">Morning Brief</h3>
      </div>
      
      <p className="text-sm font-medium text-zinc-200 font-mono leading-relaxed pr-6 relative z-10">
        "{brief}"
      </p>
      
      {/* Decorative Elements */}
      <div className="absolute -bottom-6 -right-6 text-zinc-800/20 rotate-12 pointer-events-none">
        <Radio size={80} />
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-black/20 pointer-events-none" />
    </div>
  );
};
