
import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { X, Trophy, Medal, User } from 'lucide-react';
import { getRankColor, getRank } from '../lib/utils';

interface LeaderboardProps {
  onClose: () => void;
  currentUserId: string;
}

interface LeaderboardUser {
  id: string;
  username: string;
  avatar_url: string;
  streak: number;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ onClose, currentUserId }) => {
  const [users, setUsers] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_url, streak')
        .order('streak', { ascending: false })
        .limit(50);

      if (error) throw error;
      setUsers(data as any || []);
    } catch (e) {
      console.error('Error fetching leaderboard', e);
    } finally {
      setLoading(false);
    }
  };

  const getMedal = (index: number) => {
    if (index === 0) return <Medal size={20} className="text-yellow-400" fill="currentColor" />;
    if (index === 1) return <Medal size={20} className="text-zinc-400" fill="currentColor" />;
    if (index === 2) return <Medal size={20} className="text-amber-700" fill="currentColor" />;
    return <span className="text-sm font-mono font-bold text-zinc-600">#{index + 1}</span>;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                <Trophy className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
                <h2 className="font-black italic uppercase tracking-tighter text-white text-xl">The Arena</h2>
                <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest">Global Top 50</p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-2 scroll-smooth">
            {loading ? (
                <div className="py-12 flex justify-center">
                    <div className="text-xs font-mono text-zinc-500 animate-pulse">CALCULATING GLOBAL RANKS...</div>
                </div>
            ) : (
                <div className="space-y-1">
                    {users.map((user, index) => {
                        const isMe = user.id === currentUserId;
                        const rank = getRank(user.streak);
                        const rankColor = getRankColor(rank);

                        return (
                            <div 
                                key={user.id} 
                                className={`flex items-center gap-4 p-3 rounded-xl transition-all ${
                                    isMe 
                                    ? 'bg-zinc-800 border border-zinc-700' 
                                    : 'hover:bg-zinc-900 border border-transparent hover:border-zinc-800'
                                }`}
                            >
                                <div className="w-8 flex items-center justify-center">
                                    {getMedal(index)}
                                </div>
                                
                                <div className="w-10 h-10 rounded-full bg-zinc-800 overflow-hidden relative border border-zinc-700">
                                    {user.avatar_url ? (
                                        <img src={user.avatar_url} alt={user.username} className="w-full h-full object-cover" />
                                    ) : (
                                        <User className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-zinc-600" />
                                    )}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                        <h3 className={`font-bold text-sm truncate ${isMe ? 'text-white' : 'text-zinc-300'}`}>
                                            {user.username}
                                        </h3>
                                        {isMe && <span className="text-[9px] bg-apex-primary text-black font-bold px-1 rounded">YOU</span>}
                                    </div>
                                    <p className={`text-[10px] font-bold uppercase tracking-wider ${rankColor}`}>
                                        {rank}
                                    </p>
                                </div>

                                <div className="text-right">
                                    <span className="text-lg font-black text-white">{user.streak}</span>
                                    <p className="text-[9px] text-zinc-600 font-mono uppercase">DAYS</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-zinc-900/50 border-t border-zinc-800 text-center">
            <p className="text-[10px] text-zinc-500 font-mono">
                RANKS UPDATE IN REAL-TIME • CONSISTENCY IS KING
            </p>
        </div>

      </div>
    </div>
  );
};
