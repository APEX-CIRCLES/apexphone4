import React, { useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'neutral';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const icons = {
    success: <CheckCircle2 size={18} className="text-apex-primary" />,
    error: <AlertCircle size={18} className="text-apex-danger" />,
    neutral: <Info size={18} className="text-apex-muted" />
  };

  const borders = {
    success: 'border-apex-primary/20 bg-emerald-950/80',
    error: 'border-apex-danger/20 bg-rose-950/80',
    neutral: 'border-zinc-800 bg-zinc-900/90'
  };

  return (
    <div className={`fixed top-4 left-4 right-4 z-[100] flex items-center gap-3 p-4 rounded-xl border backdrop-blur-md shadow-2xl animate-in fade-in slide-in-from-top-4 duration-300 ${borders[type]}`}>
      {icons[type]}
      <p className="flex-1 text-sm font-bold text-white tracking-wide">{message}</p>
      <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
        <X size={16} />
      </button>
    </div>
  );
};