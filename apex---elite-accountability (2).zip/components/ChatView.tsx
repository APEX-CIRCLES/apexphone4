
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Send, User, AlertTriangle, Shield } from 'lucide-react';

interface ChatViewProps {
  circleId: string;
  currentUserId: string;
  initialMessage?: string;
}

interface Message {
  id: string;
  content: string;
  user_id: string;
  created_at: string;
  user?: {
    username: string;
    avatar_url: string | null;
  };
}

export const ChatView: React.FC<ChatViewProps> = ({ circleId, currentUserId, initialMessage }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState(initialMessage || '');
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialMessage) {
        setNewMessage(initialMessage);
        inputRef.current?.focus();
    }
  }, [initialMessage]);

  // Auto-scroll whenever messages change
  useEffect(() => {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    setLoading(true);
    fetchMessages();

    const channel = supabase
      .channel(`chat:${circleId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `circle_id=eq.${circleId}`,
        },
        async (payload) => {
          // 1. Fetch user details immediately for the new message
          const { data: userData } = await supabase
            .from('profiles')
            .select('username, avatar_url')
            .eq('id', payload.new.user_id)
            .single();
            
          const newMsg: Message = {
            id: payload.new.id,
            content: payload.new.content,
            user_id: payload.new.user_id,
            created_at: payload.new.created_at,
            user: userData as any
          };

          setMessages(prev => {
              // 2. Deduplicate: Avoid adding if ID exists
              if (prev.some(m => m.id === newMsg.id)) return prev;
              
              // 3. Optimistic Replacement
              const hasOptimisticMatch = prev.some(m => 
                  m.user_id === newMsg.user_id && 
                  m.content === newMsg.content && 
                  m.id.startsWith('temp-')
              );
              
              if (hasOptimisticMatch) {
                  return prev.map(m => (m.id.startsWith('temp-') && m.content === newMsg.content) ? newMsg : m);
              }
              
              return [...prev, newMsg];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [circleId]);

  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          user:profiles(username, avatar_url)
        `)
        .eq('circle_id', circleId)
        .order('created_at', { ascending: true })
        .limit(100);

      if (error) throw error;
      setMessages(data as any || []);
    } catch (e) {
      console.error('Error fetching messages', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const content = newMessage.trim();
    setNewMessage(''); // Clear immediately

    // 1. Optimistic Update
    const tempId = `temp-${Date.now()}`;
    const optimisticMsg: Message = {
        id: tempId,
        content: content,
        user_id: currentUserId,
        created_at: new Date().toISOString(),
        user: {
            username: 'Me', 
            avatar_url: null 
        }
    };
    
    setMessages(prev => [...prev, optimisticMsg]);

    try {
      const { error } = await supabase.from('messages').insert({
        circle_id: circleId,
        user_id: currentUserId,
        content
      });
      
      if (error) throw error;
    } catch (e) {
      console.error('Error sending message', e);
      setMessages(prev => prev.filter(m => m.id !== tempId)); // Rollback
      alert('Failed to send message');
    }
  };

  const formatTime = (isoString: string) => {
      return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const isSystemMessage = (content: string) => content.includes('⚠️') || content.includes('Alert');

  if (loading) return <div className="flex justify-center p-20 text-xs font-mono text-zinc-600 animate-pulse">ENCRYPTING UPLINK...</div>;

  return (
    <div className="flex flex-col h-[calc(100vh-190px)] relative">
      <div className="flex-1 overflow-y-auto px-4 pt-4 pb-4 space-y-4">
        {messages.length === 0 && (
            <div className="text-center py-12 text-zinc-600 text-xs italic">
                Secure channel established.
            </div>
        )}
        
        {messages.map((msg, idx) => {
          const isMe = msg.user_id === currentUserId;
          const prevMsg = messages[idx - 1];
          
          // Logic: Show label if different user OR > 2 minutes gap
          const isDifferentUser = !prevMsg || prevMsg.user_id !== msg.user_id;
          const isLongGap = prevMsg && (new Date(msg.created_at).getTime() - new Date(prevMsg.created_at).getTime() > 2 * 60 * 1000);
          const showLabel = isDifferentUser || isLongGap;

          if (isSystemMessage(msg.content)) {
            return (
                <div key={msg.id} className="flex justify-center my-4 animate-in fade-in zoom-in duration-300">
                    <div className="bg-red-950/30 border border-red-900/30 px-3 py-1.5 rounded-full text-[9px] font-bold text-red-400 uppercase tracking-wide flex items-center gap-2">
                        <AlertTriangle size={10} />
                        <span>{msg.content}</span>
                    </div>
                </div>
            );
          }

          return (
            <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2`}>
              
              {/* LABEL (Username) */}
              {showLabel && (
                  <div className={`flex items-center gap-2 mb-1 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className="w-4 h-4 rounded-full bg-zinc-800 overflow-hidden border border-zinc-700">
                        {msg.user?.avatar_url ? (
                            <img src={msg.user.avatar_url} alt="user" className="w-full h-full object-cover" />
                        ) : (
                            <User className="w-full h-full p-0.5 text-zinc-500" />
                        )}
                      </div>
                      <span className="text-[10px] font-bold text-zinc-400">
                          {msg.user?.username || (isMe ? 'You' : 'Unknown Agent')}
                      </span>
                  </div>
              )}

              {/* BUBBLE */}
              <div className={`flex gap-2 max-w-[85%] ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed break-words shadow-sm relative group ${
                    isMe 
                      ? 'bg-apex-primary text-black font-medium rounded-tr-sm' 
                      : 'bg-zinc-800 border border-zinc-700 text-zinc-200 rounded-tl-sm'
                  }`}>
                    {msg.content}
                    <div className={`text-[8px] font-mono mt-1 opacity-60 ${isMe ? 'text-black' : 'text-zinc-500 text-right'}`}>
                        {formatTime(msg.created_at)}
                    </div>
                  </div>
              </div>

            </div>
          );
        })}
        <div ref={bottomRef} className="h-2" />
      </div>

      {/* Input Area */}
      <div className="p-3 bg-black border-t border-zinc-800 sticky bottom-0 z-20">
        <form onSubmit={handleSend} className="relative flex items-center gap-2">
          <input
            ref={inputRef}
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Send tactical update..."
            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-full pl-4 pr-4 py-3 text-white focus:outline-none focus:border-apex-primary transition-colors text-sm placeholder:text-zinc-600"
          />
          <button 
            type="submit"
            disabled={!newMessage.trim()}
            className="p-3 bg-apex-primary rounded-full text-black disabled:opacity-50 disabled:bg-zinc-800 disabled:text-zinc-600 transition-all active:scale-90 flex-shrink-0 shadow-lg"
          >
            <Send size={18} fill="currentColor" />
          </button>
        </form>
      </div>
    </div>
  );
};
