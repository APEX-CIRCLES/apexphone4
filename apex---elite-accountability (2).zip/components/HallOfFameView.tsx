
import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Post, CheckInType } from '../types';
import { Star, Loader2 } from 'lucide-react';

interface HallOfFameViewProps {
  circleId: string;
  onPostClick: (post: Post) => void;
}

export const HallOfFameView: React.FC<HallOfFameViewProps> = ({ circleId, onPostClick }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHallOfFame();
  }, [circleId]);

  const fetchHallOfFame = async () => {
    const { data, error } = await supabase
      .from('hall_of_fame')
      .select(`
        post:posts (
            *,
            user:profiles(username, avatar_url)
        )
      `)
      .eq('circle_id', circleId)
      .order('created_at', { ascending: false });

    if (!error && data) {
        const mappedPosts: Post[] = data.map((item: any) => ({
            id: item.post.id,
            userId: item.post.user_id,
            type: item.post.activity_type as CheckInType,
            imageUrl: item.post.image_url,
            caption: item.post.caption,
            timestamp: new Date(item.post.created_at).getTime(),
            reactions: item.post.reactions,
            user: item.post.user
        }));
        setPosts(mappedPosts);
    }
    setLoading(false);
  };

  if (loading) return (
    <div className="flex justify-center py-20">
        <Loader2 className="animate-spin text-yellow-500" />
    </div>
  );

  if (posts.length === 0) return (
    <div className="flex flex-col items-center justify-center py-24 text-center px-8">
        <div className="p-4 bg-zinc-900/50 rounded-full border border-zinc-800 mb-4">
            <Star className="w-8 h-8 text-zinc-700" />
        </div>
        <h3 className="text-white font-bold uppercase tracking-wide mb-2">Hall of Fame Empty</h3>
        <p className="text-xs text-zinc-500 max-w-[250px]">
            Star legendary posts in the feed to save them here forever.
        </p>
    </div>
  );

  return (
    <div className="p-1">
      <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-yellow-500/5 border border-yellow-500/10 mx-2 rounded-lg">
        <Star size={14} className="text-yellow-500" fill="currentColor" />
        <span className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest">Permanent Collection</span>
      </div>
      <div className="grid grid-cols-3 gap-1 px-2">
        {posts.map(post => (
            <div 
                key={post.id} 
                onClick={() => onPostClick(post)}
                className="aspect-square bg-zinc-900 relative group overflow-hidden cursor-pointer"
            >
                <img 
                    src={post.imageUrl} 
                    alt="Hall of Fame" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-[10px] font-bold text-white uppercase">{post.type.replace('_', ' ')}</span>
                </div>
                <div className="absolute top-1 right-1 text-yellow-500 drop-shadow-md">
                    <Star size={10} fill="currentColor" />
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};
