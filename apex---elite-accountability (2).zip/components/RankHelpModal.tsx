
import React from 'react';
import { X, Trophy, Flame, Shield } from 'lucide-react';
import { getRankColor } from '../lib/utils';

interface RankHelpModalProps {
  onClose: () => void;
}

const RANKS = [
    { name: 'Unranked', range: '0-2 Days', color: 'text-zinc-500' },
    { name: 'Initiate', range: '3-6 Days', color: 'text-blue-500' },
    { name: 'Operative', range: '7-13 Days', color: 'text-emerald-500' },
    { name: 'Vanguard', range: '14-29 Days', color: 'text-red-500' },
    { name: 'APEX', range: '30+ Days', color: 'text-yellow-500' },
];

export const RankHelpModal: React.FC<RankHelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[120] bg-black/90 backdrop-blur-sm flex items-center justify-center p-6">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <div className="flex items-center gap-2 text-white">
            <Shield className="w-5 h-5 text-apex-primary" />
            <h2 className="font-bold uppercase tracking-wider text-sm">Rank Protocols</h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
            <div className="text-center mb-6">
                <Flame className="w-10 h-10 text-orange-500 mx-auto mb-2" />
                <p className="text-sm text-zinc-400">
                    Status is earned through <span className="text-white font-bold">consecutive daily action</span>.
                    <br />Miss a day, and you reset to zero.
                </p>
            </div>

            <div className="space-y-3">
                {RANKS.map((rank) => (
                    <div key={rank.name} className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/50 border border-zinc-800">
                        <span className={`text-sm font-black uppercase tracking-widest ${rank.color}`}>
                            {rank.name}
                        </span>
                        <span className="text-xs font-mono text-zinc-500 font-bold">
                            {rank.range}
                        </span>
                    </div>
                ))}
            </div>
            
            <div className="mt-6 p-4 bg-blue-950/20 border border-blue-900/30 rounded-xl text-center">
                <p className="text-[10px] text-blue-400 uppercase font-bold tracking-wide">
                    Global Leaderboard unlocks at Bronze (Initiate)
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};
