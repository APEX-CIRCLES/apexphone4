
import React, { useState } from 'react';
import { ChevronRight, Lock, Flame, Shield, ArrowRight } from 'lucide-react';

interface OnboardingModalProps {
  onComplete: () => Promise<void>;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);

  const steps = [
    {
      icon: <Shield className="w-12 h-12 text-apex-primary" />,
      title: "Welcome to APEX",
      description: "You have entered the Elite Accountability Engine. This is not social media. This is a proving ground.",
      detail: "Small circles. High stakes. Zero excuses."
    },
    {
      icon: <Lock className="w-12 h-12 text-apex-danger" />,
      title: "Fog of War",
      description: "Access is earned, not given. You cannot see your Circle's progress until you upload your own proof.",
      detail: "No lurking. No free rides."
    },
    {
      icon: <Flame className="w-12 h-12 text-apex-accent" />,
      title: "Consistency is Currency",
      description: "Your rank is determined solely by your streak. Miss a day, and you bleed status.",
      detail: "Prove it or lose it."
    }
  ];

  const handleNext = async () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      setLoading(true);
      await onComplete();
      setLoading(false);
    }
  };

  const CurrentIcon = steps[step].icon;

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm flex-1 flex flex-col justify-center">
        
        {/* Progress Bar */}
        <div className="flex gap-2 mb-12">
          {steps.map((_, i) => (
            <div 
              key={i} 
              className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                i <= step ? 'bg-apex-primary' : 'bg-zinc-800'
              }`} 
            />
          ))}
        </div>

        {/* Content */}
        <div className="flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-8 duration-500 key={step}">
          <div className="mb-8 p-6 bg-zinc-900 rounded-full border border-zinc-800 shadow-[0_0_30px_rgba(0,0,0,0.5)]">
            {steps[step].icon}
          </div>
          
          <h1 className="text-3xl font-black italic uppercase tracking-tighter text-white mb-4">
            {steps[step].title}
          </h1>
          
          <p className="text-zinc-400 font-medium text-lg mb-4 leading-relaxed">
            {steps[step].description}
          </p>
          
          <p className="text-apex-primary font-mono text-xs uppercase tracking-widest border border-apex-primary/20 bg-apex-primary/5 px-3 py-1 rounded">
            {steps[step].detail}
          </p>
        </div>

      </div>

      {/* Footer / Action */}
      <div className="w-full max-w-sm pb-8">
        <button
          onClick={handleNext}
          disabled={loading}
          className="w-full group relative bg-white text-black h-16 rounded-full font-bold uppercase tracking-widest hover:bg-zinc-200 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
        >
          {loading ? (
             <span>Initializing...</span>
          ) : (
             <>
                <span>{step === steps.length - 1 ? 'Enter The Arena' : 'Next Protocol'}</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
             </>
          )}
        </button>
      </div>
    </div>
  );
};
