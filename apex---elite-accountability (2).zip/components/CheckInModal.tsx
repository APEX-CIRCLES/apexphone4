
import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, RefreshCw, Trophy, Check, Tag, Info, Target, ChevronUp, ChevronDown } from 'lucide-react';
import { CheckInType, Circle, Goal } from '../types';
import { MASTERY_TRACKS } from '../lib/mastery';
import { HABIT_CONFIG, HabitSubGoal } from '../lib/habit-config';
import { supabase } from '../lib/supabase';
import { compressImage } from '../lib/utils';

interface CheckInModalProps {
  onClose: () => void;
  onSubmit: (file: File | null, type: CheckInType, caption: string, milestoneKey?: string, subActivity?: string, circleId?: string, tags?: string[], metrics?: Record<string, any>, goalId?: string) => void;
  allowedTypes?: CheckInType[] | null;
  currentUserId?: string;
  circles?: Circle[];
  goals?: Goal[];
}

export const CheckInModal: React.FC<CheckInModalProps> = ({ onClose, onSubmit, allowedTypes, currentUserId, circles, goals }) => {
  const [image, setImage] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  
  const [selectedCircleId, setSelectedCircleId] = useState<string | null>(circles && circles.length > 0 ? circles[0].id : null);
  
  const [type, setType] = useState<CheckInType>(CheckInType.GYM);
  const [subGoal, setSubGoal] = useState<HabitSubGoal | null>(null);
  const [tags, setTags] = useState<Set<string>>(new Set());
  const [metrics, setMetrics] = useState<Record<string, any>>({});
  
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  
  const [caption, setCaption] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);
  
  // Drawer State
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const prevCircleId = useRef<string | null>(null);

  const effectiveAllowedTypes = circles && selectedCircleId 
    ? circles.find(c => c.id === selectedCircleId)?.allowedTypes 
    : allowedTypes;

  const availableTypes = effectiveAllowedTypes && effectiveAllowedTypes.length > 0 ? effectiveAllowedTypes : Object.values(CheckInType);

  // Auto-select first circle
  useEffect(() => {
      if (!selectedCircleId && circles && circles.length > 0) {
          setSelectedCircleId(circles[0].id);
      }
  }, [circles]);

  // SMART PROTOCOL SWITCHING
  useEffect(() => {
    if (!selectedCircleId) return;

    const circleChanged = prevCircleId.current !== selectedCircleId;
    const goalsLoaded = goals && goals.length > 0;

    if (circleChanged || goalsLoaded) {
        const currentCircle = circles?.find(c => c.id === selectedCircleId);
        const allowed = currentCircle?.allowedTypes && currentCircle.allowedTypes.length > 0 
            ? currentCircle.allowedTypes 
            : Object.values(CheckInType);

        let nextType = type;
        let matchedGoal = false;

        if (goals) {
            const circleGoal = goals.find(g => 
                g.circleId === selectedCircleId && 
                allowed.includes(g.activityType)
            );
            
            if (circleGoal && (circleChanged || !allowed.includes(type))) {
                nextType = circleGoal.activityType;
                matchedGoal = true;
            }
        }

        if (!matchedGoal && !allowed.includes(nextType)) {
            nextType = allowed[0];
        }

        if (nextType !== type) {
            setType(nextType);
        }
        
        prevCircleId.current = selectedCircleId;
    }
  }, [selectedCircleId, circles, goals]); 

  useEffect(() => {
      setSelectedGoalId(null);
      setSubGoal(null);
      setTags(new Set());
      setMetrics({});
  }, [type]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      
      // 1. Show preview immediately
      setImage(URL.createObjectURL(selectedFile));
      setIsCompressing(true);

      try {
          // 2. Compress image in background
          const processedFile = await compressImage(selectedFile);
          setFile(processedFile);
      } catch (err) {
          console.error("Compression error:", err);
          setFile(selectedFile); // Fallback to original
      } finally {
          setIsCompressing(false);
      }
    }
  };

  const handleMetricChange = (key: string, value: any) => {
      setMetrics(prev => ({ ...prev, [key]: value }));
  }

  const toggleTag = (tag: string) => {
      const newTags = new Set(tags);
      if (newTags.has(tag)) newTags.delete(tag);
      else newTags.add(tag);
      setTags(newTags);
  }
  
  const handleGoalSelect = (goal: Goal) => {
      if (selectedGoalId === goal.id) {
          setSelectedGoalId(null);
          setMetrics({});
      } else {
          setSelectedGoalId(goal.id);
          if (goal.metricTarget) {
              setMetrics(goal.metricTarget);
          }
      }
  };

  const handleSubmit = () => {
    if (!file && !image) return; 
    setIsSubmitting(true);
    
    // Auto-add goal title as a tag so it shows in feed
    const finalTags = new Set(tags);
    if (selectedGoalId && goals) {
        const goal = goals.find(g => g.id === selectedGoalId);
        if (goal && goal.title) {
            finalTags.add(goal.title);
        } else if (goal) {
            finalTags.add("Mission Complete");
        }
    }

    onSubmit(
        file, 
        type, 
        caption, 
        undefined, 
        subGoal?.label || undefined, 
        selectedCircleId || undefined,
        Array.from(finalTags),
        metrics,
        selectedGoalId || undefined
    );
  };

  const config = HABIT_CONFIG[type];
  const relevantDirectives = (goals || []).filter(g => g.activityType === type && g.circleId === selectedCircleId);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      
      {/* 1. TOP BAR OVERLAY */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 flex justify-between items-start bg-gradient-to-b from-black/90 to-transparent pb-12 pointer-events-none">
        <button onClick={onClose} className="p-2 bg-black/50 backdrop-blur rounded-full text-white pointer-events-auto">
          <X size={20} />
        </button>
        
        {/* Squad Selector (Small Pills) */}
        {circles && circles.length > 0 && (
            <div className="flex gap-2 bg-black/50 backdrop-blur p-1 rounded-full border border-white/10 overflow-x-auto max-w-[65%] hide-scrollbar pointer-events-auto">
                {circles.map(circle => (
                    <button 
                        key={circle.id}
                        onClick={() => setSelectedCircleId(circle.id)}
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-[8px] font-bold shrink-0 transition-all ${
                            selectedCircleId === circle.id 
                            ? 'ring-2 ring-white scale-110' 
                            : 'opacity-50 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: circle.theme, color: '#000' }}
                    >
                        {circle.name.substring(0, 1)}
                    </button>
                ))}
            </div>
        )}
      </div>

      {/* 2. CAMERA VIEWPORT (FULL SCREEN) */}
      <div className="absolute inset-0 bg-zinc-900">
          {image ? (
            <img src={image} alt="Preview" className="w-full h-full object-cover" />
          ) : (
            <label className="w-full h-full flex flex-col items-center justify-center text-zinc-500 cursor-pointer hover:bg-zinc-800/50 transition-colors">
                <Camera size={48} className="mb-4 opacity-50" />
                <span className="text-xs font-mono uppercase tracking-widest">Open Camera</span>
                <input 
                    type="file" 
                    accept="image/*" 
                    capture="environment" 
                    onChange={handleFileChange}
                    className="hidden" 
                />
            </label>
          )}
          
          {image && (
                <button onClick={() => setImage(null)} className="absolute top-20 right-4 bg-black/50 p-2 rounded-full text-white backdrop-blur z-20">
                    <RefreshCw size={16} />
                </button>
          )}
      </div>

      {/* 3. CONTROL DECK (DRAWER) */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800 rounded-t-3xl transition-all duration-300 ease-out flex flex-col shadow-2xl z-30 ${
            isDrawerOpen ? 'h-[85vh]' : 'h-auto pb-6' 
        }`}
      >
          {/* Drawer Handle */}
          <div 
            onClick={() => setIsDrawerOpen(!isDrawerOpen)}
            className="w-full h-8 flex items-center justify-center cursor-pointer active:bg-white/5 rounded-t-3xl"
          >
              <div className="w-12 h-1 bg-zinc-700 rounded-full" />
          </div>

          <div className="px-6 flex-1 overflow-y-auto">
              
              {/* MAIN CONTROLS (Always Visible) */}
              <div className="mb-4">
                  <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-black italic text-white uppercase tracking-tighter">
                          {type.replace('_', ' ')}
                      </h2>
                      <button 
                        onClick={() => setIsDrawerOpen(!isDrawerOpen)} 
                        className={`text-[10px] font-bold uppercase flex items-center gap-1 px-2 py-1 rounded border transition-colors ${
                            selectedGoalId 
                            ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' 
                            : 'bg-apex-primary/10 text-apex-primary border-apex-primary/20'
                        }`}
                      >
                          {selectedGoalId ? (
                              <><Check size={10} /> Directive Attached</>
                          ) : (
                              isDrawerOpen ? 'Hide Intel' : 'Mission Intel'
                          )}
                          {isDrawerOpen ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
                      </button>
                  </div>

                  {/* Protocol Scroller */}
                  <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-4">
                        {availableTypes.map(t => (
                            <button 
                                key={t}
                                onClick={() => setType(t)}
                                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase whitespace-nowrap transition-colors border ${
                                    type === t 
                                    ? 'bg-white text-black border-white' 
                                    : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                                }`}
                            >
                                {t.replace('_', ' ')}
                            </button>
                        ))}
                  </div>

                  {/* Expanded Drawer Content */}
                  <div className={`space-y-6 transition-all duration-300 ${isDrawerOpen ? 'opacity-100' : 'hidden opacity-0'}`}>
                      
                      {/* Directives */}
                      {relevantDirectives.length > 0 && (
                        <div className="bg-emerald-950/20 border border-emerald-900/30 p-4 rounded-xl">
                            <label className="text-[10px] font-bold text-emerald-500 uppercase mb-3 flex items-center gap-1.5 tracking-wider">
                                <Target size={12} />
                                Select Active Mission
                            </label>
                            <div className="space-y-2">
                                {relevantDirectives.map(goal => {
                                    let metricDetails = '';
                                    if (goal.metricTarget) {
                                        const entries = Object.entries(goal.metricTarget);
                                        if (entries.length > 0) {
                                            metricDetails = entries.map(([k, v]) => {
                                                const def = HABIT_CONFIG[goal.activityType]?.metrics.find(m => m.key === k);
                                                return `${def?.label || k}: ${v}${def?.unit || ''}`;
                                            }).join(' • ');
                                        }
                                    }
                                    
                                    const isSelected = selectedGoalId === goal.id;
                                    
                                    return (
                                        <button 
                                            key={goal.id} 
                                            onClick={() => handleGoalSelect(goal)}
                                            className={`w-full flex justify-between items-center p-3 rounded-lg border transition-all duration-200 text-left ${
                                                isSelected 
                                                ? 'bg-emerald-500/20 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.1)]' 
                                                : 'bg-zinc-900/50 border-zinc-800 hover:border-emerald-500/30 hover:bg-zinc-900'
                                            }`}
                                        >
                                            <div className="flex-1 min-w-0 pr-2">
                                                <div className="flex items-center gap-2 mb-0.5">
                                                    <span className={`text-xs font-bold truncate ${isSelected ? 'text-white' : 'text-zinc-300'}`}>
                                                        {goal.title || 'Standard Directive'}
                                                    </span>
                                                    {isSelected && <Check size={12} className="text-emerald-500" />}
                                                </div>
                                                {metricDetails && (
                                                    <span className={`text-[10px] font-mono block truncate ${isSelected ? 'text-emerald-300' : 'text-zinc-500'}`}>
                                                        {metricDetails}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="text-right shrink-0">
                                                <span className={`text-xs font-mono font-bold ${isSelected ? 'text-emerald-400' : 'text-zinc-600'}`}>
                                                    {goal.progress}/{goal.targetCount}
                                                </span>
                                            </div>
                                        </button>
                                    )
                                })}
                            </div>
                        </div>
                      )}

                      {/* Metrics */}
                      {config.metrics.length > 0 && (
                        <div>
                            <label className="text-[10px] font-bold text-zinc-500 uppercase mb-3 block tracking-wider">Session Data</label>
                            <div className="grid grid-cols-2 gap-3">
                                {config.metrics.map(m => (
                                    <div key={m.key} className="bg-black p-3 rounded-lg border border-zinc-800">
                                        <label className="text-[10px] text-zinc-500 uppercase font-bold block mb-1">{m.label}</label>
                                        <div className="flex items-center gap-1">
                                            <input 
                                                type={m.type === 'number' ? 'number' : 'text'}
                                                placeholder="0"
                                                value={metrics[m.key] || ''}
                                                className="w-full bg-transparent text-white font-mono font-bold text-lg focus:outline-none"
                                                onChange={(e) => handleMetricChange(m.key, e.target.value)}
                                            />
                                            {m.unit && <span className="text-[10px] text-zinc-600 font-bold">{m.unit}</span>}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                      )}

                      {/* Tags */}
                      <div>
                        <label className="text-[10px] font-bold text-zinc-500 uppercase mb-3 block tracking-wider">Tags</label>
                        <div className="flex flex-wrap gap-2">
                            {config.tags.map(tag => (
                                <button
                                    key={tag}
                                    onClick={() => toggleTag(tag)}
                                    className={`px-3 py-1.5 rounded-md border text-[10px] font-bold uppercase transition-all ${
                                        tags.has(tag)
                                            ? 'bg-apex-primary/20 border-apex-primary text-apex-primary'
                                            : 'bg-black border-zinc-800 text-zinc-400'
                                    }`}
                                >
                                    {tag}
                                </button>
                            ))}
                        </div>
                      </div>
                  </div>

                  {/* Caption & Submit */}
                  <div className="mt-4 space-y-3">
                      <input 
                            type="text" 
                            placeholder="Add caption..." 
                            value={caption}
                            onChange={(e) => setCaption(e.target.value)}
                            className="w-full bg-black border border-zinc-800 rounded-xl p-4 text-white text-sm focus:outline-none focus:border-zinc-600"
                        />

                       <button 
                            disabled={!image || isSubmitting || isCompressing || (circles && !selectedCircleId)}
                            onClick={handleSubmit}
                            className={`w-full py-4 rounded-full font-bold uppercase tracking-widest text-sm transition-all shadow-lg flex items-center justify-center gap-2 ${
                                image && !isSubmitting && !isCompressing && (!circles || selectedCircleId)
                                ? 'bg-apex-primary text-black hover:bg-emerald-400 shadow-emerald-500/20' 
                                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                            }`}
                        >
                            {isCompressing ? 'Optimizing...' : isSubmitting ? 'Verifying...' : 'POST PROOF'}
                        </button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};
