
import React from 'react';
import { Circle } from '../types';
import { Lock, Flame, Check } from 'lucide-react';

interface CircleCardProps {
  circle: Circle;
  onClick: () => void;
}

export const CircleCard: React.FC<CircleCardProps> = ({ circle, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="w-full group relative overflow-hidden rounded-2xl mb-4 text-left transition-all duration-300 active:scale-[0.98] border border-zinc-800 bg-zinc-900/40 hover:border-zinc-700"
    >
      {/* Custom Background Image */}
      {circle.imageUrl && (
          <div className="absolute inset-0 z-0">
              <img 
                src={circle.imageUrl} 
                alt="" 
                className="w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity blur-sm scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
          </div>
      )}

      {/* Theme Gradient Backdrop (Fallback/Overlay) */}
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500 z-0"
        style={{ background: `linear-gradient(to right, ${circle.theme}, transparent)` }} 
      />
      
      {/* Active State Accent Line */}
      <div 
        className={`absolute left-0 top-0 bottom-0 w-1 transition-all duration-300 z-10 ${circle.hasUserPostedToday ? 'opacity-100' : 'opacity-0'}`}
        style={{ backgroundColor: circle.theme }}
      />

      <div className="relative z-10 p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
             {circle.imageUrl ? (
                <div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg border border-zinc-700/50 bg-black/20 shrink-0">
                    <img src={circle.imageUrl} alt={circle.name} className="w-full h-full object-cover" />
                </div>
             ) : (
                <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg shadow-lg shrink-0"
                    style={{ backgroundColor: `${circle.theme}20`, color: circle.theme, border: `1px solid ${circle.theme}40` }}
                >
                    {circle.name.substring(0, 1).toUpperCase()}
                </div>
             )}
             
             <div>
                <h3 className="font-bold text-white text-base leading-tight group-hover:text-white transition-colors drop-shadow-md">
                    {circle.name}
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5 font-medium line-clamp-1 pr-4">
                    {circle.description || "No mission brief."}
                </p>
             </div>
          </div>
          
          {circle.hasUserPostedToday ? (
             <div className="flex flex-col items-center">
                 <div className="bg-emerald-500/10 p-1.5 rounded-full border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.15)] mb-1 backdrop-blur-sm">
                    <Check size={14} className="text-emerald-500" />
                 </div>
                 <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-wide shadow-black drop-shadow-md">Done</span>
             </div>
          ) : (
            <div className="flex flex-col items-center">
                 <div className="bg-zinc-800/80 p-1.5 rounded-full border border-zinc-700 mb-1 backdrop-blur-sm">
                    <Lock size={14} className="text-zinc-500" />
                 </div>
                 <span className="text-[9px] font-bold text-zinc-600 uppercase tracking-wide">Locked</span>
             </div>
          )}
        </div>

        {/* Stats Row */}
        <div className="flex items-end gap-4 mt-2">
            {/* Streak */}
            <div className="flex flex-col">
                 <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider mb-1">Streak</span>
                 <div className="flex items-center gap-1.5 text-orange-500">
                    <Flame size={14} fill="currentColor" />
                    <span className="text-sm font-mono font-bold text-white drop-shadow-md">{circle.streak}</span>
                 </div>
            </div>

            {/* Participation Bar */}
            <div className="flex-1 flex flex-col justify-end pb-0.5">
                 <div className="flex justify-between items-end mb-1.5">
                    <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider">Group Status</span>
                    <span className="text-[10px] font-mono text-zinc-400">
                        <span className="text-white font-bold">{circle.activeCount}</span>/{circle.memberCount}
                    </span>
                 </div>
                 <div className="h-1.5 bg-zinc-800/50 rounded-full overflow-hidden border border-zinc-800/50 backdrop-blur-sm">
                    <div 
                        className="h-full rounded-full transition-all duration-500 shadow-[0_0_10px_currentColor]"
                        style={{ 
                            width: `${(circle.activeCount / circle.memberCount) * 100}%`,
                            backgroundColor: circle.theme,
                            color: circle.theme // for shadow
                        }}
                    />
                 </div>
            </div>
        </div>
      </div>
    </button>
  );
};
