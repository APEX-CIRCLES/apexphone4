
import React, { useEffect, useState } from 'react';
import { X, Heart, MessageCircle, AlertTriangle, Bell, Check, ShieldAlert } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface NotificationCenterProps {
  onClose: () => void;
  currentUserId: string;
}

interface Notification {
  id: string;
  type: 'LIKE' | 'REPLY' | 'NUDGE' | 'FLAG' | 'SYSTEM';
  content: string;
  is_read: boolean;
  created_at: string;
  related_entity_id?: string;
  actor_id: string;
  actor?: {
    username: string;
    avatar_url: string;
  };
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ onClose, currentUserId }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
    markAllAsRead();
  }, []);

  const fetchNotifications = async () => {
    try {
        // Step 1: Fetch Notifications
        const { data: notifsData, error: notifsError } = await supabase
          .from('notifications')
          .select('*')
          .eq('user_id', currentUserId)
          .order('created_at', { ascending: false })
          .limit(50);

        if (notifsError) throw notifsError;
        
        const rawNotifs = notifsData as any[] || [];

        if (rawNotifs.length === 0) {
            setNotifications([]);
            setLoading(false);
            return;
        }

        // Step 2: Fetch Actors manually (Only if there are actors to fetch)
        const actorIds = [...new Set(rawNotifs.map(n => n.actor_id).filter(Boolean))];
        
        let actorMap = new Map();

        if (actorIds.length > 0) {
            const { data: actorsData, error: actorsError } = await supabase
                .from('profiles')
                .select('id, username, avatar_url')
                .in('id', actorIds);
            
            if (actorsError) {
                console.error("Error fetching actors", actorsError);
            } else {
                actorMap = new Map(actorsData?.map((a: any) => [a.id, a]));
            }
        }

        // Step 3: Combine
        const combined = rawNotifs.map(n => ({
            ...n,
            actor: actorMap.get(n.actor_id)
        }));

        setNotifications(combined);
    } catch (e: any) {
        console.error('Error fetching notifications:', e.message || e);
    } finally {
        setLoading(false);
    }
  };

  const markAllAsRead = async () => {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', currentUserId)
      .eq('is_read', false);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'LIKE': return <Heart size={16} className="text-rose-500" fill="currentColor" />;
      case 'REPLY': return <MessageCircle size={16} className="text-blue-500" />;
      case 'NUDGE': return <Bell size={16} className="text-red-500" />;
      case 'FLAG': return <AlertTriangle size={16} className="text-orange-500" />;
      case 'SYSTEM': return <ShieldAlert size={16} className="text-zinc-500" />;
      default: return <Bell size={16} className="text-zinc-500" />;
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-[120] w-full max-w-sm bg-zinc-950 border-l border-zinc-800 shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col">
      <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50 backdrop-blur">
        <h2 className="text-sm font-bold uppercase tracking-widest text-white flex items-center gap-2">
          <Bell size={16} />
          Intel Feed
        </h2>
        <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="py-12 text-center text-xs text-zinc-600 font-mono animate-pulse">DECRYPTING SIGNALS...</div>
        ) : notifications.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-12 h-12 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-4 border border-zinc-800">
              <Check size={20} className="text-zinc-700" />
            </div>
            <p className="text-zinc-500 text-xs font-bold uppercase">All Caught Up</p>
          </div>
        ) : (
          <div className="space-y-1">
            {notifications.map((notif) => (
              <div 
                key={notif.id} 
                className={`p-4 rounded-xl flex gap-3 ${notif.is_read ? 'bg-transparent opacity-60' : 'bg-zinc-900 border border-zinc-800'}`}
              >
                <div className="mt-1">
                    {getIcon(notif.type)}
                </div>
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold text-white">{notif.actor?.username || 'System'}</span>
                    </div>
                    <p className="text-sm text-zinc-300 leading-snug">{notif.content}</p>
                    <p className="text-[10px] text-zinc-600 font-mono mt-2 uppercase">
                        {new Date(notif.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
