
import React, { useEffect, useState } from 'react';
import { X, Copy, Check, User, Bell, LogOut, Trash2, Crown, Share, Settings } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface CircleMembersModalProps {
  circleId: string;
  circleName: string;
  currentUserId: string;
  onClose: () => void;
  onLeave: () => void;
  onDeleteCircle: () => void;
  onEditCircle: () => void;
  onKickMember: (userId: string) => Promise<void>;
  onShowToast: (msg: string, type: 'success' | 'error' | 'neutral') => void;
  isCreator: boolean;
}

interface Member {
  userId: string;
  username: string;
  avatarUrl: string;
  joinedAt: string;
  hasPostedToday: boolean;
}

export const CircleMembersModal: React.FC<CircleMembersModalProps> = ({ 
  circleId, 
  circleName, 
  currentUserId, 
  onClose, 
  onLeave,
  onDeleteCircle,
  onEditCircle,
  onKickMember,
  onShowToast,
  isCreator
}) => {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [nudgedUsers, setNudgedUsers] = useState<Set<string>>(new Set());
  const [processingAction, setProcessingAction] = useState<string | null>(null);

  useEffect(() => {
    fetchMembers();
  }, [circleId]);

  const fetchMembers = async () => {
    try {
      // 1. Fetch Members
      const { data: memberData, error } = await supabase
        .from('circle_members')
        .select(`
            joined_at,
            user_id,
            profiles (
                username,
                avatar_url
            )
        `)
        .eq('circle_id', circleId);

      if (error) throw error;

      // 2. Check who posted today
      const startOfDay = new Date();
      startOfDay.setHours(0,0,0,0);
      
      const { data: posts } = await supabase
        .from('posts')
        .select('user_id')
        .eq('circle_id', circleId)
        .gte('created_at', startOfDay.toISOString());

      const postedUserIds = new Set(posts?.map((p: any) => p.user_id) || []);

      // 3. Merge
      const formattedMembers = (memberData as any[]).map((m: any) => ({
        userId: m.user_id,
        username: m.profiles.username,
        avatarUrl: m.profiles.avatar_url,
        joinedAt: m.joined_at,
        hasPostedToday: postedUserIds.has(m.user_id)
      }));

      // Sort: Me first, then active, then inactive
      formattedMembers.sort((a, b) => {
        if (a.userId === currentUserId) return -1;
        if (b.userId === currentUserId) return 1;
        return Number(b.hasPostedToday) - Number(a.hasPostedToday);
      });

      setMembers(formattedMembers);
    } catch (e) {
      console.error('Error fetching members:', e);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    // Copy the Invite Link, not just the code
    const inviteLink = `${window.location.origin}?invite=${circleId}`;
    navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    onShowToast('Invite Link Copied', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    const inviteLink = `${window.location.origin}?invite=${circleId}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Join ${circleName} on APEX`,
          text: `I'm inviting you to my circle '${circleName}' on APEX. Join here:`,
          url: inviteLink, 
        });
        onShowToast('Invite Sent', 'success');
      } catch (e) {
        console.error('Error sharing', e);
      }
    } else {
      copyToClipboard();
    }
  };

  const handleNudge = async (member: Member) => {
    if (nudgedUsers.has(member.userId)) return;

    try {
        setNudgedUsers(prev => new Set(prev).add(member.userId));
        
        await supabase.from('messages').insert({
            circle_id: circleId,
            user_id: currentUserId,
            content: `@${member.username} ⚠️ NO PROOF DETECTED. EXECUTE.`
        });
        
        onShowToast(`Nudged @${member.username}`, 'neutral');

    } catch (e) {
        console.error("Failed to nudge", e);
        onShowToast('Failed to send nudge', 'error');
    }
  };

  const handleLeaveCircle = async () => {
      if (!window.confirm("Are you sure you want to leave this circle? Your streak will be lost.")) return;
      
      try {
          const { error } = await supabase
            .from('circle_members')
            .delete()
            .match({ circle_id: circleId, user_id: currentUserId });
            
          if (error) throw error;
          
          onShowToast('Left Circle', 'neutral');
          onLeave();
          onClose();
      } catch (e) {
          console.error("Error leaving circle", e);
          onShowToast('Failed to leave circle', 'error');
      }
  };

  const handleDelete = async () => {
    if (!window.confirm("CRITICAL WARNING: This will permanently DELETE the circle and all its history. There is no undo.")) return;
    onDeleteCircle();
  };

  const handleKick = async (userId: string, username: string) => {
    if (!window.confirm(`Are you sure you want to kick ${username} from the circle?`)) return;
    
    try {
        setProcessingAction(userId);
        await onKickMember(userId);
        setMembers(prev => prev.filter(m => m.userId !== userId));
        onShowToast(`Removed ${username}`, 'neutral');
    } catch (e) {
        console.error(e);
        onShowToast('Failed to remove member', 'error');
    } finally {
        setProcessingAction(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[80vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center shrink-0">
          <div>
            <h2 className="font-bold text-white text-lg leading-none">{circleName}</h2>
            <div className="flex items-center gap-2 mt-1">
                <p className="text-xs text-apex-muted uppercase tracking-widest">Roster & Access</p>
                {isCreator && <span className="bg-apex-primary/20 text-apex-primary text-[9px] font-bold px-1.5 rounded uppercase">Admin</span>}
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Invite Code Section */}
        <div className="p-6 bg-zinc-950 border-b border-zinc-800 shrink-0">
            <label className="text-xs font-bold text-zinc-500 uppercase mb-2 block">Circle ID (Invite Code)</label>
            <div className="flex gap-2">
                <button 
                    onClick={copyToClipboard}
                    className="flex-1 flex items-center justify-between bg-zinc-900 border border-zinc-800 rounded-xl p-4 group hover:border-zinc-700 transition-colors"
                >
                    <code className="text-sm font-mono text-apex-primary truncate mr-4">{circleId}</code>
                    {copied ? (
                        <Check size={16} className="text-white" />
                    ) : (
                        <Copy size={16} className="text-zinc-500 group-hover:text-white" />
                    )}
                </button>
                <button
                    onClick={handleShare}
                    className="w-14 flex items-center justify-center bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 transition-colors"
                    title="Share Invite Link"
                >
                    <Share size={20} className="text-white" />
                </button>
            </div>
            <p className="text-[10px] text-zinc-600 mt-2 text-center">
                Share this link with your trusted circle only.
            </p>
        </div>

        {/* Members List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 min-h-0">
            {loading ? (
                <div className="text-center py-8 text-zinc-500 text-xs animate-pulse">Loading roster...</div>
            ) : members.map((member) => (
                <div key={member.userId} className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-zinc-800/50">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-zinc-800 overflow-hidden relative">
                            {member.avatarUrl ? (
                                <img src={member.avatarUrl} alt={member.username} className="w-full h-full object-cover" />
                            ) : (
                                <User className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-zinc-600" />
                            )}
                        </div>
                        <div>
                            <p className="text-sm font-bold text-white flex items-center gap-2">
                                {member.username}
                                {member.userId === currentUserId && <span className="text-[10px] text-zinc-500">(YOU)</span>}
                                {member.userId === member.userId && isCreator && member.userId !== currentUserId && processingAction === member.userId && <span className="text-[10px] text-red-500 animate-pulse">REMOVING...</span>}
                            </p>
                            <p className="text-[10px] text-zinc-500 font-mono">
                                JOINED {new Date(member.joinedAt).toLocaleDateString()}
                            </p>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                        {member.hasPostedToday ? (
                            <div className="flex items-center gap-2 bg-emerald-950/30 border border-emerald-900/50 px-2 py-1 rounded-md">
                                <div className="w-2 h-2 bg-apex-primary rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                                <span className="text-[10px] font-bold text-apex-primary">DONE</span>
                            </div>
                        ) : (
                             member.userId !== currentUserId ? (
                                <button 
                                    onClick={() => handleNudge(member)}
                                    disabled={nudgedUsers.has(member.userId)}
                                    className={`flex items-center gap-1 px-2 py-1 rounded-md border text-[10px] font-bold uppercase transition-all ${
                                        nudgedUsers.has(member.userId) 
                                        ? 'bg-zinc-800 border-zinc-700 text-zinc-500 cursor-not-allowed' 
                                        : 'bg-red-950/20 border-red-900/50 text-red-500 hover:bg-red-900/40'
                                    }`}
                                >
                                    <Bell size={10} />
                                    <span>{nudgedUsers.has(member.userId) ? 'SENT' : 'SHAME'}</span>
                                </button>
                             ) : (
                                <span className="text-[10px] text-zinc-600 font-mono">PENDING</span>
                             )
                        )}

                        {/* Admin Action: Kick */}
                        {isCreator && member.userId !== currentUserId && (
                             <button 
                                onClick={() => handleKick(member.userId, member.username)}
                                disabled={processingAction === member.userId}
                                className="p-1.5 text-zinc-600 hover:text-red-500 transition-colors"
                                title="Kick Member"
                            >
                                <Trash2 size={14} />
                             </button>
                        )}
                    </div>
                </div>
            ))}
        </div>
        
        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950 flex flex-col gap-2">
            {isCreator ? (
                <>
                 <button 
                    onClick={onEditCircle}
                    className="w-full flex items-center justify-center gap-2 text-zinc-400 hover:text-white hover:bg-zinc-900 rounded-lg text-xs font-bold uppercase tracking-widest py-3 transition-colors border border-zinc-800 hover:border-zinc-700"
                >
                    <Settings size={14} />
                    <span>Edit Protocols</span>
                </button>
                 <button 
                    onClick={handleDelete}
                    className="w-full flex items-center justify-center gap-2 text-red-600 hover:text-red-500 hover:bg-red-950/20 rounded-lg text-xs font-bold uppercase tracking-widest py-3 transition-colors border border-transparent hover:border-red-900/50"
                >
                    <Trash2 size={14} />
                    <span>Delete Circle Protocol</span>
                </button>
                </>
            ) : (
                <button 
                    onClick={handleLeaveCircle}
                    className="w-full flex items-center justify-center gap-2 text-red-500/50 hover:text-red-500 text-xs font-bold uppercase tracking-widest py-2 transition-colors"
                >
                    <LogOut size={14} />
                    <span>Leave Circle</span>
                </button>
            )}
        </div>

      </div>
    </div>
  );
};
