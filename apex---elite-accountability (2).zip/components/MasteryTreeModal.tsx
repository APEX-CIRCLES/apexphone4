
import React, { useState } from 'react';
import { X, Trophy, Lock, CheckCircle2, ChevronRight, ArrowLeft, Star, Shield } from 'lucide-react';
import { CheckInType } from '../types';
import { MASTERY_TRACKS } from '../lib/mastery';

interface MasteryTreeModalProps {
  unlockedKeys: Set<string>;
  onClose: () => void;
}

export const MasteryTreeModal: React.FC<MasteryTreeModalProps> = ({ unlockedKeys, onClose }) => {
  const [selectedType, setSelectedType] = useState<CheckInType>(CheckInType.GYM);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(true);
  
  const tracks = MASTERY_TRACKS[selectedType] || [];
  
  // Split tracks
  const coreTracks = tracks.filter(t => t.category === 'CORE').sort((a, b) => a.level - b.level);
  const sideTracks = tracks.filter(t => t.category === 'SIDE').sort((a, b) => a.level - b.level);

  const handleSelectType = (type: CheckInType) => {
      setSelectedType(type);
      setIsMobileMenuOpen(false); 
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex items-center justify-center p-0 md:p-4">
      {/* Desktop Backdrop */}
      <div className="absolute inset-0 z-0 hidden md:block" onClick={onClose} />
      
      <div className="relative z-10 w-full h-full md:h-[85vh] max-w-4xl bg-zinc-950 md:border border-zinc-800 md:rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row animate-in fade-in zoom-in duration-300 pointer-events-auto">
        
        {/* SIDEBAR */}
        <div className={`
            w-full md:w-64 border-b md:border-b-0 md:border-r border-zinc-800 bg-zinc-900/30 flex flex-col shrink-0
            ${isMobileMenuOpen ? 'flex h-full' : 'hidden md:flex h-full'}
        `}>
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between md:justify-start gap-2 shrink-0 bg-zinc-900/50 backdrop-blur sticky top-0 z-20">
                <div className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-500" />
                    <h2 className="font-bold uppercase tracking-wider text-sm text-white">Compendium</h2>
                </div>
                <button onClick={onClose} className="md:hidden text-zinc-500 hover:text-white p-2">
                    <X size={20} />
                </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1 min-h-0">
                {Object.values(CheckInType).map(type => {
                    const typeTracks = MASTERY_TRACKS[type] || [];
                    const unlockedCount = typeTracks.filter(t => unlockedKeys.has(t.key)).length;
                    const totalCount = typeTracks.length;
                    const percent = Math.round((unlockedCount / totalCount) * 100);
                    const isSelected = selectedType === type;

                    return (
                        <button
                            key={type}
                            onClick={() => handleSelectType(type)}
                            className={`w-full text-left px-3 py-3 rounded-xl flex items-center justify-between transition-all group cursor-pointer ${
                                isSelected && !isMobileMenuOpen
                                ? 'bg-zinc-800 border border-zinc-700' 
                                : 'hover:bg-zinc-900 border border-transparent'
                            }`}
                        >
                            <div className="flex flex-col">
                                <span className={`text-xs font-bold uppercase ${isSelected && !isMobileMenuOpen ? 'text-white' : 'text-zinc-500 group-hover:text-zinc-300'}`}>
                                    {type.replace('_', ' ')}
                                </span>
                                <div className="w-12 h-1 bg-zinc-800 rounded-full mt-1.5 overflow-hidden">
                                    <div 
                                        className={`h-full ${percent === 100 ? 'bg-yellow-500' : 'bg-zinc-600'}`} 
                                        style={{ width: `${percent}%` }}
                                    />
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                {percent === 100 && <Trophy size={12} className="text-yellow-500" />}
                                <ChevronRight size={16} className="text-zinc-700 md:hidden" />
                            </div>
                        </button>
                    )
                })}
            </div>
        </div>

        {/* MAIN CONTENT */}
        <div className={`
            flex-1 flex flex-col min-w-0 min-h-0 bg-black/50 relative
            ${!isMobileMenuOpen ? 'flex h-full' : 'hidden md:flex h-full'}
        `}>
            <div className="p-4 md:p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50 shrink-0 sticky top-0 z-20 backdrop-blur">
                <div className="flex items-center gap-3">
                    <button 
                        onClick={() => setIsMobileMenuOpen(true)}
                        className="md:hidden p-1.5 bg-zinc-800 rounded-full text-zinc-400 hover:text-white"
                    >
                        <ArrowLeft size={16} />
                    </button>
                    <div>
                        <h1 className="text-lg md:text-xl font-black italic uppercase text-white tracking-tighter">
                            {selectedType.replace('_', ' ')}
                        </h1>
                        <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest mt-0.5">
                            Progression Track
                        </p>
                    </div>
                </div>
                <button onClick={onClose} className="hidden md:block text-zinc-500 hover:text-white transition-colors p-2">
                    <X size={24} />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 md:p-8 relative min-h-0 overscroll-contain">
                
                {/* SECTION 1: THE CORE PATH */}
                <div className="mb-10">
                    <div className="flex items-center gap-2 mb-6">
                        <Shield size={16} className="text-apex-primary" />
                        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Main Quest</h3>
                    </div>

                    <div className="relative pl-4">
                        {/* Vertical Line */}
                        <div className="absolute left-[23px] top-4 bottom-10 w-0.5 bg-zinc-800 z-0" />

                        <div className="space-y-8 relative z-10">
                            {coreTracks.map((milestone, index) => {
                                const isUnlocked = unlockedKeys.has(milestone.key);
                                const previousUnlocked = index === 0 || unlockedKeys.has(coreTracks[index - 1].key);
                                const isLocked = !isUnlocked;
                                const isNext = isLocked && previousUnlocked;

                                return (
                                    <div key={milestone.key} className={`flex gap-4 md:gap-6 group ${isLocked && !isNext ? 'opacity-50 grayscale' : 'opacity-100'}`}>
                                        {/* Icon Node */}
                                        <div className={`w-8 h-8 rounded-full border-4 shrink-0 z-10 flex items-center justify-center transition-all duration-500 ${
                                            isUnlocked 
                                            ? 'bg-yellow-500 border-yellow-600 shadow-[0_0_15px_rgba(234,179,8,0.5)]' 
                                            : isNext 
                                                ? 'bg-zinc-900 border-zinc-700 animate-pulse ring-2 ring-apex-primary/50'
                                                : 'bg-zinc-950 border-zinc-800'
                                        }`}>
                                            {isUnlocked ? (
                                                <Trophy size={12} className="text-black" fill="currentColor" />
                                            ) : (
                                                <Lock size={12} className="text-zinc-700" />
                                            )}
                                        </div>

                                        {/* Content Card */}
                                        <div className={`flex-1 p-4 rounded-xl border transition-all duration-300 ${
                                            isUnlocked 
                                            ? 'bg-yellow-950/10 border-yellow-900/30' 
                                            : isNext
                                                ? 'bg-zinc-900 border-zinc-700'
                                                : 'bg-zinc-900/30 border-zinc-800'
                                        }`}>
                                            <div className="flex justify-between items-start mb-2">
                                                <h3 className={`font-bold uppercase text-sm leading-tight ${isUnlocked ? 'text-yellow-500' : 'text-zinc-300'}`}>
                                                    {milestone.label}
                                                </h3>
                                                {isUnlocked && <CheckCircle2 size={16} className="text-yellow-500 shrink-0 ml-2" />}
                                            </div>
                                            
                                            <p className={`text-xs leading-relaxed mb-3 ${isUnlocked ? 'text-zinc-300' : 'text-zinc-500 font-medium'}`}>
                                                {milestone.description}
                                            </p>

                                            <div className="text-[10px] font-mono text-zinc-600 uppercase tracking-wide flex items-center gap-2">
                                                <span className={`px-1.5 py-0.5 rounded ${isUnlocked ? 'bg-yellow-500/20 text-yellow-600' : 'bg-zinc-800'}`}>
                                                    Level {milestone.level}
                                                </span>
                                                {isNext && <span className="text-apex-primary animate-pulse">CURRENT OBJECTIVE</span>}
                                                {isLocked && !isNext && <span>LOCKED</span>}
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </div>

                {/* SECTION 2: SIDE QUESTS */}
                {sideTracks.length > 0 && (
                    <div>
                        <div className="flex items-center gap-2 mb-4 pt-6 border-t border-zinc-800/50">
                            <Star size={16} className="text-purple-500" />
                            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Side Quests</h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {sideTracks.map((milestone) => {
                                const isUnlocked = unlockedKeys.has(milestone.key);
                                
                                return (
                                    <div key={milestone.key} className={`p-4 rounded-xl border transition-all duration-300 ${
                                        isUnlocked 
                                        ? 'bg-purple-950/10 border-purple-900/30' 
                                        : 'bg-zinc-900/30 border-zinc-800 hover:border-zinc-700'
                                    }`}>
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center gap-2">
                                                {isUnlocked ? (
                                                    <Trophy size={14} className="text-purple-500" />
                                                ) : (
                                                    <div className="w-3.5 h-3.5 rounded-full border-2 border-zinc-700" />
                                                )}
                                                <h3 className={`font-bold uppercase text-xs leading-tight ${isUnlocked ? 'text-purple-400' : 'text-zinc-400'}`}>
                                                    {milestone.label}
                                                </h3>
                                            </div>
                                        </div>
                                        
                                        <p className="text-[11px] text-zinc-500 leading-snug">
                                            {milestone.description}
                                        </p>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                )}

            </div>
        </div>

      </div>
    </div>
  );
};
