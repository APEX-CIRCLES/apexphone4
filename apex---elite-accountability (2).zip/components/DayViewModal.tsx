
import React from 'react';
import { X, Calendar, Clock, Activity } from 'lucide-react';
import { Post } from '../types';

interface DayViewModalProps {
  date: string;
  post: Post | null;
  onClose: () => void;
}

export const DayViewModal: React.FC<DayViewModalProps> = ({ date, post, onClose }) => {
  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl relative">
        
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start z-10 bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center gap-2 bg-black/50 backdrop-blur px-3 py-1.5 rounded-full border border-white/10">
            <Calendar size={14} className="text-apex-primary" />
            <span className="text-xs font-bold text-white uppercase">{formatDate(date)}</span>
          </div>
          <button 
            onClick={onClose}
            className="p-2 bg-black/50 backdrop-blur rounded-full text-white hover:bg-white/20 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {post ? (
            <>
                <div className="relative aspect-[4/5] bg-zinc-900">
                    <img 
                        src={post.imageUrl} 
                        alt="Proof" 
                        className="w-full h-full object-cover"
                    />
                </div>

                <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                             <div className={`p-1.5 rounded bg-zinc-900 border border-zinc-800 text-apex-primary`}>
                                <Activity size={16} />
                             </div>
                             <div>
                                 <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Activity</p>
                                 <p className="text-sm font-bold text-white uppercase">{post.type.replace('_', ' ')}</p>
                             </div>
                        </div>
                        <div className="text-right">
                             <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider flex items-center justify-end gap-1">
                                <Clock size={10} />
                                Time
                             </p>
                             <p className="text-sm font-bold text-white font-mono">{formatTime(post.timestamp)}</p>
                        </div>
                    </div>

                    {post.caption && (
                        <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4">
                            <p className="text-sm text-zinc-300 italic">"{post.caption}"</p>
                        </div>
                    )}
                </div>
            </>
        ) : (
            <div className="aspect-square flex flex-col items-center justify-center p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center mb-4">
                    <X size={32} className="text-zinc-700" />
                </div>
                <h3 className="text-white font-bold uppercase tracking-wide mb-2">No Data Recorded</h3>
                <p className="text-xs text-zinc-500">
                    The archives show no activity for this date.
                    <br />Consistency is the only metric that matters.
                </p>
            </div>
        )}
      </div>
    </div>
  );
};
