
import React, { useMemo, useState } from 'react';
import { X, BarChart3, TrendingUp, Calendar, Activity } from 'lucide-react';
import { Post, CheckInType } from '../types';
import { calculateStats } from '../lib/analytics';

interface StatsModalProps {
  posts: Post[];
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({ posts, onClose }) => {
  const stats = useMemo(() => calculateStats(posts), [posts]);
  const [selectedType, setSelectedType] = useState<CheckInType | 'ALL'>('ALL');

  const availableTypes = Object.keys(stats) as CheckInType[];

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <BarChart3 className="w-5 h-5 text-blue-500" />
            </div>
            <div>
                <h2 className="font-black italic uppercase tracking-tighter text-white text-xl">Tactician</h2>
                <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest">Performance Analytics</p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Filter */}
        <div className="p-4 border-b border-zinc-800 bg-zinc-900/30 overflow-x-auto hide-scrollbar">
            <div className="flex gap-2">
                <button
                    onClick={() => setSelectedType('ALL')}
                    className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase whitespace-nowrap border transition-all ${
                        selectedType === 'ALL'
                        ? 'bg-white text-black border-white'
                        : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                    }`}
                >
                    Overview
                </button>
                {availableTypes.map(t => (
                    <button
                        key={t}
                        onClick={() => setSelectedType(t)}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase whitespace-nowrap border transition-all ${
                            selectedType === t
                            ? 'bg-blue-500 text-white border-blue-500'
                            : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                        }`}
                    >
                        {t.replace('_', ' ')}
                    </button>
                ))}
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {availableTypes.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 text-xs italic">
                    Not enough data to generate intelligence.
                </div>
            ) : (
                (selectedType === 'ALL' ? availableTypes : [selectedType]).map(type => {
                    const data = stats[type];
                    if (!data) return null;

                    return (
                        <div key={type} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                             <div className="flex items-center justify-between mb-3">
                                <h3 className="font-bold text-white uppercase tracking-wider text-sm">{type.replace('_', ' ')}</h3>
                                <div className="text-[10px] font-mono text-zinc-500">
                                    {data.count} SESSIONS
                                </div>
                             </div>
                             
                             <div className="grid grid-cols-2 gap-3">
                                 {Object.values(data.metrics).map(metric => (
                                     <div key={metric.label} className="bg-zinc-900/50 border border-zinc-800 p-3 rounded-xl">
                                         <p className="text-[9px] font-bold text-zinc-500 uppercase mb-1">{metric.label}</p>
                                         <div className="flex items-end justify-between">
                                             <div>
                                                 <span className="text-lg font-black text-white">{metric.total.toLocaleString()}</span>
                                                 <span className="text-[10px] text-zinc-600 font-bold ml-1">{metric.unit}</span>
                                             </div>
                                             <div className="text-right">
                                                 <div className="text-[9px] text-zinc-500">MAX</div>
                                                 <div className="text-xs font-bold text-emerald-500">{metric.max.toLocaleString()}</div>
                                             </div>
                                         </div>
                                     </div>
                                 ))}
                                 
                                 {/* Last Session Indicator */}
                                 <div className="bg-zinc-900/50 border border-zinc-800 p-3 rounded-xl col-span-2 flex items-center justify-between">
                                     <div className="flex items-center gap-2">
                                        <Calendar size={14} className="text-zinc-500" />
                                        <span className="text-[10px] font-bold text-zinc-500 uppercase">Last Session</span>
                                     </div>
                                     <span className="text-xs font-mono text-white">
                                         {new Date(data.lastSession).toLocaleDateString()}
                                     </span>
                                 </div>
                             </div>
                        </div>
                    );
                })
            )}
        </div>
      </div>
    </div>
  );
};
