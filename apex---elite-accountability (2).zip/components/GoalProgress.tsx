
import React from 'react';
import { Goal } from '../types';
import { Check, Target, Flame } from 'lucide-react';
import { HABIT_CONFIG } from '../lib/habit-config';

interface GoalProgressProps {
  goal: Goal;
}

const COLORS: Record<string, string> = {
    GYM: 'bg-emerald-500',
    RUNNING: 'bg-orange-500',
    READING: 'bg-blue-500',
    DEEP_WORK: 'bg-purple-500',
    MEDITATION: 'bg-indigo-500',
    COLD_PLUNGE: 'bg-cyan-500',
    EARLY_RISE: 'bg-amber-500',
    FASTING: 'bg-rose-500',
    STEPS: 'bg-lime-500',
    JOURNALING: 'bg-stone-500',
    DIET: 'bg-green-500',
    RUCKING: 'bg-yellow-600',
};

export const GoalProgress: React.FC<GoalProgressProps> = ({ goal }) => {
  const color = COLORS[goal.activityType] || 'bg-white';
  const progress = goal.progress || 0;
  const isComplete = progress >= goal.targetCount;
  
  const percentage = Math.min(100, (progress / goal.targetCount) * 100);

  // Format Requirement Label
  let requirementLabel = goal.title || goal.subGoal || goal.activityType.replace('_', ' ');
  
  if (!goal.title && goal.metricTarget) {
      const keys = Object.keys(goal.metricTarget);
      if (keys.length > 0) {
          const key = keys[0];
          const val = goal.metricTarget[key];
          const config = HABIT_CONFIG[goal.activityType]?.metrics.find(m => m.key === key);
          requirementLabel += ` • ${val}${config?.unit || ''}`;
      }
  }

  return (
    <div className="mb-3 last:mb-0">
        <div className="flex justify-between items-end mb-1">
            <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${color}`} />
                <div className="flex flex-col">
                    <span className="text-xs font-bold text-white uppercase leading-none">{requirementLabel}</span>
                    <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] text-zinc-500 font-mono uppercase">
                            {goal.frequency === 'DAILY' ? 'DAILY' : goal.frequency === 'WEEKLY' ? `${goal.targetCount}x WEEKLY` : 'CUSTOM SCHEDULE'}
                        </span>
                        {/* Goal Streak */}
                        {(goal.currentStreak || 0) > 0 && (
                            <div className="flex items-center gap-0.5 text-orange-500">
                                <Flame size={10} fill="currentColor" />
                                <span className="text-[9px] font-bold">{goal.currentStreak}</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            <div className="text-xs font-mono font-bold text-zinc-400">
                <span className={isComplete ? 'text-emerald-500' : 'text-white'}>{progress}</span>/{goal.targetCount}
            </div>
        </div>
        
        <div className="h-2 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
            <div 
                className={`h-full transition-all duration-1000 ${isComplete ? 'bg-emerald-500' : color}`}
                style={{ width: `${percentage}%` }}
            />
        </div>
    </div>
  );
};
