
import React, { useState, useEffect } from 'react';
import { Share, PlusSquare, X } from 'lucide-react';

export const InstallPrompt = () => {
  const [show, setShow] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if standalone (already installed)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
    
    // Check if iOS
    const ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(ios);

    // Only show if NOT installed and IS mobile
    if (!isStandalone && /Mobi|Android/i.test(navigator.userAgent)) {
        // Delay slightly
        const timer = setTimeout(() => setShow(true), 3000);
        return () => clearTimeout(timer);
    }
  }, []);

  if (!show) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[200] p-4 animate-in slide-in-from-bottom-4 duration-500">
      <div className="bg-zinc-900/95 backdrop-blur-md border border-zinc-800 rounded-2xl p-4 shadow-2xl relative">
        <button 
            onClick={() => setShow(false)} 
            className="absolute top-2 right-2 p-2 text-zinc-500 hover:text-white"
        >
            <X size={20} />
        </button>

        <div className="flex items-start gap-4 pr-6">
            <div className="w-12 h-12 bg-apex-primary rounded-xl flex items-center justify-center shrink-0 shadow-lg">
                <span className="font-black italic text-black text-xl">A</span>
            </div>
            <div>
                <h3 className="font-bold text-white text-sm">Install APEX App</h3>
                <p className="text-xs text-zinc-400 mt-1 leading-snug">
                    For the full fullscreen experience and notifications, add to your home screen.
                </p>
            </div>
        </div>

        {isIOS ? (
            <div className="mt-4 flex items-center gap-2 text-xs font-bold text-zinc-400 bg-black/40 p-3 rounded-lg border border-white/5">
                <span>1. Tap</span>
                <Share size={16} className="text-blue-500" />
                <span>2. Select</span>
                <span className="flex items-center gap-1 text-white"><PlusSquare size={16} /> Add to Home Screen</span>
            </div>
        ) : (
            <div className="mt-4 p-2">
                <p className="text-xs text-zinc-500 text-center">Tap the menu icon and select "Install App" or "Add to Home Screen"</p>
            </div>
        )}
      </div>
    </div>
  );
};
