
import React, { useState, useRef, useEffect } from 'react';
import { LogOut, Camera, Save, Loader2, Flame, Target, Plus, BarChart3, ChevronRight, Archive, Trophy, FileText, Snowflake, Download, Info, Settings, Edit2, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { User as UserType, Post, CheckInType, Goal } from '../types';
import { getRank, getRankColor, compressImage } from '../lib/utils';
import { MASTERY_TRACKS, Milestone } from '../lib/mastery';
import { GoalProgress } from './GoalProgress';

interface ProfileViewProps {
  user: UserType;
  // Data passed from parent
  allPosts: Post[];
  unlockedKeys: Set<string>;
  goals: Goal[];
  loadingData: boolean;
  
  // Actions
  onUpdateProfile: (username: string, avatarUrl: string) => Promise<void>;
  onSignOut: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'neutral') => void;
  onShowManifesto?: () => void;
  onOpenGoalModal?: () => void;
  onOpenStats: () => void;
  onOpenMastery: () => void;
  onDeleteGoal: (id: string) => void;
  onShowRankHelp: () => void;
  onOpenSettings: () => void;
  onEditGoal?: (goal: Goal) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ 
    user, 
    allPosts,
    unlockedKeys,
    goals,
    loadingData,
    onUpdateProfile, 
    onSignOut, 
    onShowToast, 
    onShowManifesto, 
    onOpenGoalModal,
    onOpenStats,
    onOpenMastery,
    onDeleteGoal,
    onShowRankHelp,
    onOpenSettings,
    onEditGoal
}) => {
  const [username, setUsername] = useState(user.username);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isPWA, setIsPWA] = useState(true);
  
  // Local UI State for History Grid
  const [historyLimit, setHistoryLimit] = useState(21);
  
  const [highestMilestones, setHighestMilestones] = useState<Map<string, string>>(new Map());

  const rank = getRank(user.streak);
  const rankColor = getRankColor(rank);

  useEffect(() => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
      setIsPWA(isStandalone);
  }, []);

  // Calculate highest milestones when keys change
  useEffect(() => {
      const map = new Map<string, string>();
      Object.values(CheckInType).forEach(type => {
             const track = MASTERY_TRACKS[type] || [];
             let highest: Milestone | null = null;
             track.forEach(m => {
                 if (unlockedKeys.has(m.key)) {
                     highest = m;
                 }
             });
             
             if (highest) {
                 map.set(type, (highest as Milestone).label);
             }
      });
      setHighestMilestones(map);
  }, [unlockedKeys]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    
    try {
      setLoading(true);
      
      // Compress and standardize to JPG
      const compressedFile = await compressImage(file);
      
      // Use standard User Folder path. Using upsert: false and unique timestamp to avoid RLS update blocks.
      const timestamp = Date.now();
      const fileName = `${user.id}/${timestamp}_avatar.jpg`;

      const { error: uploadError } = await supabase.storage
        .from('proof-images') 
        .upload(fileName, compressedFile, {
            upsert: false, // Changed to false to prevent 'update' policy violations
            contentType: 'image/jpeg'
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('proof-images')
        .getPublicUrl(fileName);

      // Force cache bust
      const finalUrl = `${publicUrl}?t=${timestamp}`;

      await onUpdateProfile(username, finalUrl);
      onShowToast('Avatar Updated', 'success');
    } catch (error: any) {
      console.error('Error uploading avatar:', error);
      onShowToast(`Upload failed: ${error.message || 'Unknown error'}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      await onUpdateProfile(username, user.avatarUrl);
      setIsEditing(false);
      onShowToast('Profile Updated', 'success');
    } catch (error) {
      console.error('Error updating profile:', error);
      onShowToast('Update Failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const displayedHistory = allPosts.slice(0, historyLimit);
  const hasMoreHistory = allPosts.length > historyLimit;

  return (
    <div className="p-6 pt-12 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
      
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-black italic tracking-tighter text-white">IDENTITY</h1>
        <div className="flex gap-2">
            {onShowManifesto && (
                <button 
                  onClick={onShowManifesto}
                  className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  title="View Manifesto"
                >
                  <FileText size={20} />
                </button>
            )}
            <button 
              onClick={onOpenSettings}
              className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
              title="Settings"
            >
              <Settings size={20} />
            </button>
        </div>
      </div>

      <div className="flex flex-col items-center mb-10">
        <label className="relative group cursor-pointer">
          <div className="w-32 h-32 rounded-full bg-zinc-800 border-4 border-zinc-900 overflow-hidden shadow-2xl relative">
            {loading ? (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                    <Loader2 className="animate-spin text-apex-primary" />
                </div>
            ) : (
                <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
            )}
          </div>
          <div className="absolute bottom-0 right-0 bg-apex-primary text-black p-2 rounded-full border-4 border-black group-hover:scale-110 transition-transform">
            <Camera size={20} />
          </div>
          <input 
            type="file" 
            className="hidden" 
            accept="image/*" 
            onChange={handleFileChange}
          />
        </label>

        <div className="mt-6 w-full max-w-xs">
            <label className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-1 block">Codename</label>
            <div className="relative">
                <input
                    type="text"
                    value={username}
                    disabled={!isEditing}
                    onChange={(e) => setUsername(e.target.value)}
                    className={`w-full bg-transparent border-b-2 py-2 text-xl font-bold font-mono text-center focus:outline-none ${
                        isEditing ? 'border-apex-primary text-white' : 'border-transparent text-zinc-300'
                    }`}
                />
                {!isEditing ? (
                    <button 
                        onClick={() => setIsEditing(true)}
                        className="absolute right-0 top-1/2 -translate-y-1/2 text-xs text-apex-primary font-bold uppercase hover:underline"
                    >
                        Edit
                    </button>
                ) : (
                    <button 
                        onClick={handleSave}
                        disabled={loading}
                        className="absolute right-0 top-1/2 -translate-y-1/2 text-apex-primary"
                    >
                        <Save size={20} />
                    </button>
                )}
            </div>
        </div>
      </div>

      {!isPWA && (
        <div className="mb-8 p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between shadow-xl animate-pulse">
            <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg text-black">
                    <Download size={20} />
                </div>
                <div>
                    <h3 className="text-white font-bold text-sm">Install App</h3>
                    <p className="text-[10px] text-zinc-500">Add to Home Screen for Full Access</p>
                </div>
            </div>
        </div>
      )}

      {/* Goals Section */}
      <div className="mb-8">
           <div className="flex items-center justify-between mb-4 px-1">
              <div className="flex items-center gap-2">
                  <Target size={16} className="text-zinc-500" />
                  <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Active Directives</h3>
              </div>
              <button onClick={onOpenGoalModal} className="text-apex-primary hover:text-white transition-colors">
                  <Plus size={16} />
              </button>
          </div>
          {goals.length === 0 ? (
               <div className="text-center py-6 border border-dashed border-zinc-800 rounded-xl bg-zinc-900/30 mb-2">
                  <p className="text-zinc-600 text-xs italic">No directives set.</p>
              </div>
          ) : (
              <div className="space-y-2">
                  {goals.map(goal => (
                      <div key={goal.id} className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex justify-between items-center group relative">
                           <div>
                               <div className="flex items-center gap-2">
                                   <div className={`w-2 h-2 rounded-full ${goal.activityType ? 'bg-apex-primary' : 'bg-white'}`} />
                                   <span className="text-sm font-bold text-white uppercase">{goal.title || goal.activityType.replace('_', ' ')}</span>
                               </div>
                               <span className="text-[10px] font-mono text-zinc-500 uppercase">
                                   {goal.frequency} • {goal.targetCount}x
                               </span>
                           </div>
                           
                           <div className="flex items-center gap-2 absolute right-4">
                               {onEditGoal && (
                                   <button 
                                    onClick={(e) => { 
                                        e.stopPropagation(); 
                                        e.preventDefault();
                                        onEditGoal(goal); 
                                    }} 
                                    className="p-1.5 text-zinc-400 hover:text-white rounded-md transition-colors"
                                   >
                                       <Edit2 size={16} />
                                   </button>
                               )}
                               <button 
                                onClick={(e) => { 
                                    e.stopPropagation(); 
                                    e.preventDefault();
                                    onDeleteGoal(goal.id); 
                                }} 
                                className="p-1.5 text-zinc-400 hover:text-red-500 rounded-md transition-colors"
                               >
                                   <Trash2 size={16} />
                               </button>
                           </div>
                      </div>
                  ))}
              </div>
          )}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
                <Flame className="text-orange-500" fill="currentColor" size={24} />
                <div className="text-3xl font-black text-white">{user.streak}</div>
            </div>
            <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Day Streak</div>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl text-center relative">
            <div className={`text-3xl font-black mb-1 ${rankColor}`}>{rank.toUpperCase()}</div>
            <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Current Status</div>
            <button onClick={onShowRankHelp} className="absolute top-2 right-2 text-zinc-600 hover:text-white">
                <Info size={14} />
            </button>
        </div>
      </div>
      
      {/* ANALYTICS BUTTON */}
      <div className="mb-4">
          <button 
            onClick={onOpenStats}
            className="w-full py-4 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-800 transition-colors group"
          >
              <BarChart3 className="text-blue-500 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold uppercase tracking-widest text-white">View Tactical Stats</span>
          </button>
      </div>

      {/* Freeze Tokens */}
      <div className="mb-8 bg-zinc-900 border border-zinc-800 p-4 rounded-2xl flex items-center justify-between">
         <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-full border border-blue-500/20">
                <Snowflake className="text-blue-500" size={20} />
            </div>
            <div>
                <div className="text-white font-bold">Freeze Tokens</div>
                <div className="text-[10px] text-zinc-500 uppercase tracking-wider">Safety Net Protocol</div>
            </div>
         </div>
         <div className="text-2xl font-black text-white">{user.freezeTokens || 0}</div>
      </div>

      {/* Mastery Levels - Interactive */}
      <button 
        onClick={onOpenMastery}
        className="w-full mb-8 text-left group transition-transform active:scale-[0.99]"
      >
           <div className="flex items-center justify-between mb-4 px-1">
              <div className="flex items-center gap-2">
                  <Trophy size={16} className="text-yellow-500" />
                  <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Mastery Levels</h3>
              </div>
              <ChevronRight size={16} className="text-zinc-600 group-hover:text-white transition-colors" />
          </div>
          <div className="grid grid-cols-2 gap-2">
             {Object.values(CheckInType).map(type => {
                 const currentLevel = highestMilestones.get(type);
                 return (
                    <div key={type} className="bg-zinc-900 border border-zinc-800 p-3 rounded-xl flex items-center justify-between group-hover:border-zinc-700 transition-colors">
                        <div>
                            <p className="text-[9px] font-bold text-zinc-500 uppercase">{type.replace('_', ' ')}</p>
                            <p className={`text-xs font-bold ${currentLevel ? 'text-white' : 'text-zinc-600 italic'}`}>
                                {currentLevel || 'Novice'}
                            </p>
                        </div>
                        {currentLevel && <Trophy size={14} className="text-yellow-500" fill="currentColor" />}
                    </div>
                 );
             })}
          </div>
      </button>

      <div className="mb-8">
          <div className="flex items-center gap-2 mb-4 px-1">
              <Archive size={16} className="text-zinc-500" />
              <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">The Vault</h3>
          </div>
          
          {loadingData ? (
              <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-zinc-600" />
              </div>
          ) : displayedHistory.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-zinc-800 rounded-xl bg-zinc-900/30">
                  <p className="text-zinc-600 text-xs italic">The Vault is empty.</p>
              </div>
          ) : (
              <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-1">
                    {displayedHistory.map(post => (
                        <div key={post.id} className="aspect-square bg-zinc-900 relative group overflow-hidden">
                            <img 
                                src={post.imageUrl} 
                                alt="history" 
                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                            />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <span className="text-[10px] font-bold text-white uppercase">{post.type}</span>
                            </div>
                            {post.milestoneKey && (
                                <div className="absolute top-1 right-1">
                                    <Trophy size={12} className="text-yellow-500" fill="currentColor" />
                                </div>
                            )}
                        </div>
                    ))}
                  </div>
                  {hasMoreHistory && (
                      <button 
                        onClick={() => setHistoryLimit(prev => prev + 21)}
                        className="w-full py-3 text-xs font-bold uppercase tracking-widest text-zinc-500 hover:text-white hover:bg-zinc-900 rounded-xl transition-colors"
                      >
                          Load Archived Protocols
                      </button>
                  )}
              </div>
          )}
      </div>

      <div className="bg-zinc-950 rounded-xl border border-zinc-900 p-6 text-center">
        <h3 className="text-xs font-bold text-zinc-600 uppercase tracking-widest mb-4">Membership Card</h3>
        <div className="font-mono text-xs text-zinc-500 break-all">
            ID: {user.id}
        </div>
        <div className="mt-4 inline-block px-3 py-1 rounded-full bg-zinc-900 text-[10px] text-zinc-400 font-bold border border-zinc-800">
            MEMBER SINCE {new Date().getFullYear()}
        </div>
      </div>
    </div>
  );
};
