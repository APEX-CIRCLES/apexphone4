
import React, { useState, useRef } from 'react';
import { X, Sparkles, Globe, Lock, Check, Camera, RefreshCw } from 'lucide-react';
import { CheckInType } from '../types';

interface CreateCircleModalProps {
  onClose: () => void;
  onSubmit: (name: string, description: string, theme: string, isPublic: boolean, allowedTypes: CheckInType[], imageFile: File | null) => void;
}

const THEMES = [
  { name: 'Emerald', hex: '#10b981' },
  { name: 'Blue', hex: '#3b82f6' },
  { name: 'Rose', hex: '#f43f5e' },
  { name: 'Amber', hex: '#f59e0b' },
  { name: 'Purple', hex: '#8b5cf6' },
];

export const CreateCircleModal: React.FC<CreateCircleModalProps> = ({ onClose, onSubmit }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [theme, setTheme] = useState(THEMES[0].hex);
  const [isPublic, setIsPublic] = useState(false);
  const [allowedTypes, setAllowedTypes] = useState<CheckInType[]>(Object.values(CheckInType));
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleType = (type: CheckInType) => {
    if (allowedTypes.includes(type)) {
      // Prevent removing the last one
      if (allowedTypes.length > 1) {
        setAllowedTypes(prev => prev.filter(t => t !== type));
      }
    } else {
      setAllowedTypes(prev => [...prev, type]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        setImageFile(file);
        setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async () => {
    if (!name) return;
    setIsSubmitting(true);
    await onSubmit(name, description, theme, isPublic, allowedTypes, imageFile);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header - Fixed at top */}
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900 shrink-0">
          <div className="flex items-center gap-2 text-white">
            <Sparkles className="w-5 h-5 text-apex-accent" />
            <h2 className="font-bold uppercase tracking-wider text-sm">Forge New Circle</h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Body - Scrollable */}
        <div className="p-6 space-y-6 overflow-y-auto">
          <div className="flex flex-col items-center">
             <label className="w-24 h-24 rounded-2xl bg-zinc-800 border-2 border-dashed border-zinc-700 flex items-center justify-center cursor-pointer hover:border-white transition-colors relative overflow-hidden group">
                {imagePreview ? (
                    <img src={imagePreview} className="w-full h-full object-cover" alt="Preview" />
                ) : (
                    <Camera className="text-zinc-500 group-hover:text-white" />
                )}
                {imagePreview && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <RefreshCw size={20} className="text-white" />
                    </div>
                )}
                <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
             </label>
             <p className="text-[10px] text-zinc-500 mt-2 uppercase font-bold tracking-wide">Circle Icon / Cover</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Circle Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. The 5AM Club"
              className="w-full bg-black border border-zinc-700 rounded-xl p-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-apex-primary transition-colors font-bold"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Mission (Optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Wake up. Attack. Win."
              className="w-full bg-black border border-zinc-700 rounded-xl p-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-apex-primary transition-colors"
            />
          </div>

          <div className="space-y-3">
             <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Allowed Protocols</label>
             <div className="grid grid-cols-2 gap-2">
                {Object.values(CheckInType).map(t => {
                    const isSelected = allowedTypes.includes(t);
                    return (
                        <button
                            key={t}
                            onClick={() => toggleType(t)}
                            className={`p-3 rounded-lg border text-xs font-bold uppercase transition-all flex items-center justify-between ${
                                isSelected 
                                ? 'bg-zinc-800 border-apex-primary text-white' 
                                : 'bg-black border-zinc-800 text-zinc-600 hover:border-zinc-700'
                            }`}
                        >
                            <span>{t.replace('_', ' ')}</span>
                            {isSelected && <Check size={14} className="text-apex-primary" />}
                        </button>
                    )
                })}
             </div>
             <p className="text-[10px] text-zinc-600">Select at least one habit type allowed for check-ins.</p>
          </div>

          <div className="space-y-3">
             <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Visibility</label>
             <div className="grid grid-cols-2 gap-3">
                <button
                    onClick={() => setIsPublic(false)}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                        !isPublic ? 'bg-zinc-800 border-white text-white' : 'bg-black border-zinc-800 text-zinc-500'
                    }`}
                >
                    <Lock size={20} />
                    <span className="text-xs font-bold uppercase">Private</span>
                </button>
                <button
                    onClick={() => setIsPublic(true)}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                        isPublic ? 'bg-zinc-800 border-white text-white' : 'bg-black border-zinc-800 text-zinc-500'
                    }`}
                >
                    <Globe size={20} />
                    <span className="text-xs font-bold uppercase">Public</span>
                </button>
             </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Theme Color</label>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {THEMES.map((t) => (
                <button
                  key={t.hex}
                  onClick={() => setTheme(t.hex)}
                  className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${
                    theme === t.hex ? 'border-white scale-110' : 'border-transparent opacity-50 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: t.hex }}
                >
                  {theme === t.hex && <div className="w-2 h-2 bg-white rounded-full" />}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={isSubmitting || !name}
            className={`w-full py-4 rounded-full font-bold uppercase tracking-widest text-sm transition-all ${
              name && !isSubmitting
                ? 'bg-white text-black hover:bg-zinc-200'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
          >
            {isSubmitting ? 'Forging...' : 'Initialize Circle'}
          </button>
        </div>
      </div>
    </div>
  );
};
