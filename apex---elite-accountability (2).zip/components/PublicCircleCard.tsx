
import React from 'react';
import { Users, Globe, ArrowRight } from 'lucide-react';

interface PublicCircleCardProps {
  id: string;
  name: string;
  description: string;
  theme: string;
  imageUrl?: string | null;
  onJoin: (id: string) => void;
  joining: boolean;
}

export const PublicCircleCard: React.FC<PublicCircleCardProps> = ({ id, name, description, theme, imageUrl, onJoin, joining }) => {
  return (
    <div className="bg-zinc-900/50 border border-zinc-800 p-5 rounded-2xl mb-3 relative overflow-hidden group">
      {/* Background Image */}
      {imageUrl && (
          <div className="absolute inset-0 z-0">
              <img 
                src={imageUrl} 
                alt="" 
                className="w-full h-full object-cover opacity-10 group-hover:opacity-20 transition-opacity blur-sm scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/90 to-transparent" />
          </div>
      )}

      <div className="absolute top-0 right-0 p-3 opacity-30 group-hover:opacity-100 transition-opacity z-10">
        <Globe size={16} className="text-zinc-500" />
      </div>
      
      <div className="flex items-start gap-4 mb-4 relative z-10">
        {imageUrl ? (
             <div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg border border-zinc-700 shrink-0 bg-black/30">
                <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
            </div>
        ) : (
            <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-black font-bold text-lg shrink-0"
                style={{ backgroundColor: theme }}
            >
                {name.substring(0, 1).toUpperCase()}
            </div>
        )}
        
        <div>
            <h3 className="font-bold text-white text-lg leading-tight drop-shadow-md">{name}</h3>
            <p className="text-xs text-zinc-400 mt-1 line-clamp-2 font-medium">{description || "No mission statement provided."}</p>
        </div>
      </div>

      <div className="flex items-center justify-between mt-2 relative z-10">
        <div className="flex items-center gap-1.5 text-zinc-500 text-[10px] font-mono uppercase tracking-widest bg-black/60 backdrop-blur px-2 py-1 rounded border border-zinc-800/50">
            <Users size={12} />
            <span>Open Squad</span>
        </div>
        
        <button 
            onClick={() => onJoin(id)}
            disabled={joining}
            className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wide hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 shadow-lg"
        >
            {joining ? 'Joining...' : 'Join'}
            {!joining && <ArrowRight size={14} />}
        </button>
      </div>
    </div>
  );
};
