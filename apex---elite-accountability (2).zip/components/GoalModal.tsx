
import React, { useState, useEffect } from 'react';
import { X, Target, Plus, Trash2, Settings2, Save } from 'lucide-react';
import { CheckInType, Goal } from '../types';
import { HABIT_CONFIG } from '../lib/habit-config';

interface GoalModalProps {
  onClose: () => void;
  onSubmit: (goal: Omit<Goal, 'id' | 'progress'>) => Promise<void>;
  activityTypes?: CheckInType[];
  circleId?: string;
  initialGoal?: Goal | null;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const GoalModal: React.FC<GoalModalProps> = ({ onClose, onSubmit, activityTypes, circleId, initialGoal }) => {
  // Initialize state with initialGoal if present, otherwise defaults
  const [type, setType] = useState<CheckInType>(
      initialGoal ? initialGoal.activityType : (activityTypes ? activityTypes[0] : CheckInType.GYM)
  );
  const [frequency, setFrequency] = useState<Goal['frequency']>(
      initialGoal ? initialGoal.frequency : 'WEEKLY'
  );
  const [targetCount, setTargetCount] = useState(
      initialGoal ? initialGoal.targetCount : 3
  );
  const [targetDays, setTargetDays] = useState<number[]>(
      initialGoal ? initialGoal.targetDays || [] : []
  );
  const [title, setTitle] = useState(
      initialGoal ? initialGoal.title || '' : ''
  );
  
  // Parse Metric Targets
  const [metricTargets, setMetricTargets] = useState<Record<string, number>>(
      initialGoal && initialGoal.metricTarget ? initialGoal.metricTarget : {}
  );

  const [currentMetricKey, setCurrentMetricKey] = useState<string>('');
  const [currentMetricValue, setCurrentMetricValue] = useState<string>('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const availableTypes = activityTypes || Object.values(CheckInType);
  const config = HABIT_CONFIG[type];

  // Reset metrics when type changes manually (not on init)
  useEffect(() => {
      if (initialGoal && type === initialGoal.activityType) return;
      setMetricTargets({});
      setCurrentMetricKey('');
      setCurrentMetricValue('');
  }, [type]);

  const toggleDay = (index: number) => {
    if (targetDays.includes(index)) {
        setTargetDays(prev => prev.filter(d => d !== index));
    } else {
        setTargetDays(prev => [...prev, index].sort());
    }
  };

  const addConstraint = () => {
      if (!currentMetricKey || !currentMetricValue) return;
      const val = parseFloat(currentMetricValue);
      if (isNaN(val) || val <= 0) return;

      setMetricTargets(prev => ({
          ...prev,
          [currentMetricKey]: val
      }));
      
      setCurrentMetricKey('');
      setCurrentMetricValue('');
  };

  const removeConstraint = (key: string) => {
      const newTargets = { ...metricTargets };
      delete newTargets[key];
      setMetricTargets(newTargets);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    await onSubmit({
        circleId: circleId, // Preserve context
        activityType: type,
        frequency,
        targetCount: frequency === 'WEEKLY' ? targetCount : frequency === 'DAILY' ? 7 : targetDays.length,
        targetDays: frequency === 'SPECIFIC_DAYS' ? targetDays : undefined,
        metricTarget: Object.keys(metricTargets).length > 0 ? metricTargets : undefined,
        title: title || undefined,
        subGoal: null
    });
    setIsSubmitting(false);
    onClose();
  };

  const availableMetrics = config.metrics.filter(m => m.type === 'number' || m.type === 'time');

  return (
    <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200 my-8">
        
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-950">
          <div className="flex items-center gap-2 text-white">
            <Target className="w-5 h-5 text-apex-primary" />
            <h2 className="font-bold uppercase tracking-wider text-sm">
                {initialGoal ? 'Edit Directive' : (circleId ? 'Set Circle Standard' : 'Set New Directive')}
            </h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
            
            {/* 1. Protocol Selector */}
            <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Protocol</label>
                <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
                    {availableTypes.map(t => (
                        <button 
                            key={t}
                            onClick={() => setType(t)}
                            className={`px-3 py-2 rounded-lg text-xs font-bold uppercase whitespace-nowrap transition-colors border ${
                                type === t 
                                ? 'bg-zinc-800 text-white border-apex-primary' 
                                : 'bg-black text-zinc-500 border-zinc-800'
                            }`}
                        >
                            {t.replace('_', ' ')}
                        </button>
                    ))}
                </div>
            </div>
            
            {/* 2. Directive Name */}
            <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Directive Name</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Hill Sprints, 75 Hard, Morning Routine"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-white text-sm focus:outline-none focus:border-white placeholder:text-zinc-700 font-bold"
                />
            </div>

            {/* 3. MULTI-METRIC ENFORCEMENT */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
                 <div className="flex items-center gap-2 mb-1">
                    <Settings2 size={14} className="text-apex-primary" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Performance Constraints</span>
                 </div>
                 
                 {/* Active Constraints List */}
                 {Object.keys(metricTargets).length > 0 && (
                     <div className="space-y-2 mb-3">
                         {Object.entries(metricTargets).map(([key, val]) => {
                             const label = config.metrics.find(m => m.key === key)?.label || key;
                             const unit = config.metrics.find(m => m.key === key)?.unit || '';
                             return (
                                 <div key={key} className="flex items-center justify-between bg-zinc-900 border border-zinc-800 px-3 py-2 rounded-lg animate-in slide-in-from-left-2">
                                     <span className="text-xs font-mono text-zinc-300 uppercase">
                                         <span className="text-zinc-500 font-bold mr-2">{label}:</span> 
                                         {val}{unit}
                                     </span>
                                     <button onClick={() => removeConstraint(key)} className="text-zinc-600 hover:text-red-500">
                                         <Trash2 size={14} />
                                     </button>
                                 </div>
                             )
                         })}
                     </div>
                 )}

                 {/* Add New Constraint */}
                 <div className="flex gap-2 items-end">
                    <div className="flex-1">
                        <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Metric</label>
                        <select 
                            value={currentMetricKey}
                            onChange={(e) => setCurrentMetricKey(e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-apex-primary"
                        >
                            <option value="">Select...</option>
                            {availableMetrics.map(m => (
                                <option key={m.key} value={m.key} disabled={!!metricTargets[m.key]}>{m.label} ({m.unit || ''})</option>
                            ))}
                        </select>
                    </div>
                    <div className="w-24">
                        <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Min Value</label>
                        <input 
                            type="number"
                            value={currentMetricValue}
                            onChange={(e) => setCurrentMetricValue(e.target.value)}
                            placeholder="0"
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-apex-primary font-mono"
                        />
                    </div>
                    <button 
                        onClick={addConstraint}
                        disabled={!currentMetricKey || !currentMetricValue}
                        className="h-[34px] px-3 bg-zinc-800 text-white rounded-lg hover:bg-apex-primary hover:text-black disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                        <Plus size={16} />
                    </button>
                 </div>
                 
                 {Object.keys(metricTargets).length > 0 && (
                     <p className="text-[10px] text-zinc-600 mt-2 italic">
                        * All constraints must be met for a valid check-in.
                     </p>
                 )}
            </div>

            {/* 4. Frequency Selector */}
            <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Schedule</label>
                <div className="grid grid-cols-3 gap-2">
                    <button
                        onClick={() => setFrequency('DAILY')}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                            frequency === 'DAILY' ? 'bg-zinc-800 border-white text-white' : 'bg-black border-zinc-800 text-zinc-500'
                        }`}
                    >
                        <span className="text-xs font-bold uppercase">Daily</span>
                    </button>
                    <button
                        onClick={() => setFrequency('WEEKLY')}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                            frequency === 'WEEKLY' ? 'bg-zinc-800 border-white text-white' : 'bg-black border-zinc-800 text-zinc-500'
                        }`}
                    >
                        <span className="text-xs font-bold uppercase">Weekly</span>
                    </button>
                    <button
                        onClick={() => setFrequency('SPECIFIC_DAYS')}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                            frequency === 'SPECIFIC_DAYS' ? 'bg-zinc-800 border-white text-white' : 'bg-black border-zinc-800 text-zinc-500'
                        }`}
                    >
                        <span className="text-xs font-bold uppercase">Specifics</span>
                    </button>
                </div>
            </div>

            {/* Frequency Config */}
            {frequency === 'WEEKLY' && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
                     <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Times Per Week</label>
                     <div className="flex items-center gap-4 bg-zinc-950 p-4 rounded-xl border border-zinc-800">
                        <button onClick={() => setTargetCount(Math.max(1, targetCount - 1))} className="w-8 h-8 rounded bg-zinc-900 text-white font-bold hover:bg-zinc-800">-</button>
                        <span className="text-2xl font-black text-white w-8 text-center">{targetCount}</span>
                        <button onClick={() => setTargetCount(Math.min(7, targetCount + 1))} className="w-8 h-8 rounded bg-zinc-900 text-white font-bold hover:bg-zinc-800">+</button>
                     </div>
                </div>
            )}

            {frequency === 'SPECIFIC_DAYS' && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Select Days</label>
                    <div className="grid grid-cols-7 gap-1">
                        {DAYS.map((day, idx) => (
                            <button
                                key={day}
                                onClick={() => toggleDay(idx)}
                                className={`aspect-square rounded flex items-center justify-center text-[10px] font-bold uppercase transition-all ${
                                    targetDays.includes(idx)
                                    ? 'bg-apex-primary text-black'
                                    : 'bg-zinc-900 text-zinc-600'
                                }`}
                            >
                                {day.substring(0, 1)}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="w-full py-4 rounded-full font-bold uppercase tracking-widest text-sm bg-white text-black hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
            >
                {isSubmitting ? 'Saving...' : initialGoal ? 'Update Directive' : 'Confirm Directive'}
            </button>
        </div>
      </div>
    </div>
  );
};
