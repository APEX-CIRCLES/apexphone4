
import React, { useState } from 'react';
import { Post, CheckInType } from '../types';
import { MessageCircle, Heart, Trash2, Dumbbell, BookOpen, Laptop, Footprints, Brain, Star, Trophy, Thermometer, Sun, Timer, Footprints as StepsIcon, PenTool, Utensils, Backpack, Tag, AlertTriangle, ShieldAlert, Gavel, Image as ImageIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getMilestone } from '../lib/mastery';
import { HABIT_CONFIG } from '../lib/habit-config';

interface FeedPostProps {
  post: Post;
  currentUserId: string;
  isCreator?: boolean;
  onDelete?: (postId: string) => void;
  onReply?: (username: string) => void;
  onToggleHallOfFame?: (post: Post) => void;
  onFlag?: (post: Post) => void;
  onPardon?: (post: Post) => void;
}

const ACTIVITY_CONFIG = {
  [CheckInType.GYM]: { icon: Dumbbell, color: 'text-emerald-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  [CheckInType.READING]: { icon: BookOpen, color: 'text-blue-500', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  [CheckInType.DEEP_WORK]: { icon: Laptop, color: 'text-purple-500', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  [CheckInType.RUNNING]: { icon: Footprints, color: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
  [CheckInType.MEDITATION]: { icon: Brain, color: 'text-indigo-500', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
  [CheckInType.COLD_PLUNGE]: { icon: Thermometer, color: 'text-cyan-400', bg: 'bg-cyan-400/10', border: 'border-cyan-400/20' },
  [CheckInType.EARLY_RISE]: { icon: Sun, color: 'text-amber-400', bg: 'bg-amber-400/10', border: 'border-amber-400/20' },
  [CheckInType.FASTING]: { icon: Timer, color: 'text-rose-400', bg: 'bg-rose-400/10', border: 'border-rose-400/20' },
  [CheckInType.STEPS]: { icon: StepsIcon, color: 'text-lime-400', bg: 'bg-lime-400/10', border: 'border-lime-400/20' },
  [CheckInType.JOURNALING]: { icon: PenTool, color: 'text-stone-400', bg: 'bg-stone-400/10', border: 'border-stone-400/20' },
  [CheckInType.DIET]: { icon: Utensils, color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20' },
  [CheckInType.RUCKING]: { icon: Backpack, color: 'text-yellow-600', bg: 'bg-yellow-600/10', border: 'border-yellow-600/20' },
};

export const FeedPost: React.FC<FeedPostProps> = ({ post, currentUserId, isCreator, onDelete, onReply, onToggleHallOfFame, onFlag, onPardon }) => {
  const [liked, setLiked] = useState(post.isLikedByCurrentUser || false);
  const [likes, setLikes] = useState(post.reactions);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const isMyPost = post.userId === currentUserId;
  const ActivityIcon = ACTIVITY_CONFIG[post.type]?.icon || Dumbbell;
  const theme = ACTIVITY_CONFIG[post.type] || ACTIVITY_CONFIG[CheckInType.GYM];
  
  const milestone = getMilestone(post.type, post.milestoneKey || null);
  const isContested = (post.flagCount || 0) > 0;
  
  const metricConfig = HABIT_CONFIG[post.type]?.metrics || [];

  const handleLike = async () => {
    if (isUpdating) return;
    
    // Optimistic Update
    const previousLiked = liked;
    const previousLikes = likes;
    
    setLiked(!liked);
    setLikes(prev => !liked ? prev + 1 : prev - 1);
    setIsUpdating(true);

    try {
      if (!previousLiked) {
        const { error } = await supabase.from('post_likes').insert({ user_id: currentUserId, post_id: post.id });
        if (error) throw error;
        await supabase.rpc('increment_likes', { post_id: post.id });
        if (!isMyPost) {
           await supabase.from('notifications').insert({
               user_id: post.userId,
               actor_id: currentUserId,
               type: 'LIKE',
               content: 'acknowledged your proof.',
               related_entity_id: post.id
           });
        }
      } else {
        const { error } = await supabase.from('post_likes').delete().match({ user_id: currentUserId, post_id: post.id });
        if (error) throw error;
        await supabase.rpc('decrement_likes', { post_id: post.id });
      }
    } catch (e) {
      setLiked(previousLiked);
      setLikes(previousLikes);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Are you sure?")) return;
    setIsDeleting(true);
    if (onDelete) await onDelete(post.id);
    setIsDeleting(false);
  };

  const timeAgo = (timestamp: number) => {
    const minutes = Math.floor((Date.now() - timestamp) / 60000);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h`;
  };

  return (
    <div className={`mb-8 last:mb-24 transition-opacity duration-500 ${isDeleting ? 'opacity-50' : 'opacity-100'}`}>
      
      {/* Header */}
      <div className="flex justify-between items-center mb-3 px-1">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-zinc-800 overflow-hidden border border-zinc-700">
            <img src={post.user?.avatar_url || `https://api.dicebear.com/9.x/dylan/svg?seed=${post.userId}`} alt="user" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center gap-2">
                <p className="text-sm font-bold text-white leading-none">{post.user?.username || 'User'}</p>
                {isContested && (
                    <span className="text-[9px] font-black bg-red-600 text-white px-1.5 rounded uppercase tracking-wide flex items-center gap-1">
                        <AlertTriangle size={8} className="fill-white" />
                        Contested
                    </span>
                )}
            </div>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
                <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded ${theme.bg} ${theme.border} border`}>
                    <ActivityIcon size={10} className={theme.color} />
                    <span className={`text-[9px] font-bold uppercase tracking-wider ${theme.color}`}>
                        {post.type.replace('_', ' ')}
                    </span>
                </div>
                {post.subActivity && (
                     <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800">
                        <Tag size={10} className="text-zinc-500" />
                        <span className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                            {post.subActivity}
                        </span>
                    </div>
                )}
                <span className="text-[10px] text-zinc-500 font-mono">• {timeAgo(post.timestamp)}</span>
            </div>
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex gap-2">
            {onToggleHallOfFame && (
                <button 
                    onClick={() => onToggleHallOfFame(post)}
                    className={`p-2 transition-colors ${post.isInHallOfFame ? 'text-yellow-500' : 'text-zinc-600 hover:text-yellow-500/50'}`}
                >
                    <Star size={16} fill={post.isInHallOfFame ? "currentColor" : "none"} />
                </button>
            )}
            
            {isCreator && isContested && !isMyPost ? (
                <>
                 <button onClick={() => onPardon && onPardon(post)} className="text-emerald-500 hover:bg-emerald-950/30 p-2 rounded transition-colors"><ShieldAlert size={16} /></button>
                 <button onClick={handleDelete} className="text-red-500 hover:bg-red-950/30 p-2 rounded transition-colors"><Gavel size={16} /></button>
                </>
            ) : isMyPost ? (
                <button onClick={handleDelete} disabled={isDeleting} className="text-zinc-600 hover:text-red-500 transition-colors p-2"><Trash2 size={16} /></button>
            ) : (
                <button onClick={() => onFlag && onFlag(post)} className={`p-2 transition-colors ${post.isFlaggedByCurrentUser ? 'text-red-500' : 'text-zinc-600 hover:text-red-500'}`} disabled={post.isFlaggedByCurrentUser}><AlertTriangle size={16} fill={post.isFlaggedByCurrentUser ? "currentColor" : "none"} /></button>
            )}
        </div>
      </div>

      {/* Media */}
      <div className={`relative rounded-2xl overflow-hidden aspect-[4/5] bg-zinc-900 border shadow-xl ${isContested ? 'border-red-500' : milestone ? 'border-yellow-500/50' : 'border-zinc-800'}`}>
        
        {/* SKELETON LOADER */}
        <div className={`absolute inset-0 bg-zinc-800 animate-pulse z-0 flex items-center justify-center transition-opacity duration-500 ${imageLoaded ? 'opacity-0' : 'opacity-100'}`}>
            <ImageIcon size={48} className="text-zinc-700 opacity-50" />
        </div>

        <img 
            src={post.imageUrl} 
            alt="Proof" 
            onLoad={() => setImageLoaded(true)}
            className={`w-full h-full object-cover transition-all duration-500 relative z-10 ${imageLoaded ? 'opacity-100' : 'opacity-0'} ${isContested ? 'grayscale contrast-125' : ''}`} 
            loading="lazy" 
        />
        
        {isContested && (
            <div className="absolute inset-0 bg-red-900/10 flex items-center justify-center pointer-events-none z-20">
                <div className="border-4 border-red-500 p-4 rounded-xl rotate-[-12deg] bg-black/50 backdrop-blur-sm shadow-2xl">
                    <h3 className="text-3xl font-black text-red-500 uppercase tracking-tighter">CONTESTED</h3>
                </div>
            </div>
        )}

        {milestone && !isContested && (
            <div className="absolute top-4 left-4 right-4 flex justify-center pointer-events-none z-20">
                 <div className="bg-black/60 backdrop-blur-md border border-yellow-500/50 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg animate-in slide-in-from-top-4 duration-700">
                    <Trophy size={14} className="text-yellow-500" />
                    <span className="text-xs font-black italic text-white uppercase tracking-wider">UNLOCKED: {milestone.label}</span>
                 </div>
            </div>
        )}
        
        {post.caption && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-4 pt-12 z-20">
                <p className="text-white font-medium text-sm drop-shadow-md">{post.caption}</p>
            </div>
        )}
      </div>

      {/* METRICS & TAGS GRID */}
      {(post.metrics || (post.tags && post.tags.length > 0)) && (
          <div className="mt-3 bg-zinc-900/30 rounded-xl border border-zinc-800 p-3">
              {/* Metrics */}
              {post.metrics && Object.keys(post.metrics).length > 0 && (
                  <div className="flex flex-wrap gap-4 mb-2 pb-2 border-b border-zinc-800/50">
                      {Object.entries(post.metrics).map(([key, value]) => {
                          const def = metricConfig.find(m => m.key === key);
                          if (!def || !value) return null;
                          return (
                              <div key={key} className="flex flex-col">
                                  <span className="text-[9px] text-zinc-500 uppercase font-bold">{def.label}</span>
                                  <span className="text-xs font-mono font-bold text-white">
                                      {value} <span className="text-zinc-600 text-[10px]">{def.unit}</span>
                                  </span>
                              </div>
                          )
                      })}
                  </div>
              )}
              
              {/* Tags */}
              {post.tags && post.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                      {post.tags.map(tag => (
                          <span key={tag} className="text-[9px] font-bold text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700 uppercase tracking-wide">
                              {tag}
                          </span>
                      ))}
                  </div>
              )}
          </div>
      )}

      {/* Footer */}
      <div className="flex items-center gap-4 mt-3 px-2">
        <button onClick={handleLike} className={`flex items-center gap-1.5 transition-colors active:scale-90 ${liked ? 'text-rose-500' : 'text-zinc-400'}`}>
            <Heart size={20} fill={liked ? 'currentColor' : 'none'} />
            <span className="text-xs font-bold">{likes}</span>
        </button>
        <button onClick={() => onReply && onReply(post.user?.username || 'user')} className="flex items-center gap-1.5 text-zinc-400 hover:text-white transition-colors">
            <MessageCircle size={20} />
            <span className="text-xs font-bold">Reply</span>
        </button>
      </div>
    </div>
  );
};
