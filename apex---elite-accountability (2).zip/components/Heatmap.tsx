

import React from 'react';
import { HeatmapDay } from '../types';
import { Activity, Zap, Snowflake } from 'lucide-react';

interface HeatmapProps {
  days: HeatmapDay[];
  onDayClick?: (day: HeatmapDay) => void;
}

export const Heatmap: React.FC<HeatmapProps> = ({ days, onDayClick }) => {
  // Calculate stats
  const completed = days.filter(d => d.status === 'completed' || d.status === 'frozen').length;
  const consistency = days.length > 0 ? Math.round((completed / days.filter(d => d.status !== 'future').length) * 100) : 0;

  return (
    <div className="w-full mb-8">
      <div className="flex justify-between items-end mb-4 px-1">
        <div className="flex items-center gap-2 text-zinc-500">
            <Activity size={14} />
            <h3 className="text-[10px] font-bold uppercase tracking-widest">Consistency Graph</h3>
        </div>
        <div className="flex items-center gap-2">
            <div className={`text-xs font-mono font-bold ${consistency >= 80 ? 'text-emerald-500' : 'text-zinc-500'}`}>
                {isNaN(consistency) ? 0 : consistency}%
            </div>
            <div className={`w-2 h-2 rounded-full ${consistency >= 80 ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]' : 'bg-zinc-800'}`} />
        </div>
      </div>
      
      <div className="bg-zinc-900/30 border border-zinc-800/50 p-4 rounded-2xl backdrop-blur-sm">
        <div className="grid grid-cols-7 gap-2">
            {days.map((day, idx) => {
            let bgColor = 'bg-zinc-900';
            let borderColor = 'border-transparent';
            let shadow = '';
            let content = null;
            
            if (day.status === 'completed') {
                borderColor = 'border-emerald-500/20';
                // Opacity based on intensity
                if (day.intensity > 80) {
                    bgColor = 'bg-emerald-500';
                    shadow = 'shadow-[0_0_12px_rgba(16,185,129,0.4)]';
                } else {
                    bgColor = 'bg-emerald-900';
                }
            } else if (day.status === 'frozen') {
                bgColor = 'bg-blue-500/20';
                borderColor = 'border-blue-500/50';
                content = <Snowflake size={10} className="text-blue-400" />;
            } else if (day.status === 'missed') {
                bgColor = 'bg-red-950/20';
                borderColor = 'border-red-900/10';
                content = <div className="w-1 h-1 rounded-full bg-red-900/50" />;
            } else if (day.status === 'pending') {
                bgColor = 'bg-zinc-800 animate-pulse';
                borderColor = 'border-zinc-700';
            } else if (day.status === 'future') {
                bgColor = 'bg-transparent';
                borderColor = 'border-zinc-800/30 border-dashed';
            }

            return (
                <button 
                key={idx}
                onClick={() => onDayClick && day.status !== 'future' && onDayClick(day)}
                disabled={day.status === 'future'}
                className={`aspect-square rounded-md border flex items-center justify-center transition-all duration-300 ${bgColor} ${borderColor} ${shadow} ${day.status !== 'future' ? 'cursor-pointer hover:scale-110 hover:border-white/20' : 'cursor-default'}`}
                >
                    {content}
                </button>
            );
            })}
        </div>
        
        <div className="flex justify-between items-center mt-3 px-1">
            <span className="text-[9px] text-zinc-600 font-mono uppercase">28 Day Cycle</span>
            <div className="flex gap-1">
                <div className="w-2 h-2 rounded bg-zinc-900 border border-zinc-800" />
                <div className="w-2 h-2 rounded flex items-center justify-center bg-blue-900/50 border border-blue-500/20"><Snowflake size={8} className="text-blue-500" /></div>
                <div className="w-2 h-2 rounded bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.4)]" />
            </div>
        </div>
      </div>
    </div>
  );
};
