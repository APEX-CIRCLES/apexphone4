import React from 'react';
import { Lock, Camera } from 'lucide-react';

interface FogOfWarProps {
  onCheckIn: () => void;
}

export const FogOfWar: React.FC<FogOfWarProps> = ({ onCheckIn }) => {
  return (
    <div className="absolute inset-0 z-20 backdrop-blur-2xl bg-black/40 flex flex-col items-center justify-center p-6 text-center">
      <div className="mb-6 bg-zinc-900/80 p-4 rounded-full border border-zinc-700 shadow-2xl">
        <Lock size={32} className="text-apex-muted" />
      </div>
      
      <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white mb-2">
        Fog of War Active
      </h2>
      <p className="text-apex-muted text-sm mb-8 max-w-[250px]">
        You cannot see the circle's progress until you prove your own.
      </p>

      <button 
        onClick={onCheckIn}
        className="group relative flex items-center gap-3 bg-apex-text text-black px-8 py-4 rounded-full font-bold uppercase tracking-wide hover:bg-white transition-all active:scale-95 animate-pulse-border"
      >
        <Camera size={20} />
        <span>Post Proof</span>
      </button>

      <div className="mt-8 text-xs font-mono text-zinc-600">
        NO PROOF • NO ACCESS • NO EXCUSES
      </div>
    </div>
  );
};