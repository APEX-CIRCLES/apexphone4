
import React, { useState, useEffect } from 'react';
import { X, Volume2, VolumeX, Smartphone, Trash2, Settings, ShieldAlert, LogOut } from 'lucide-react';
import { toggleSound, toggleHaptics, playClick } from '../lib/sound';

interface SettingsModalProps {
  onClose: () => void;
  onSignOut: () => void;
  onDeleteAccount: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, onSignOut, onDeleteAccount }) => {
  const [soundOn, setSoundOn] = useState(true);
  const [hapticsOn, setHapticsOn] = useState(true);

  useEffect(() => {
      // Load prefs (In real app, load from localStorage)
      const savedSound = localStorage.getItem('apex_sound') !== 'false';
      const savedHaptics = localStorage.getItem('apex_haptics') !== 'false';
      setSoundOn(savedSound);
      setHapticsOn(savedHaptics);
      toggleSound(savedSound);
      toggleHaptics(savedHaptics);
  }, []);

  const handleToggleSound = () => {
      const newState = !soundOn;
      setSoundOn(newState);
      toggleSound(newState);
      localStorage.setItem('apex_sound', String(newState));
      if (newState) playClick();
  };

  const handleToggleHaptics = () => {
      const newState = !hapticsOn;
      setHapticsOn(newState);
      toggleHaptics(newState);
      localStorage.setItem('apex_haptics', String(newState));
      if (newState) playClick();
  };

  const handleDelete = () => {
      if (window.confirm("CRITICAL: Are you sure? This will permanently delete your profile, streaks, and history.")) {
          onDeleteAccount();
      }
  };

  return (
    <div className="fixed inset-0 z-[150] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/30">
          <div className="flex items-center gap-2 text-white">
            <Settings className="w-5 h-5 text-zinc-400" />
            <h2 className="font-bold uppercase tracking-wider text-sm">System Config</h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
            
            {/* Audio / Sensory */}
            <div className="space-y-3">
                <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Sensory Feedback</h3>
                
                <button 
                    onClick={handleToggleSound}
                    className="w-full flex items-center justify-between p-4 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all"
                >
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${soundOn ? 'bg-emerald-500/10 text-emerald-500' : 'bg-zinc-800 text-zinc-500'}`}>
                            {soundOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
                        </div>
                        <span className="text-sm font-bold text-zinc-300">Audio FX</span>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${soundOn ? 'bg-emerald-500' : 'bg-zinc-700'}`}>
                        <div className={`absolute top-1 bottom-1 w-3 bg-white rounded-full transition-all ${soundOn ? 'left-6' : 'left-1'}`} />
                    </div>
                </button>

                <button 
                    onClick={handleToggleHaptics}
                    className="w-full flex items-center justify-between p-4 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all"
                >
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${hapticsOn ? 'bg-blue-500/10 text-blue-500' : 'bg-zinc-800 text-zinc-500'}`}>
                            <Smartphone size={20} />
                        </div>
                        <span className="text-sm font-bold text-zinc-300">Haptics</span>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${hapticsOn ? 'bg-blue-500' : 'bg-zinc-700'}`}>
                        <div className={`absolute top-1 bottom-1 w-3 bg-white rounded-full transition-all ${hapticsOn ? 'left-6' : 'left-1'}`} />
                    </div>
                </button>
            </div>

            {/* Account Actions */}
            <div className="space-y-3">
                <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Account & Data</h3>
                
                <button 
                    onClick={onSignOut}
                    className="w-full flex items-center gap-3 p-4 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition-all text-zinc-300"
                >
                    <LogOut size={20} />
                    <span className="text-sm font-bold">Sign Out</span>
                </button>

                <button 
                    onClick={handleDelete}
                    className="w-full flex items-center gap-3 p-4 rounded-xl bg-red-950/10 border border-red-900/30 hover:bg-red-950/20 transition-all text-red-500 group"
                >
                    <ShieldAlert size={20} className="group-hover:animate-pulse" />
                    <span className="text-sm font-bold">Delete Account</span>
                </button>
            </div>

            <div className="text-center pt-4">
                <p className="text-[10px] text-zinc-600 font-mono">APEX v1.0.0 • BUILD {new Date().getFullYear()}</p>
            </div>

        </div>
      </div>
    </div>
  );
};
